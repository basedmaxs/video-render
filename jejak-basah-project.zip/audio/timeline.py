# Picture timeline mirrored from src/story.ts + src/cast.ts (seconds). Quiet ghost story: gang, night, drain, toy.
import numpy as np

FPS = 30
TOTAL = 1442
DUR = TOTAL / FPS            # 48.067 s
fr = lambda f: f / FPS
FLASH = 1e6                  # no white flash in this film

CUTS = [0, 122, 224, 289, 364, 426, 483, 543, 567, 632, 688, 747, 799, 876, 903, 944, 1001, 1057, 1157, 1238, 1319, TOTAL]
LIGHT = {i: ("night" if 8 <= i <= 18 else "golden" if i == 21 else "day") for i in range(1, 22)}
SHOTS = {i + 1: (CUTS[i], CUTS[i + 1], LIGHT[i + 1], "gang") for i in range(21)}
XFADE = {8: 8, 19: 8, 21: 10}

# story events (seconds)
FLOUR = (14.4, 15.7)
NIGHT_T, MORNING_T = 18.2, 38.66
DOOR = (21.2, 22.5)
KID_OUT = (22.8, 24.7)
WALK = (26.75, 29.2)
FADE = (30.2, 31.0)
TOY_T = 40.1
N_PRINTS = 11
print_t = lambda i: WALK[0] + 0.25 + i * (WALK[1] - WALK[0] - 0.35) / (N_PRINTS - 1)
PRINTS = [print_t(i) for i in range(N_PRINTS)]


def shot_t(i):
    a, b = SHOTS[i][:2]
    return fr(a), fr(b)


def shot_at(t):
    f = t * FPS
    for i, (a, b, *_r) in SHOTS.items():
        if a <= f < b:
            return i
    return 21


def words(path):
    import json
    return json.load(open(path, encoding="utf-8"))
