# Jejak basah - soundtrack cue sheet

All sound is original: synthesized in numpy/scipy by `sfx_gen.py` / `instruments.py`, placed by `sfx.py` / `music.py`, mixed by `mix.py`.
Voice = `voice/voice.wav`, gain only (no EQ, no compression, no pitch).

## Files
| file | content |
|---|---|
| `mix.wav` | final mix, 48 kHz, stereo, 24-bit, 3,240,000 samples = 67.500 s |
| `stem_voice.wav` / `stem_music.wav` / `stem_sfx.wav` | stems at mix gain (they sum to the mix before the master limiter) |

## Master loudness (own BS.1770-4 meter)
- Integrated **-15.0 LUFS**, true peak **-1.2 dBTP**, LRA 2.8 LU, max momentary -9.6 LUFS, max short-term -12.9 LUFS
- Stems: voice -14.6 LUFS, music -25.1 LUFS, sfx -31.2 LUFS (voice gain +17.19 dB, same gain on every stem)
- Master limiter (4x oversampled look-ahead, ceiling -1.2 dBTP): max gain reduction 4.57 dB, active (>0.1 dB) on 20.79 % of samples, >0.5 dB on 8.89 %

ffmpeg ebur128 cross-check:
```
Summary:
  Integrated loudness:
    I:         -15.0 LUFS
    Threshold: -25.1 LUFS
  Loudness range:
    LRA:         2.9 LU
    Threshold: -35.1 LUFS
    LRA low:   -16.5 LUFS
    LRA high:  -13.6 LUFS
  True peak:
    Peak:       -1.2 dBFS
```

## Voice on top: per-section loudness (LUFS, integrated per stem, at mix gain)
bed = music + sfx. margin = voice - bed (integrated over the section). speech median / p10 = median and 10th percentile of the 400 ms momentary margin (voice - bed) over windows centred on spoken words.

| section (shots) | time s | voice | music | sfx | bed | margin LU | speech median LU | speech p10 LU |
|---|---|---|---|---|---|---|---|---|
| hook (1-2) | 0.00-7.47 | -13.3 | -24.2 | -34.4 | -23.8 | 10.5 | 10.6 | 6.1 |
| watch (3-7) | 7.47-18.10 | -14.3 | -24.8 | -33.9 | -24.3 | 9.9 | 10.4 | 5.3 |
| night (8-13) | 18.10-29.20 | -14.6 | -24.6 | -28.4 | -23.2 | 8.6 | 8.1 | 4.8 |
| fade (14-16) | 29.20-33.37 | -16.5 | -26.8 | -29.2 | -25.4 | 8.9 | 9.0 | 5.0 |
| memory (17-18) | 33.37-38.57 | -14.6 | -25.7 | -31.4 | -24.6 | 10.1 | 9.8 | 5.6 |
| morning (19-20) | 38.57-43.97 | -15.9 | -26.5 | -32.3 | -25.5 | 9.5 | 9.2 | 6.8 |
| moral (21) | 43.97-48.07 | -15.3 | -26.4 | -34.3 | -25.6 | 10.3 | 10.7 | 6.7 |

## Music map (original march, Bb major, 120 bpm: quarter note = footfall)
Music target per section, LU under the voice (after a -3 dB speech duck keyed from words.json): hook -10.5, watch -10.5, night -10.0, fade -9.5, memory -11.0, morning -10.5, moral -11.0. Applied section gains (dB): hook -18.6, watch -21.7, night -21.6, fade -21.0, memory -22.3, morning -23.9, moral -22.5, dropout -21.6.

Rides (music only, dB): 3.00-3.55 s -2.0, 6.20-6.80 s -2.0, 37.40-37.96 s -2.5 - so quiet sentence-final words stay on top and the band blooms in the gaps after them. The hook's last two footfalls (3.5, 4.0) are also 3 dB lower in the SFX for '...walking across it.'

| time s | frame | music |
|---|---|---|
| 0.00 | 0 | hook: low pad, music-box lullaby fragments |
| 7.50 | 225 | watch: pizzicato bass, vibes lullaby, glock sparkle for the flour |
| 18.10 | 543 | night: pad, deep pizzicato, music-box lullaby an octave down, soft timpani heartbeat when the door opens |
| 29.20 | 876 | dead stop: held breath on 'Tiba-tiba,' |
| 30.15 | 904 | fade: ascending glock shimmer + warm pad as she dissolves |
| 33.40 | 1002 | memory: slow descending vibes + music box, deep bass |
| 38.60 | 1158 | morning: C-major lullaby on vibes + glock, plucked bass; a music-box note as the toy is set down |
| 44.00 | 1320 | moral: music-box + low vibes lullaby, final warm chord |

## SFX events
Level convention: every EVENT has a naive level (LU vs the voice stem, as the event's max momentary loudness); applied = naive - 6 dB (standard mix rule) + distance/intensity offsets. BEDS are integrated loudness, not reduced. 'mix LUFS' = the event's max momentary loudness in the final mix (voice stem = -14.6 LUFS integrated). Column sounds also get the camera-distance low-pass and more valley reverb.

| # | time s | frame | cue | what | naive LU | applied LU | mix LUFS | pan |
|---|---|---|---|---|---|---|---|---|
| 1 | 0.000 | 0.0 | amb_day (bed, integrated) | kampung morning: roosters far away, sparrows, soft breeze (shots 1-7) | -20 | -20.0 | -34.6 | +0.00 |
| 2 | 7.450 | 223.5 | step_in | he stops at the prints | -8 | -14.0 | -28.6 | +0.30 |
| 3 | 12.350 | 370.5 | hmm | puzzled breath on 'berhenti di tengah halaman' | -10 | -16.0 | -30.6 | -0.10 |
| 4 | 14.400 | 432.0 | flour | flour sprinkled on the ground | -13 | -19.0 | -33.6 | +0.00 |
| 5 | 16.300 | 489.0 | bag | tiny pat of the hands, done | -17 | -23.0 | -37.6 | +0.20 |
| 6 | 17.900 | 537.0 | amb_night (bed, integrated) | night in the gang: crickets, a distant dog, still air (shots 8-18) | -19 | -19.0 | -33.6 | +0.00 |
| 7 | 21.150 | 634.5 | door_creak | the door opens slowly: wood creak | -5 | -11.0 | -25.6 | -0.40 |
| 8 | 21.400 | 642.0 | gasp | he holds his breath at the window | -13 | -19.0 | -33.6 | +0.40 |
| 9 | 22.400 | 672.0 | door_stop | door settles against the wall | -13 | -19.0 | -33.6 | -0.40 |
| 10 | 23.000 | 690.0 | wet_in | wet footstep inside / on the porch | -11 | -18.0 | -32.6 | -0.30 |
| 11 | 23.280 | 698.4 | wet_in | wet footstep inside / on the porch | -11 | -18.0 | -32.6 | -0.30 |
| 12 | 23.560 | 706.8 | wet_in | wet footstep inside / on the porch | -11 | -17.0 | -31.6 | -0.30 |
| 13 | 23.840 | 715.2 | wet_in | wet footstep inside / on the porch | -11 | -17.0 | -31.6 | -0.30 |
| 14 | 24.120 | 723.6 | wet_in | wet footstep inside / on the porch | -11 | -17.0 | -31.6 | -0.30 |
| 15 | 24.400 | 732.0 | wet_in | wet footstep inside / on the porch | -11 | -17.0 | -31.6 | -0.30 |
| 16 | 24.680 | 740.4 | wet_in | wet footstep inside / on the porch | -11 | -17.0 | -31.6 | -0.30 |
| 17 | 24.900 | 747.0 | drip | water drips from her feet | -14 | -20.0 | -34.6 | -0.30 |
| 18 | 25.450 | 763.5 | drip | water drips from her feet | -14 | -20.0 | -34.6 | -0.04 |
| 19 | 26.000 | 780.0 | drip | water drips from her feet | -14 | -20.0 | -34.6 | -0.24 |
| 20 | 26.550 | 796.5 | drip | water drips from her feet | -14 | -20.0 | -34.6 | -0.14 |
| 21 | 27.000 | 810.0 | wet_step | wet footprint 1/11 | -9 | -15.0 | -29.6 | -0.50 |
| 22 | 27.210 | 816.3 | wet_step | wet footprint 2/11 | -9 | -15.0 | -29.6 | -0.39 |
| 23 | 27.420 | 822.6 | wet_step | wet footprint 3/11 | -9 | -15.0 | -29.6 | -0.28 |
| 24 | 27.630 | 828.9 | wet_step | wet footprint 4/11 | -9 | -15.0 | -29.6 | -0.17 |
| 25 | 27.840 | 835.2 | wet_step | wet footprint 5/11 | -9 | -15.0 | -29.6 | -0.06 |
| 26 | 28.050 | 841.5 | wet_step | wet footprint 6/11 | -9 | -15.0 | -29.6 | +0.05 |
| 27 | 28.260 | 847.8 | wet_step | wet footprint 7/11 | -9 | -15.0 | -29.6 | +0.16 |
| 28 | 28.470 | 854.1 | wet_step | wet footprint 8/11 | -9 | -15.0 | -29.6 | +0.27 |
| 29 | 28.680 | 860.4 | wet_step | wet footprint 9/11 | -9 | -15.0 | -29.6 | +0.38 |
| 30 | 28.890 | 866.7 | wet_step | wet footprint 10/11 | -9 | -15.0 | -29.6 | +0.49 |
| 31 | 29.100 | 873.0 | wet_step | wet footprint 11/11 | -9 | -15.0 | -29.6 | +0.60 |
| 32 | 29.300 | 879.0 | stop | she stops: a single last drip | -13 | -19.0 | -33.6 | +0.00 |
| 33 | 30.150 | 904.5 | fade_shimmer | she dissolves: airy shimmer | -6 | -12.0 | -26.6 | +0.00 |
| 34 | 31.700 | 951.0 | ripple | water rings where the trail ends | -13 | -19.0 | -33.6 | +0.00 |
| 35 | 35.900 | 1077.0 | drain (bed, integrated) | the drain: trickle and drips | -17 | -17.0 | -31.6 | +0.00 |
| 36 | 38.260 | 1147.8 | amb_morning (bed, integrated) | morning again: sparrows, breeze, a rooster (shots 19-21) | -21 | -21.0 | -35.6 | +0.00 |
| 37 | 40.070 | 1202.1 | toy_tok | wooden toy set down on the stones | -5 | -11.0 | -25.6 | +0.10 |
| 38 | 41.500 | 1245.0 | relief | he breathes out | -13 | -19.0 | -33.6 | +0.20 |
| 39 | 44.900 | 1347.0 | chime | soft chime as she rests on the porch | -11 | -17.0 | -31.6 | -0.30 |
