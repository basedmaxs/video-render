# Every sound effect + ambience bed of the gang short as a cue list timed to the picture (timeline.py), rendered
# into one stereo SFX stem. Levels follow the user's standard mix: each EVENT has a "naive" level (LU relative to the
# voice stem, measured as the event's max momentary loudness) and is placed SFX_DB = -6 dB under it; ambience BEDS
# (integrated loudness) are not reduced. Distance to the camera adds gain, a low-pass and more valley reverb.
import math
import numpy as np
from dsp import (SR, ns, tt, rng, dbg, lp, hp, bp, peq, shelf, pan, st, place, fades, widen, make_ir, convolve_st,
                 momentary_max, integrated, colored, smooth_noise, modal)
import sfx_gen as G
import timeline as T

N = ns(T.DUR)
SFX_DB = -6.0


class Cue:
    def __init__(self, t, name, desc, gen, naive, kind="event", p=0.0, extra=0.0, lpf=None, send=0.12, group=None, cut=None):
        self.t, self.name, self.desc, self.gen, self.naive = t, name, desc, gen, naive
        self.kind, self.p, self.extra, self.lpf, self.send, self.cut = kind, p, extra, lpf, send, cut
        self.group = group or name
        self.applied = naive + (SFX_DB if kind == "event" else 0.0) + extra
        self.measured = None


def cues():
    C = []
    R = rng(7741)
    rr = lambda: rng(int(R.integers(1 << 30)))
    add = C.append

    # ------------------------------------------------ ambience beds
    add(Cue(0.0, "amb_day", "kampung morning: roosters far away, sparrows, soft breeze (shots 1-7)",
            _cut(lambda: (_day(T.NIGHT_T + 0.4, rng(11)), 0.0), T.NIGHT_T + 0.4, 0.4, 0.9), -25, "bed", send=0.0))
    add(Cue(T.NIGHT_T - 0.3, "amb_night", "night in the gang: crickets, a distant dog, still air (shots 8-18)",
            _cut(lambda: (_night(T.MORNING_T - T.NIGHT_T + 0.8, rng(12)), 0.0), T.MORNING_T - T.NIGHT_T + 0.8, 0.8, 1.0), -24, "bed", send=0.0))
    add(Cue(T.MORNING_T - 0.4, "amb_morning", "morning again: sparrows, breeze, a rooster (shots 19-21)",
            _cut(lambda: (_day(T.DUR - T.MORNING_T + 0.4, rng(13)), 0.0), T.DUR - T.MORNING_T + 0.4, 0.9, 1.2), -26, "bed", send=0.0))

    # ------------------------------------------------ morning one: the young man
    add(Cue(7.45, "step_in", "he stops at the prints", (lambda r=rr(): (shelf(G.stroll_step(r, 0.5), 1500, 4.0, "high"), 0.0)), -17, p=0.3, send=0.2, group="steps"))
    add(Cue(12.35, "hmm", "puzzled breath on 'berhenti di tengah halaman'", (lambda r=rr(): (G.oof(r, "oh", 118), 0.1)), -19, p=-0.1, send=0.2, group="breath"))
    add(Cue(T.FLOUR[0], "flour", "flour sprinkled on the ground", (lambda r=rr(): (_flour(r), 0.2)), -22, p=0.0, send=0.15))
    add(Cue(16.3, "bag", "tiny pat of the hands, done", (lambda r=rr(): (_pat(r), 0.0)), -26, p=0.2, send=0.1))

    # ------------------------------------------------ the night
    add(Cue(T.DOOR[0] - 0.05, "door_creak", "the door opens slowly: wood creak", (lambda r=rr(): (G.creak(1.3, r, 95, 170, scale=0.9), 0.0)), -14, p=-0.4, send=0.3, group="door"))
    add(Cue(T.DOOR[1] - 0.1, "door_stop", "door settles against the wall", (lambda r=rr(): (G.push_thump(r), 0.0)), -22, p=-0.4, send=0.25, group="door"))
    add(Cue(21.4, "gasp", "he holds his breath at the window", (lambda r=rr(): (G.whoa(r, 118, 0.32), 0.1)), -22, p=0.4, send=0.3, group="breath"))
    for k, t in enumerate(np.arange(23.0, 24.7, 0.28)):
        add(Cue(float(t), "wet_in", "wet footstep inside / on the porch", (lambda r=rr(): (_wet(r, 0.7), 0.02)), -20, p=-0.3, extra=-1.0 * (k < 2), send=0.3, group="wet"))
    for k, t in enumerate(np.arange(24.9, 26.6, 0.55)):
        add(Cue(float(t), "drip", "water drips from her feet", (lambda r=rr(): (_drip(r), 0.0)), -23, p=float(R.uniform(-0.3, 0.3)), send=0.4, group="drip"))
    for i, t in enumerate(T.PRINTS):
        add(Cue(t, "wet_step", f"wet footprint {i + 1}/{T.N_PRINTS}", (lambda r=rr(): (_wet(r, 1.0), 0.02)), -18, p=float(np.clip(-0.5 + 0.11 * i, -0.6, 0.6)), send=0.35, group="wet"))
    add(Cue(T.WALK[1] + 0.1, "stop", "she stops: a single last drip", (lambda r=rr(): (_drip(r), 0.0)), -22, p=0.0, send=0.5, group="drip"))
    add(Cue(T.FADE[0] - 0.05, "fade_shimmer", "she dissolves: airy shimmer", lambda: (_shimmer(rng(21)), 0.0), -15, p=0.0, send=0.55))
    add(Cue(31.7, "ripple", "water rings where the trail ends", (lambda r=rr(): (G.bubbles(1.2, r, 14, 400, 2200, env=None), 0.0)), -22, p=0.0, send=0.5))

    # ------------------------------------------------ the memory + the toy
    add(Cue(35.9, "drain", "the drain: trickle and drips", lambda: (_trickle(2.2, rng(22)), 0.0), -22, "bed", p=0.0, send=0.5))
    add(Cue(T.TOY_T - 0.03, "toy_tok", "wooden toy set down on the stones", (lambda r=rr(): (_wood(r), 0.0)), -14, p=0.1, send=0.25))
    add(Cue(41.5, "relief", "he breathes out", (lambda r=rr(): (G.oof(r, "ugh", 112), 0.1)), -22, p=0.2, send=0.25, group="breath"))
    add(Cue(44.9, "chime", "soft chime as she rests on the porch", lambda: (_glints(rng(23)), 0.0), -20, p=-0.3, send=0.45))
    for c in C:
        c.naive += 5 if c.kind == "bed" else 9
        c.applied += 5 if c.kind == "bed" else 9
    return C



def _cut(gen, dur, fin, fout):
    def g():
        x, a = gen()
        return fades(x, fin, fout), a
    return g


def _env(gen, dur, fin, fout):
    return _cut(gen, dur, fin, fout)


# ================================================================ generators for this story
def _wet(r, size=1.0):
    d = 0.32
    n = ns(d)
    t = np.arange(n) / SR
    nz = r.standard_normal(n)
    splash = bp(nz, 350, 3200, 1) * np.exp(-t / 0.045) * (0.8 + 0.4 * smooth_noise(n, r, 30))
    slap = np.sin(2 * np.pi * (140 - 60 * np.minimum(t / 0.05, 1)) * t) * np.exp(-t / 0.03) * 0.9
    flick = hp(nz, 4500) * np.exp(-t / 0.012) * 0.25
    return fades((splash + slap + flick) * size, 0.002, 0.05)


def _drip(r):
    d = 0.35
    t = tt(d)
    f = 1400 + 900 * (1 - np.exp(-t / 0.02))
    y = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / 0.05)
    y += 0.4 * np.sin(2 * np.pi * np.cumsum(f * 1.5) / SR) * np.exp(-t / 0.03)
    return fades(y * np.clip(t / 0.002, 0, 1), 0.001, 0.08)


def _flour(r):
    d = 1.5
    n = ns(d)
    t = np.arange(n) / SR
    y = bp(colored(n, r, 0.3), 3000, 9000, 1) * smooth_noise(n, r, 9) ** 2 * np.clip(t / 0.15, 0, 1) * np.clip((d - t) / 0.3, 0, 1) * 0.8
    return fades(y, 0.02, 0.2)


def _pat(r):
    t = tt(0.18)
    return (bp(r.standard_normal(len(t)), 600, 3500, 1) * np.exp(-t / 0.02) + 0.5 * np.sin(2 * np.pi * 180 * t) * np.exp(-t / 0.025)) * 0.7


def _wood(r):
    t = tt(0.35)
    y = np.zeros(len(t))
    for f, a, tau in [(420, 1.0, 0.03), (780, 0.6, 0.02), (1300, 0.35, 0.012)]:
        y += a * np.sin(2 * np.pi * f * r.uniform(0.97, 1.03) * t) * np.exp(-t / tau)
    y += 0.4 * bp(r.standard_normal(len(t)), 800, 4000, 1) * np.exp(-t / 0.006)
    return fades(y, 0.001, 0.05)


def _glints(r):
    out = np.zeros(ns(1.6))
    for k, f in enumerate([1900, 2500, 3100, 2300, 3700]):
        c = np.asarray(G.clink(r, f, 0.4, 1.0), float) * 0.7
        i = ns(0.17 * k + r.uniform(0, 0.03))
        out[i:i + len(c)] += c[: len(out) - i]
    return fades(out, 0.002, 0.3)


def _shimmer(r):
    d = 2.0
    n = ns(d)
    t = np.arange(n) / SR
    y = np.zeros(n)
    for k in range(9):
        f = 1200 + 500 * k + r.uniform(-30, 30)
        t0 = 0.08 * k
        env = np.where(t > t0, np.exp(-(t - t0) / 0.35), 0) * np.clip((t - t0) / 0.02, 0, 1)
        y += 0.2 * np.sin(2 * np.pi * f * t) * env
    y += 0.25 * hp(colored(n, r, 0.4), 3500) * np.exp(-t / 0.7)
    return st(fades(y, 0.005, 0.5))


def _trickle(dur, r):
    n = ns(dur)
    x = bp(colored(n, r, 0.5), 400, 3200, 1) * 0.35 * smooth_noise(n, r, 7)
    d = np.zeros(n)
    for tm in np.arange(0.1, dur - 0.2, 0.35):
        c = _drip(r) * 0.5
        i = ns(tm + r.uniform(0, 0.2))
        d[i:i + len(c)] += c[: n - i]
    return st(fades(x + d, 0.3, 0.6))


def _day(dur, r):
    n = ns(dur)
    x = G.breeze(dur, r, 0.7, 0.15, 700)
    x += pan(G.bird_chirps(dur, r, 0.5, "sparrow") * 0.08, 0.5)
    x += pan(G.bird_chirps(dur, r, 0.35, "sparrow") * 0.05, -0.6)
    x += pan(G.bird_chirps(dur, r, 0.25, "blackbird") * 0.04, 0.1)
    return x


def _night(dur, r):
    n = ns(dur)
    x = G.breeze(dur, r, 0.45, 0.1, 500)
    x += widen(G.crickets(dur, r, 4) * 0.02, r, 9, 1.0)
    return x


def render(v_ref, on_event=None):
    """v_ref = integrated loudness of the voice stem (stereo). Returns (stereo stem, cue list with measured levels).
    on_event(cue, x, t0) is called with every placed (dry) event, for analysis."""
    C = cues()
    out = np.zeros((2, N))
    send = np.zeros(N)
    for c in C:
        x, anchor = c.gen()
        x = np.asarray(x, float)
        x = pan(x, c.p) if x.ndim == 1 else x
        if c.cut is not None:
            k = ns(c.cut - (c.t - anchor))
            if 0 < k < x.shape[1]:
                x = fades(x[:, :k], 0.0, 0.02)
        tgt = v_ref + c.applied
        cur = momentary_max(x) if c.kind == "event" else integrated(x)
        if np.isfinite(cur):
            x = x * dbg(tgt - cur)
        if c.lpf:
            x = lp(x, c.lpf, 1)
        c.measured = momentary_max(x) - v_ref if c.kind == "event" else integrated(x) - v_ref
        t0 = c.t - anchor
        place(out, x, t0)
        if on_event:
            on_event(c, x, t0)
        if c.send > 0:
            G._place_mono(send, c.send * x.mean(0), t0)
    valley = make_ir(1.1, 77, pre=0.01, hf=1.6, early=[(0.09, 0.45, -0.5), (0.14, 0.3, 0.6), (0.23, 0.2, -0.2)])
    out += 0.55 * convolve_st(send, valley)
    out = hp(out, 25, 2)
    end = ns(T.DUR - 0.12)
    out[:, end:] *= np.linspace(1, 0, N - end)[None, :] ** 2
    return out, C
