# Original score for "Jejak basah" (A minor -> C major at dawn, 76 bpm): music box + vibes + glockenspiel, a low pad and sparse
# pizzicato. A slow lullaby motif carries the whole film: curious in the morning, creeping at night, a held-breath DEAD STOP on
# "Tiba-tiba," (the child stops), shimmering glock as she fades, sad and slow in the memory, then the same lullaby in C major.
import numpy as np
from dsp import SR, ns, rng, pan, place, fades, dbg, make_ir, convolve_st, integrated, lp, hp
import instruments as I
import timeline as T

N = ns(T.DUR)
Q = 60.0 / 76.0
F = I.m2f

SECTIONS = [("hook", 0.0, 7.5), ("watch", 7.5, 18.1), ("night", 18.1, 29.2), ("dropout", 29.2, 30.15), ("fade", 30.15, 33.4),
            ("memory", 33.4, 38.6), ("morning", 38.6, 44.0), ("moral", 44.0, T.DUR)]
HARD = [29.2, 30.15]

LULLABY = [(0, 1, 69), (1, 1, 72), (2, 1, 76), (3, 1, 74), (4, 1, 72), (5, 1, 71), (6, 2, 69)]
LULLABY_C = [(0, 1, 72), (1, 1, 76), (2, 1, 79), (3, 1, 77), (4, 1, 76), (5, 1, 74), (6, 2, 72)]
CH_AM = [(45, 52, 57, 60), (41, 48, 53, 57), (43, 50, 55, 59), (40, 47, 52, 56)]       # Am F G E (root, 5th, chord notes)
CH_C = [(48, 55, 60, 64), (45, 52, 57, 60), (41, 48, 53, 57), (43, 50, 55, 59)]       # C Am F G


class Band:
    def __init__(self):
        self.tr = {}
        self.send = {}
        self.cues = []

    def track(self, name, send):
        if name not in self.tr:
            self.tr[name] = np.zeros((2, N))
            self.send[name] = send
        return self.tr[name]

    def add(self, name, x, t, p=0.0, g=1.0, send=0.15):
        buf = self.track(name, send)
        place(buf, pan(x, p) if np.ndim(x) == 1 else x, t, g)


R = rng(1831)


def _r():
    return rng(int(R.integers(1 << 30)))




R = rng(4417)


def _r():
    return rng(int(R.integers(1 << 30)))


def lull(b, t0, notes, name="musicbox", tr=0, vel=0.5, p=0.0):
    for (o, d, m) in notes:
        tm = t0 + o * Q
        if name == "musicbox":
            x = I.musicbox(F(m + tr), vel * R.uniform(0.94, 1.04), _r())
        elif name == "vibes":
            x = I.vibes(F(m + tr), vel * R.uniform(0.94, 1.04), _r(), dur=max(1.4, d * Q + 0.9), damp=d * Q + 0.5)
        else:
            x = I.glock(F(m + tr + 12), vel * R.uniform(0.94, 1.04), _r())
        b.add(name, x, tm, p)


def bass(b, t0, t1, chords, vel=0.45, every=2):
    k, t = 0, t0
    while t < t1 - 0.1:
        ch = chords[(k // every) % len(chords)]
        b.add("pluck", I.pluck(F(ch[0] if k % every == 0 else ch[1]), vel * R.uniform(0.92, 1.05), _r(), dur=0.9, bright=0.25), t, -0.1)
        k += 1
        t += Q


def padc(b, t, dur, chord, vel=0.38):
    b.add("pad", I.pad([F(m) for m in chord[1:]], dur, vel, _r(), att=min(1.4, dur * 0.4), rel=min(1.2, dur * 0.4)), t, 0.0)


def build():
    b = Band()
    for name, send in [("pluck", 0.12), ("vibes", 0.30), ("glock", 0.26), ("musicbox", 0.30), ("pad", 0.28), ("timpani", 0.16), ("triangle", 0.25)]:
        b.track(name, send)

    # ---- hook 0 - 7.5: low pad, lone music box fragments (wet prints under a clear sky)
    padc(b, 0.0, 7.6, CH_AM[0], 0.32)
    lull(b, 0.4, LULLABY[:4], "musicbox", 0, 0.5, 0.15)
    lull(b, 4.1, LULLABY[3:], "musicbox", 0, 0.42, -0.15)
    b.cues.append((0.0, "hook: low pad, music-box lullaby fragments"))

    # ---- watch 7.5 - 18.1: the young man investigates: plucked bass + vibes lullaby, flour sprinkle sparkle at 14.4
    bass(b, 7.5, 18.1, CH_AM, 0.45)
    lull(b, 7.6, LULLABY, "vibes", 0, 0.5, -0.1)
    lull(b, 7.6 + 8 * Q, LULLABY[:5], "vibes", 0, 0.5, -0.1)
    for k, m in enumerate([81, 84, 88, 91]):
        b.add("glock", I.glock(F(m), 0.3, _r()), 14.45 + k * 0.12, 0.2)
    padc(b, 7.5, 5.0, CH_AM[1], 0.3); padc(b, 12.5, 5.6, CH_AM[3], 0.3)
    b.cues.append((7.5, "watch: pizzicato bass, vibes lullaby, glock sparkle for the flour"))

    # ---- night 18.1 - 29.2: creeping, door opens, child steps out, wet steps; tension pad climbs
    padc(b, 18.1, 11.0, CH_AM[0], 0.45)
    padc(b, 21.0, 8.1, (45, 52, 57, 60, 64), 0.32)
    bass(b, 18.4, 29.1, [CH_AM[0], CH_AM[3]], 0.38, every=4)
    lull(b, 19.0, LULLABY[:6], "musicbox", -12, 0.38, 0.0)
    for k in range(6):
        b.add("timpani", I.timpani(F(33), 0.18 + 0.05 * k, _r(), dur=1.0), 22.6 + k * 1.0, 0.0)
    b.add("musicbox", I.musicbox(F(93), 0.3, _r()), 24.6, 0.3)
    b.cues.append((18.1, "night: pad, deep pizzicato, music-box lullaby an octave down, soft timpani heartbeat when the door opens"))

    # ---- DEAD STOP on "Tiba-tiba," (child stops): everything stops
    for tr in b.tr.values():
        tr[:, ns(29.2):] = 0.0
    b.cues.append((29.2, "dead stop: held breath on 'Tiba-tiba,'"))

    # ---- fade 30.15 - 33.4: she dissolves: glock shimmer, wide pad swell, then calm
    for k, m in enumerate([76, 79, 83, 88, 91, 95, 100]):
        b.add("glock", I.glock(F(m), 0.42, _r()), 30.2 + k * 0.1, 0.5 - 0.15 * k)
    b.add("pad", I.pad([F(57), F(64), F(69), F(72)], 3.4, 0.45, _r(), att=0.5, rel=1.5), 30.15, 0.0)
    b.add("triangle", I.triangle(0.5, _r()), 30.3, 0.2)
    lull(b, 31.6, LULLABY[3:6], "musicbox", 0, 0.4, 0.1)
    b.cues.append((30.15, "fade: ascending glock shimmer + warm pad as she dissolves"))

    # ---- memory 33.4 - 38.6: slow, sad vibes + low bass (the drain)
    padc(b, 33.4, 5.4, CH_AM[1], 0.36)
    lull(b, 33.6, [(0, 2, 72), (2, 2, 69), (4, 2, 65), (6, 3, 64)], "vibes", -12, 0.5, -0.1)
    lull(b, 34.0, [(0, 2, 72), (2, 2, 69), (4, 2, 65), (6, 3, 64)], "musicbox", 0, 0.3, 0.2)
    bass(b, 33.6, 38.6, [CH_AM[1], CH_AM[3]], 0.3, every=4)
    b.cues.append((33.4, "memory: slow descending vibes + music box, deep bass"))

    # ---- morning 38.6 - 44.0: warm major lullaby, the toy placed at 40.1
    padc(b, 38.6, 5.5, CH_C[0], 0.34)
    bass(b, 38.7, 44.0, CH_C, 0.42)
    lull(b, 38.8, LULLABY_C, "vibes", 0, 0.52, -0.1)
    lull(b, 38.8, LULLABY_C, "glock", 0, 0.22, 0.3)
    b.add("musicbox", I.musicbox(F(88), 0.4, _r()), 40.1, 0.3)
    b.cues.append((38.6, "morning: C-major lullaby on vibes + glock, plucked bass; a music-box note as the toy is set down"))

    # ---- moral 44.0 - end: lullaby, resolution, final chord
    padc(b, 44.0, T.DUR - 44.0, CH_C[0], 0.4)
    lull(b, 44.2, LULLABY_C, "musicbox", 0, 0.45, 0.0)
    lull(b, 44.2, LULLABY_C, "vibes", -12, 0.32, -0.15)
    bass(b, 44.2, T.DUR - 0.8, CH_C, 0.34, every=4)
    for m in [60, 64, 67, 72]:
        b.add("glock", I.glock(F(m + 12), 0.35, _r()), T.DUR - 1.8, 0.2)
    b.cues.append((44.0, "moral: music-box + low vibes lullaby, final warm chord"))

    end = np.ones(N)
    a = ns(T.DUR - 1.2)
    end[a:] = np.linspace(1, 0, N - a) ** 1.5
    for k in b.tr:
        b.tr[k] *= end[None, :]
    return b


TARGET = {"pluck": -4.0, "vibes": -2.5, "glock": -7.0, "musicbox": -2.5, "pad": -4.5, "timpani": -7.0, "triangle": -14.0}


def render(b, ref=-20.0):
    hall = make_ir(1.5, 7, pre=0.018, hf=1.4)
    yard = make_ir(0.9, 8, pre=0.008, hf=1.8, early=[(0.11, 0.5, -0.4), (0.19, 0.35, 0.5)])
    dry = np.zeros((2, N))
    wet_hall = np.zeros((2, N))
    wet_yard = np.zeros((2, N))
    levels = {}
    for k, x in b.tr.items():
        if not np.any(x):
            continue
        L = integrated(x)
        g = dbg(ref + TARGET.get(k, -6) - L)
        levels[k] = (round(L, 1), round(ref + TARGET.get(k, -6), 1))
        x = x * g
        b.tr[k] = x
        dry += x
        if k == "whistle":
            wet_yard += 0.16 * x
        else:
            wet_hall += b.send[k] * x
    out = dry + 0.7 * convolve_st(wet_hall.mean(0), hall) + 0.8 * convolve_st(wet_yard.mean(0), yard)
    out = hp(out, 30, 2)
    return out, levels
