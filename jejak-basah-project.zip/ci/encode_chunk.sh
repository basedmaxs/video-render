#!/usr/bin/env bash
# Encode frames a..b (already in frames/) to chunks/chunk_NNN.mp4 with exactly the video settings of tools/finish.sh,
# so the stitched file needs no second encode.   bash ci/encode_chunk.sh <a> <b> <index>
set -e; A="$1"; B="$2"; I=$(printf %03d "$3"); mkdir -p chunks
ffmpeg -v error -y -framerate 30 -start_number "$A" -i frames/f%04d.jpg -frames:v $((B - A + 1)) \
  -c:v libx264 -preset slow -crf 17 -pix_fmt yuv420p -an "chunks/chunk_$I.mp4"
echo "chunks/chunk_$I.mp4: $(ffprobe -v error -count_frames -select_streams v:0 -show_entries stream=nb_read_frames -of csv=p=0 "chunks/chunk_$I.mp4") frames"
