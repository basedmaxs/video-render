# Jejak basah - render project

Vertical 1080x1920, 30 fps, 1442 frames (48.1 s). Picture and sound are finished; only the full frame render is left.
Plan: 15 jobs of 100 frames on GitHub Actions. Trial first: run with `total` = 60.

Own computer instead: Node 22.6+, ffmpeg, Python 3 (numpy/scipy/Pillow), Playwright + Chromium, then
`node build.mjs .` -> `node render.mjs frames "0-1441"` -> `bash finish.sh "Jejak basah"` (output in out/).
