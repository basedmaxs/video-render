import * as THREE from "three";
import { Batch, boxGeo, V, lam } from "./build.js";
import { beam, ctex, stoneHD, cobbleHD, grassHD, cloudHD } from "./paint.js";
import { LIGHTS, LOOK } from "./lights.js";
import { TONE, CHAR, twoTone, untone } from "./shade.js";
import { NOINK } from "./ink.js";
import { Pool, Actor, Fx, stage } from "./cast.js";
import { FPS, SHOTS, camAt, printsAt, flourAt, printX, printZ, DOOR_T0, DOOR_T1, DOOR_Z, TOY_T, N_PRINTS, PORCH_Y, ROOM_Y, SPOT, smooth } from "./story.js";
export const loadKit = ()=>Promise.resolve({});
const discTex = ()=>ctex("sunDisc", 128, 128, (g)=>{
        const gr = g.createRadialGradient(64, 64, 58, 64, 64, 64);
        gr.addColorStop(0, "rgba(255,255,255,1)");
        gr.addColorStop(1, "rgba(255,255,255,0)");
        g.fillStyle = gr;
        g.fillRect(0, 0, 128, 128);
    });
const haloTex = ()=>ctex("sunHalo", 256, 256, (g)=>{
        const im = g.createImageData(256, 256);
        for(let y = 0; y < 256; y++)for(let x = 0; x < 256; x++){
            const u = Math.hypot(x - 127.5, y - 127.5) / 128;
            const a = (0.55 * Math.exp(-((u / 0.25) ** 2)) + 0.35 * Math.exp(-((u / 0.6) ** 2))) * (1 - Math.min(1, Math.max(0, (u - 0.8) / 0.2)));
            const i = (y * 256 + x) * 4;
            im.data[i] = im.data[i + 1] = im.data[i + 2] = 255;
            im.data[i + 3] = Math.round(255 * Math.min(1, a));
        }
        g.putImageData(im, 0, 0);
    });
const SUN_SHOT = {
    8: {
        az: 22,
        el: 22
    },
    21: {
        az: 150,
        el: 10
    }
};
const glowTex = ()=>ctex("doorGlow", 256, 256, (g)=>{
        const gr = g.createLinearGradient(0, 128, 256, 128);
        gr.addColorStop(0, "rgba(255,214,140,0.95)");
        gr.addColorStop(0.6, "rgba(255,200,120,0.35)");
        gr.addColorStop(1, "rgba(255,200,120,0)");
        g.fillStyle = gr;
        g.fillRect(0, 0, 256, 256);
    });
function quadUp(x0, x1, z0, z1, u, v, y = 0) {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute([
        x0,
        y,
        z1,
        x1,
        y,
        z1,
        x1,
        y,
        z0,
        x0,
        y,
        z1,
        x1,
        y,
        z0,
        x0,
        y,
        z0
    ], 3));
    g.setAttribute("normal", new THREE.Float32BufferAttribute([
        0,
        1,
        0,
        0,
        1,
        0,
        0,
        1,
        0,
        0,
        1,
        0,
        0,
        1,
        0,
        0,
        1,
        0
    ], 3));
    g.setAttribute("uv", new THREE.Float32BufferAttribute([
        0,
        0,
        u,
        0,
        u,
        v,
        0,
        0,
        u,
        v,
        0,
        v
    ], 2));
    return g;
}
export class World {
    root = new THREE.Group();
    pool = new Pool();
    actors = [];
    fxs = [];
    hemi;
    sun;
    fill;
    sky;
    skyMat;
    fog = new THREE.Fog("#bccbec", 25, 420);
    sunDisc;
    sunHalo;
    sunCache = new Map();
    cloudMaps;
    clouds = [];
    door = new THREE.Group();
    glow;
    flour;
    toy = new THREE.Group();
    prints = [];
    printMat;
    frustum = new THREE.Frustum();
    m4 = new THREE.Matrix4();
    v = new THREE.Vector3();
    sph = new THREE.Sphere();
    constructor(kit){
        const R = this.root, M = {};
        this.skyMat = new THREE.ShaderMaterial({
            uniforms: {
                c0: {
                    value: new THREE.Color()
                },
                c1: {
                    value: new THREE.Color()
                },
                c2: {
                    value: new THREE.Color()
                },
                c3: {
                    value: new THREE.Color()
                },
                c4: {
                    value: new THREE.Color()
                },
                e: {
                    value: new THREE.Vector4()
                }
            },
            vertexShader: "varying vec3 vP; void main(){ vP = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }",
            fragmentShader: `uniform vec3 c0, c1, c2, c3, c4; uniform vec4 e; varying vec3 vP;
        void main(){ float el = asin(clamp(normalize(vP).y, -1.0, 1.0));
          vec3 c = mix(c0, c1, smoothstep(0.0, e.x, el));
          c = mix(c, c2, smoothstep(e.x, e.y, el));
          c = mix(c, c3, smoothstep(e.y, e.z, el));
          c = mix(c, c4, smoothstep(e.z, e.w, el));
          gl_FragColor = vec4(c, 1.0); }`,
            side: THREE.BackSide,
            depthWrite: false,
            fog: false
        });
        this.sky = new THREE.Mesh(new THREE.SphereGeometry(1100, 48, 24), this.skyMat);
        this.sky.renderOrder = -1;
        this.sky.frustumCulled = false;
        this.sky.layers.set(NOINK);
        R.add(this.sky);
        this.sunDisc = new THREE.Sprite(new THREE.SpriteMaterial({
            map: discTex(),
            color: new THREE.Color(6.0, 4.4, 2.4),
            fog: false,
            depthWrite: false
        }));
        this.sunHalo = new THREE.Sprite(new THREE.SpriteMaterial({
            map: haloTex(),
            color: new THREE.Color(1, 1, 1),
            fog: false,
            depthWrite: false,
            depthTest: true,
            transparent: true,
            blending: THREE.AdditiveBlending
        }));
        this.sunDisc.renderOrder = -0.5;
        this.sunHalo.renderOrder = 5;
        for (const m of [
            this.sunDisc,
            this.sunHalo
        ]){
            m.frustumCulled = false;
            m.layers.set(NOINK);
            R.add(m);
        }
        this.hemi = new THREE.HemisphereLight("#cfe6ff", "#6c5c8c", 1.1);
        this.sun = new THREE.DirectionalLight("#fff0d6", 2.6);
        this.sun.castShadow = true;
        this.sun.shadow.mapSize.set(4096, 4096);
        this.fill = new THREE.DirectionalLight("#9fb8ff", 0.35);
        R.add(this.hemi, this.sun, this.sun.target, this.fill, this.fill.target);
        this.cloudMaps = {
            day: [
                0,
                1,
                2,
                3
            ].map((k)=>cloudHD(k, LOOK.day.cloud)),
            golden: [
                0,
                1,
                2,
                3
            ].map((k)=>cloudHD(k, LOOK.golden.cloud)),
            night: [
                0,
                1,
                2,
                3
            ].map((k)=>cloudHD(k, LOOK.night.cloud))
        };
        for(let i = 0; i < 9; i++){
            const a = i / 9 * Math.PI * 2 + 0.3, d = 620 + i % 3 * 60;
            const m = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({
                map: this.cloudMaps.day[i % 4],
                color: new THREE.Color(1.1, 1.1, 1.1),
                transparent: true,
                depthWrite: false,
                fog: false
            }));
            const w = 130 + i % 4 * 30;
            m.position.set(Math.cos(a) * d, 120 + i % 4 * 38, Math.sin(a) * d);
            m.scale.set(w, w / 2, 1);
            m.layers.set(NOINK);
            this.clouds.push(m);
            R.add(m);
        }
        const C = (key, color)=>lam(key, ()=>({
                    color
                }));
        M.grass = lam("grassHD", ()=>({
                map: grassHD()
            }));
        M.paving = lam("cobbleHD", ()=>({
                map: cobbleHD()
            }));
        M.dark = C("dark", "#3a2f3d");
        M.inner = C("inner", "#44364a");
        M.wood = C("wood", "#7a5236");
        M.door = C("door", "#6b4a34");
        M.trim = C("trim", "#efe6d2");
        M.conc = C("conc", "#a3a29c");
        M.grate = C("grate", "#14171f");
        M.bar = C("bar", "#6a7385");
        M.shutter = C("shutter", "#5b7a6b");
        M.glass = C("glass", "#2a3350");
        M.leaf = C("leaf", "#5aa046");
        M.trunk = C("trunk", "#7a5236");
        M.iron = twoTone(new THREE.MeshPhongMaterial({
            color: "#3d414c",
            specular: "#8a8a8a",
            shininess: 60
        }), 0.15);
        M.toyBody = C("toyBody", "#b9824a");
        M.toyTop = C("toyTop", "#d6a066");
        M.toyWheel = C("toyWheel", "#c0453a");
        const roofM = (k, c)=>M[k] = C(k, c);
        const b = new Batch();
        const roof = (xa, xb, y, rise, za, zb)=>{
            const sh = new THREE.Shape();
            sh.moveTo(xa, y);
            sh.lineTo(xb, y);
            sh.lineTo((xa + xb) / 2, y + rise);
            sh.lineTo(xa, y);
            const e = new THREE.ExtrudeGeometry(sh, {
                depth: zb - za,
                bevelEnabled: false
            });
            e.translate(0, 0, za);
            return e;
        };
        const H = 3.2;
        const glass = [];
        b.add(quadUp(-900, 900, -900, 900, 450, 450, -0.02), M.grass);
        b.add(quadUp(-4.2, 5.0, -14.5, 11, 9, 24, 0.004), M.paving);
        b.add(boxGeo(V(-0.28, 0, -9), V(0.28, 0.025, 1)), M.conc);
        b.add(boxGeo(V(-0.26, 0, SPOT[2] - 0.38), V(0.26, 0.035, SPOT[2] + 0.38)), M.grate);
        for(let i = 0; i < 5; i++)b.add(boxGeo(V(-0.24, 0.02, SPOT[2] - 0.32 + i * 0.16), V(0.24, 0.04, SPOT[2] - 0.27 + i * 0.16)), M.bar);
        const plain = (side, z0, z1, wall, rf)=>{
            const x0 = side < 0 ? -8.2 : 5.0, x1 = side < 0 ? -4.2 : 9.2, fx = side < 0 ? -4.2 : 5.0;
            const wm = C("w" + wall, wall);
            roofM("r" + rf, rf);
            b.add(boxGeo(V(x0, 0, z0), V(x1, H, z1), 2), wm);
            b.add(roof(x0 - 0.3, x1 + 0.3, H, 1.5, z0 - 0.3, z1 + 0.3), M["r" + rf]);
            const zc = (z0 + z1) / 2, e = side < 0 ? 1 : -1;
            const dx0 = side < 0 ? fx : fx - 0.04, dx1 = side < 0 ? fx + 0.04 : fx;
            b.add(boxGeo(V(dx0, 0.25, zc - 0.5), V(dx1, 2.2, zc + 0.5)), M.door);
            for (const dz of [
                -(z1 - z0) * 0.3,
                (z1 - z0) * 0.3
            ]){
                glass.push([
                    fx + (side < 0 ? 0.03 : -0.03),
                    1.2,
                    2.3,
                    zc + dz - 0.4,
                    zc + dz + 0.4,
                    side < 0 ? Math.PI / 2 : -Math.PI / 2
                ]);
                b.add(boxGeo(V(dx0 - 0.01 * e, 1.15, zc + dz - 0.46), V(dx1, 1.2, zc + dz + 0.46)), M.trim);
            }
        };
        plain(-1, -14.5, -6.8, "#e6d5ae", "#a6503a");
        plain(-1, -1.2, 4.6, "#e7c6bd", "#8d4a3c");
        plain(-1, 5.0, 11, "#cfe0d0", "#a6503a");
        plain(1, -14.5, -3.4, "#d9e3ea", "#8d4a3c");
        plain(1, 3.0, 11, "#e9d2c4", "#a6503a");
        const tw = C("wT", "#a9d0c4");
        roofM("rT", "#a6503a");
        b.add(boxGeo(V(-4.45, 0, -6.2), V(-4.2, H, -4.55), 2), tw);
        b.add(boxGeo(V(-4.45, 0, -3.45), V(-4.2, H, -1.8), 2), tw);
        b.add(boxGeo(V(-4.45, 2.25, -4.55), V(-4.2, H, -3.45), 2), tw);
        b.add(boxGeo(V(-8.6, 0, -6.2), V(-4.45, PORCH_Y, -1.8)), M.wood);
        b.add(boxGeo(V(-8.6, 0, -6.3), V(-8.5, H, -1.7)), M.inner);
        for (const zz of [
            -6.3,
            -1.8
        ])b.add(boxGeo(V(-8.6, 0, zz), V(-4.45, H, zz + 0.1)), M.inner);
        b.add(boxGeo(V(-8.6, H - 0.1, -6.3), V(-4.45, H, -1.7)), M.inner);
        b.add(boxGeo(V(-4.7, 0, -6.2), V(-4.45, H, -4.55)), M.inner);
        b.add(boxGeo(V(-4.7, 0, -3.45), V(-4.45, H, -1.8)), M.inner);
        b.add(roof(-8.8, -3.9, H, 1.6, -6.5, -1.5), M.rT);
        b.add(boxGeo(V(-4.2, 0, -5.4), V(-3.1, PORCH_Y, -2.6), 1), M.conc);
        b.add(boxGeo(V(-3.1, 0, -4.9), V(-2.85, 0.12, -3.1)), M.conc);
        for (const pz of [
            -5.3,
            -2.7
        ])b.add(boxGeo(V(-3.25, PORCH_Y, pz - 0.07), V(-3.11, 2.65, pz + 0.07)), M.wood);
        b.add(boxGeo(V(-4.3, 2.65, -5.45), V(-3.0, 2.78, -2.55)), M.wood);
        b.add(boxGeo(V(-4.22, 0.5, -3.25), V(-4.15, 0.62, -2.9)), M.trim);
        for (const zc of [
            -5.4,
            -2.6
        ]){
            glass.push([
                -4.21,
                1.2,
                2.3,
                zc - 0.4,
                zc + 0.4,
                Math.PI / 2
            ]);
            b.add(boxGeo(V(-4.25, 1.15, zc - 0.46), V(-4.2, 1.2, zc + 0.46)), M.trim);
        }
        const hw = C("wH", "#f0e2b4");
        roofM("rH", "#8d4a3c");
        b.add(boxGeo(V(5.0, 0, -2.6), V(5.25, 1.2, 2.6), 2), hw);
        b.add(boxGeo(V(5.0, 2.35, -2.6), V(5.25, H, 2.6), 2), hw);
        b.add(boxGeo(V(5.0, 1.2, -2.6), V(5.25, 2.35, -0.7), 2), hw);
        b.add(boxGeo(V(5.0, 1.2, 0.7), V(5.25, 2.35, 2.6), 2), hw);
        b.add(boxGeo(V(5.25, 0, -2.6), V(8.6, ROOM_Y, 2.6)), M.wood);
        b.add(boxGeo(V(8.5, 0, -2.7), V(8.6, H, 2.7)), M.inner);
        for (const zz of [
            -2.7,
            2.6
        ])b.add(boxGeo(V(5.25, 0, zz), V(8.6, H, zz + 0.1)), M.inner);
        b.add(boxGeo(V(5.25, H - 0.1, -2.7), V(8.6, H, 2.7)), M.inner);
        b.add(roof(4.7, 9.1, H, 1.5, -2.9, 2.9), M.rH);
        b.add(boxGeo(V(4.93, 1.12, -0.78), V(5.05, 1.2, 0.78)), M.trim);
        b.add(boxGeo(V(4.93, 2.35, -0.78), V(5.05, 2.43, 0.78)), M.trim);
        b.add(boxGeo(V(4.93, 1.2, -0.78), V(5.05, 2.35, -0.7)), M.trim);
        b.add(boxGeo(V(4.93, 1.2, 0.7), V(5.05, 2.35, 0.78)), M.trim);
        b.add(boxGeo(V(4.95, 1.2, -1.45), V(5.0, 2.35, -0.78)), M.shutter);
        b.add(boxGeo(V(4.95, 1.2, 0.78), V(5.0, 2.35, 1.45)), M.shutter);
        b.add(boxGeo(V(4.95, 0.25, 1.6), V(5.0, 2.2, 2.4)), M.door);
        b.add(boxGeo(V(3.8, 0, -7.6), V(3.95, 6.0, -7.45)), M.wood);
        b.add(boxGeo(V(3.2, 5.6, -7.62), V(4.6, 5.7, -7.44)), M.wood);
        b.add(boxGeo(V(3.2, 4.0, -2.2), V(3.3, 4.1, -2.1)), M.iron);
        b.add(boxGeo(V(3.2, 0, -2.2), V(3.3, 4.0, -2.1)), M.iron);
        b.add(boxGeo(V(3.0, 4.0, -2.3), V(3.6, 4.12, -2.0)), M.iron);
        b.add(boxGeo(V(-9, 0, -15.2), V(9.4, 2.6, -14.5), 2), C("wFar", "#cfc4a8"));
        for(let i = 0; i < 14; i++){
            const tx = -26 + i * 4.2 + i * 37 % 5 * 0.3, tz = -18 - i * 53 % 9, th = 6 + i % 3;
            b.add(boxGeo(V(tx - 0.18, 0, tz - 0.18), V(tx + 0.18, th * 0.8, tz + 0.18)), M.trunk);
            b.add(new THREE.IcosahedronGeometry(th * 0.38, 1), M.leaf, new THREE.Matrix4().makeTranslation(tx, th * 0.9, tz));
        }
        for (const [px, pz] of [
            [
                -3.5,
                -6.6
            ],
            [
                4.4,
                -4.6
            ],
            [
                -3.6,
                -0.6
            ]
        ])b.add(new THREE.IcosahedronGeometry(0.32, 1), M.leaf, new THREE.Matrix4().makeTranslation(px, 0.36, pz));
        b.build(R);
        for (const [gx, y0, y1, z0, z1, ry] of glass){
            const o = new THREE.Mesh(new THREE.PlaneGeometry(z1 - z0, y1 - y0), new THREE.MeshBasicMaterial({
                color: 0x24355c
            }));
            o.position.set(gx, (y0 + y1) / 2, (z0 + z1) / 2);
            o.rotation.y = ry;
            o.layers.set(NOINK);
            R.add(o);
        }
        const lamp = (c)=>new THREE.MeshBasicMaterial({
                color: c
            });
        const q1 = (m, w2, h2, x, y, z, ry)=>{
            const o = new THREE.Mesh(new THREE.PlaneGeometry(w2, h2), m);
            o.position.set(x, y, z);
            o.rotation.y = ry;
            o.layers.set(NOINK);
            R.add(o);
            return o;
        };
        q1(lamp(0xe6a95c), 1.4, 1.1, -8.45, 1.7, DOOR_Z, Math.PI / 2);
        q1(lamp(0xf0c27a), 1.6, 1.0, 8.45, 1.9, 0, -Math.PI / 2);
        q1(lamp(0xffe3a8), 0.5, 0.14, 3.3, 4.02, -2.15, 0);
        q1(lamp(0xffe3a8), 0.5, 0.14, 3.3, 4.02, -2.15, Math.PI);
        const gm = new THREE.MeshBasicMaterial({
            map: glowTex(),
            transparent: true,
            opacity: 0,
            depthWrite: false
        });
        this.glow = new THREE.Mesh(new THREE.PlaneGeometry(3.4, 1.7), gm);
        this.glow.rotation.x = -Math.PI / 2;
        this.glow.position.set(-2.4, 0.03, DOOR_Z);
        this.glow.layers.set(NOINK);
        R.add(this.glow);
        this.door.position.set(-4.22, PORCH_Y, -4.55);
        const dm = new THREE.Mesh(boxGeo(V(-0.03, 0, 0), V(0.03, 2.05, 1.1)), M.door);
        this.door.add(dm);
        const kn = new THREE.Mesh(boxGeo(V(0.03, 1.0, 0.9), V(0.08, 1.06, 0.97)), M.trim);
        this.door.add(kn);
        R.add(this.door);
        this.printMat = new THREE.MeshBasicMaterial({
            color: 0x4c5568,
            transparent: true,
            opacity: 0.88,
            depthWrite: false,
            polygonOffset: true,
            polygonOffsetFactor: -3
        });
        for(let i = 0; i < N_PRINTS; i++){
            const g = new THREE.Group();
            const sole = new THREE.Mesh(new THREE.CircleGeometry(1, 20), this.printMat);
            sole.rotation.x = -Math.PI / 2;
            sole.scale.set(0.17, 0.1, 1);
            sole.position.set(0.07, 0, 0);
            const heel = new THREE.Mesh(new THREE.CircleGeometry(1, 16), this.printMat);
            heel.rotation.x = -Math.PI / 2;
            heel.scale.set(0.085, 0.07, 1);
            heel.position.set(-0.14, 0, 0);
            sole.layers.set(NOINK);
            heel.layers.set(NOINK);
            sole.renderOrder = 2;
            heel.renderOrder = 2;
            g.add(sole, heel);
            g.position.set(printX(i), 0.05, printZ(i));
            g.rotation.y = (i % 2 ? 1 : -1) * 0.12;
            g.visible = false;
            this.prints.push(g);
            R.add(g);
        }
        this.flour = new THREE.Mesh(new THREE.CircleGeometry(1.15, 28), new THREE.MeshBasicMaterial({
            color: 0xf1ede0,
            transparent: true,
            opacity: 0.96,
            depthWrite: false,
            polygonOffset: true,
            polygonOffsetFactor: -2
        }));
        this.flour.rotation.x = -Math.PI / 2;
        this.flour.scale.set(1.0, 0.82, 1);
        this.flour.position.set(SPOT[0], 0.045, SPOT[2]);
        this.flour.layers.set(NOINK);
        this.flour.renderOrder = 1;
        this.flour.visible = false;
        R.add(this.flour);
        const tb = new Batch();
        tb.add(boxGeo(V(-0.17, 0.04, -0.09), V(0.17, 0.16, 0.09)), M.toyBody);
        tb.add(boxGeo(V(-0.07, 0.16, -0.08), V(0.1, 0.25, 0.08)), M.toyTop);
        for (const [wx, wz] of [
            [
                -0.11,
                -0.1
            ],
            [
                0.11,
                -0.1
            ],
            [
                -0.11,
                0.1
            ],
            [
                0.11,
                0.1
            ]
        ])tb.add(boxGeo(V(wx - 0.045, 0, wz - 0.012), V(wx + 0.045, 0.09, wz + 0.012)), M.toyWheel);
        tb.build(this.toy);
        this.toy.position.set(SPOT[0] + 0.02, 0.03, SPOT[2]);
        this.toy.rotation.y = 0.5;
        this.toy.visible = false;
        R.add(this.toy);
    }
    shotSun(id, s, L) {
        let v = this.sunCache.get(id);
        if (v) return v;
        let fx = 0, fz = 0;
        for(let f = s.a; f < s.b; f += 3){
            const c = camAt(id, f), x = c.look[0] - c.pos[0], z = c.look[2] - c.pos[2], n = Math.hypot(x, z) || 1;
            fx += x / n;
            fz += z / n;
        }
        const n = Math.hypot(fx, fz) || 1;
        fx /= n;
        fz /= n;
        const ss = s;
        const az = THREE.MathUtils.degToRad(ss.sunAz ?? SUN_SHOT[id]?.az ?? L.az), el = THREE.MathUtils.degToRad(ss.sunEl ?? SUN_SHOT[id]?.el ?? L.el);
        const hx = fx * Math.cos(az) - fz * Math.sin(az), hz = fz * Math.cos(az) + fx * Math.sin(az);
        v = new THREE.Vector3(hx * Math.cos(el), Math.sin(el), hz * Math.cos(el)).normalize();
        this.sunCache.set(id, v);
        return v;
    }
    actor(i) {
        while(this.actors.length <= i)this.actors.push(new Actor(this.root));
        return this.actors[i];
    }
    fx(i) {
        while(this.fxs.length <= i)this.fxs.push(new Fx(this.root));
        return this.fxs[i];
    }
    update(id, f, cam, scene) {
        const t = f / FPS, s = SHOTS[id - 1], L = LIGHTS[s.light];
        const c = camAt(id, f);
        cam.position.set(...c.pos);
        cam.up.set(0, 1, 0);
        cam.lookAt(...c.look);
        cam.rotateZ(c.roll);
        cam.fov = c.fov;
        cam.near = 0.2;
        cam.far = 1500;
        cam.updateProjectionMatrix();
        cam.updateMatrixWorld();
        const focus = V(...c.look), dist = cam.position.distanceTo(focus);
        cam.layers.enable(NOINK);
        const K = LOOK[s.light], sunDir = this.shotSun(id, s, L);
        this.hemi.color.set(L.sky);
        this.hemi.groundColor.set(L.ground);
        this.hemi.intensity = L.hemiI;
        this.sun.color.set(L.sunCol);
        this.sun.intensity = L.sunI;
        let Rr = THREE.MathUtils.clamp(dist * 1.15 + 7, 12, 40);
        if (s.light === "golden") Rr = Math.max(Rr, 30);
        this.sun.position.copy(focus).addScaledVector(sunDir, 220);
        this.sun.target.position.copy(focus);
        const sc = this.sun.shadow.camera;
        sc.left = -Rr;
        sc.right = Rr;
        sc.top = Rr;
        sc.bottom = -Rr;
        sc.near = 20;
        sc.far = 480;
        sc.updateProjectionMatrix();
        this.sun.shadow.bias = L.bias;
        this.sun.shadow.normalBias = L.normalBias * (Rr / 12);
        this.fill.intensity = 0;
        TONE.uLitCol.value.set(...L.lit);
        TONE.uShadeCol.value.set(...L.shade);
        TONE.uShadeLift.value.set(...L.lift);
        TONE.uLambert.value = L.lambert;
        TONE.uSideK.value = L.sideK;
        TONE.uTerm.value = L.term;
        TONE.uBounce.value.set(...LOOK[s.light].bounce);
        TONE.uSat.value = LOOK[s.light].sat;
        CHAR.uCharTint.value.set(...L.charTint);
        CHAR.uCharShade.value = L.charShade;
        CHAR.uGrad.value = L.charGrad;
        CHAR.uBodyGrad.value = L.bodyGrad;
        CHAR.uSideTint.value.set(...L.sideTint);
        const su = this.skyMat.uniforms;
        K.sky.c.forEach((hx, i)=>untone(hx, su["c" + i].value));
        const e = K.sky.e.map((deg)=>THREE.MathUtils.degToRad(deg));
        su.e.value.set(e[1], e[2], e[3], e[4]);
        this.sky.position.copy(cam.position);
        untone(L.fog, this.fog.color);
        this.fog.near = L.fogNear;
        this.fog.far = L.fogFar;
        scene.fog = this.fog;
        scene.background = null;
        const showSun = s.light === "golden" || s.light === "night";
        const dA = s.light === "night" ? 2.4 : 1.7, hA = s.light === "night" ? 9 : 24;
        this.sunDisc.visible = this.sunHalo.visible = showSun;
        if (showSun) {
            this.sunDisc.position.copy(cam.position).addScaledVector(sunDir, 900);
            this.sunDisc.scale.setScalar(2 * 900 * Math.tan(THREE.MathUtils.degToRad(dA)));
            this.sunHalo.position.copy(this.sunDisc.position);
            this.sunHalo.scale.setScalar(2 * 900 * Math.tan(THREE.MathUtils.degToRad(hA)));
            this.sunHalo.material.color.set(L.sunDisc).multiplyScalar(1.3);
        }
        for(let i = 0; i < this.clouds.length; i++){
            const m = this.clouds[i], mat = m.material;
            m.lookAt(cam.position.x, m.position.y, cam.position.z);
            mat.map = this.cloudMaps[s.light][i % 4];
        }
        const open = t >= DOOR_T0 && t < 36.5 ? smooth((t - DOOR_T0) / (DOOR_T1 - DOOR_T0)) : 0;
        this.door.rotation.y = 1.75 * open;
        this.glow.material.opacity = 0.5 * open * (s.light === "night" ? 1 : 0);
        const np = printsAt(t);
        for(let i = 0; i < this.prints.length; i++)this.prints[i].visible = i < np;
        this.printMat.color.set(s.light === "night" ? "#0a1228" : "#4c5568");
        this.printMat.opacity = s.light === "night" ? 0.92 : 0.85;
        const fl = flourAt(t);
        this.flour.visible = fl > 0.01;
        this.flour.scale.set(fl, 0.82 * fl, 1);
        this.toy.visible = t >= TOY_T;
        const right = V(0, 0, 0).setFromMatrixColumn(cam.matrixWorld, 0);
        const st = stage(id, t, {
            pos: cam.position,
            right
        });
        this.frustum.setFromProjectionMatrix(this.m4.multiplyMatrices(cam.projectionMatrix, cam.matrixWorldInverse));
        const tint = s.light === "golden" ? "#ffcf9e" : s.light === "night" ? "#9fb4ea" : "#ffffff";
        let ai = 0;
        const used = [];
        for (const p of st.places){
            const sc2 = p.scale ?? 1;
            if (!this.frustum.intersectsSphere(this.sph.set(this.v.set(p.x, p.y + 1.1 * sc2, p.z), 3.5))) continue;
            const a = this.actor(ai++);
            const [w, hh2, k] = p.size ?? [
                300,
                500,
                0.5
            ];
            a.r = this.pool.req(p.key, w, hh2, k, p.draw);
            a.mesh.visible = true;
            a.mesh.position.set(p.x, p.y, p.z);
            a.mesh.rotation.set(0, p.yaw ?? Math.atan2(cam.position.x - p.x, cam.position.z - p.z), p.roll ?? 0);
            a.mesh.scale.set(p.mirror ? -sc2 : sc2, sc2, sc2);
            if (a.mat.emissiveMap) a.mat.emissive.set(tint);
            a.mesh.castShadow = L.actorShadow;
            const al = p.alpha;
            a.mat.transparent = al !== undefined;
            a.mat.opacity = al ?? 1;
            a.mat.alphaTest = al !== undefined ? 0.02 : 0.5;
            a.mat.depthWrite = al === undefined;
            used.push(a);
        }
        for(let i = ai; i < this.actors.length; i++)this.actors[i].mesh.visible = false;
        let fi = 0;
        const fused = [];
        for (const p of st.fx){
            if (!this.frustum.intersectsSphere(this.sph.set(this.v.set(p.x, p.y, p.z), Math.max(p.w, p.h)))) continue;
            const ef = this.fx(fi++);
            ef.r = this.pool.req(p.key, p.cw, p.ch, 1, p.draw);
            ef.use(!!p.soft);
            ef.mesh.visible = true;
            ef.mesh.position.set(p.x, p.y, p.z);
            if (p.flat) ef.mesh.rotation.set(-Math.PI / 2, 0, p.rot ?? 0);
            else {
                ef.mesh.quaternion.copy(cam.quaternion);
                ef.mesh.rotateZ(p.rot ?? 0);
            }
            ef.mesh.scale.set(p.w, p.h, 1);
            fused.push(ef);
        }
        for(let i = fi; i < this.fxs.length; i++)this.fxs[i].mesh.visible = false;
        this.pool.flush();
        for (const a of used)a.bind();
        for (const ef of fused)ef.bind();
        return focus;
    }
}
