export const FPS = 30;
export const TOTAL = 1442;
export const D0 = 0;
export const clamp01 = (x)=>Math.max(0, Math.min(1, x));
export const smooth = (x)=>{
    const u = clamp01(x);
    return u * u * (3 - 2 * u);
};
export const easeOut = (u)=>1 - (1 - clamp01(u)) ** 3;
export const HOUSE_X = -4.2;
export const DOOR_Z = -4.0;
export const PORCH_Y = 0.25;
export const SPOT = [
    0,
    0,
    -4.0
];
export const WIN_X = 5.0;
export const ROOM_Y = 0.3;
export const PEM_DAY = [
    1.3,
    0,
    -3.2
];
export const DOOR_T0 = 21.2, DOOR_T1 = 22.5;
export const FLOUR_T0 = 14.4, FLOUR_T1 = 15.7;
export const FADE_T0 = 30.2, FADE_T1 = 31.0;
export const WALK_T0 = 26.75, WALK_T1 = 29.2;
export const NIGHT_T = 18.2, MORNING_T = 38.66;
export const TOY_T = 40.1;
export const N_PRINTS = 11;
export const printX = (i)=>-3.0 + 0.30 * i;
export const printZ = (i)=>DOOR_Z + (i % 2 ? 0.13 : -0.13);
export const printT = (i)=>WALK_T0 + 0.25 + i * (WALK_T1 - WALK_T0 - 0.35) / (N_PRINTS - 1);
export const printsAt = (t)=>{
    if (t < NIGHT_T - 0.3) return N_PRINTS;
    if (t >= MORNING_T) return 0;
    let n = 0;
    for(let i = 0; i < N_PRINTS; i++)if (t >= printT(i)) n = i + 1;
    return n;
};
export const flourAt = (t)=>t < FLOUR_T0 ? 0 : t >= MORNING_T - 0.2 ? 0 : smooth((t - FLOUR_T0) / (FLOUR_T1 - FLOUR_T0));
const CUTS = [
    0,
    122,
    224,
    289,
    364,
    426,
    483,
    543,
    567,
    632,
    688,
    747,
    799,
    876,
    903,
    944,
    1001,
    1057,
    1157,
    1238,
    1319,
    TOTAL
];
const LIGHT_OF = (id)=>id >= 8 && id <= 18 ? "night" : id === 21 ? "golden" : "day";
export const SHOTS = CUTS.slice(0, -1).map((a, i)=>({
        id: i + 1,
        a,
        b: CUTS[i + 1],
        light: LIGHT_OF(i + 1)
    }));
export const XFADE = {
    8: 8,
    19: 8,
    21: 10
};
export const FLASH_AT = 99999;
export const shotAt = (f)=>SHOTS.find((s)=>f >= s.a && f < s.b) ?? SHOTS[SHOTS.length - 1];
export const layersAt = (f)=>{
    for (const s of SHOTS){
        const x = XFADE[s.id];
        if (x && f >= s.a - x / 2 && f < s.a + x / 2) return [
            {
                id: s.id - 1,
                alpha: 1
            },
            {
                id: s.id,
                alpha: (f - (s.a - x / 2) + 1) / (x + 1)
            }
        ];
    }
    return [
        {
            id: shotAt(f).id,
            alpha: 1
        }
    ];
};
export const glide = (u)=>{
    const x = clamp01(u);
    return x * x * x * (x * (6 * x - 15) + 10);
};
const mix = (a, b, k)=>({
        pos: a.pos.map((v, i)=>v + (b.pos[i] - v) * k),
        look: a.look.map((v, i)=>v + (b.look[i] - v) * k),
        fov: a.fov + (b.fov - a.fov) * k,
        roll: a.roll + (b.roll - a.roll) * k
    });
const full = (c)=>({
        fov: 40,
        roll: 0,
        ...c
    });
const run = (keys, f)=>{
    let cur = full(keys[0].s(f));
    for(let i = 1; i < keys.length; i++){
        const k = keys[i];
        if (f < k.f) break;
        cur = k.cut ? full(k.s(f)) : mix(cur, full(k.s(f)), glide((f - k.f) / (k.dur ?? 24)));
    }
    return cur;
};
const T = (f)=>f / FPS;
const pushK = (f, f0, rate, punch = 0, n = 35)=>{
    const x = Math.max(0, f - f0);
    let s = rate * x;
    if (punch > rate) for(let i = 0; i < Math.min(x, n); i++)s += (punch - rate) * Math.max(0, Math.min(1, (i + 0.5) / 8, (n - i - 0.5) / 8));
    return Math.exp(-s);
};
const dolly = (pos, look, k, rest = {})=>({
        pos: [
            look[0] + (pos[0] - look[0]) * k,
            look[1] + (pos[1] - look[1]) * k,
            look[2] + (pos[2] - look[2]) * k
        ],
        look,
        ...rest
    });
const E = 1.14;
const cu = (who, f0, dist = 2.1, rate = 0.0025, fov = 32, o = {})=>(f)=>{
        const x = who < 0 ? -0.5 : 0.5, sd = (o.side ?? 0.42) * who;
        return dolly([
            x + sd,
            E + 0.04,
            dist
        ], [
            x,
            E - 0.03,
            0
        ], pushK(f, f0, rate, o.punch ?? 0, o.n ?? 35), {
            fov,
            roll: o.roll ?? 0
        });
    };
const two = (f0, dist = 3.3, rate = 0.002, fov = 38, o = {})=>(f)=>dolly([
            o.x ?? 0.1,
            o.y ?? 1.25,
            dist
        ], [
            0,
            1.0,
            0
        ], pushK(f, f0, rate), {
            fov,
            roll: o.roll ?? 0
        });
const CAMS = {
    1: [
        {
            f: 0,
            s: (f)=>dolly([
                    2.4,
                    1.7,
                    -0.4
                ], [
                    -2.2,
                    0.25,
                    -4.0
                ], pushK(f, 0, 0.0025), {
                    fov: 46
                })
        },
        {
            f: 40,
            dur: 40,
            s: ()=>({
                    pos: [
                        4.4,
                        1.3,
                        2.5
                    ],
                    look: [
                        -3.0,
                        1.1,
                        -4.0
                    ],
                    fov: 50
                })
        },
        {
            f: 84,
            dur: 34,
            s: (f)=>dolly([
                    2.0,
                    0.9,
                    -1.2
                ], [
                    -3.6,
                    0.9,
                    -4.0
                ], pushK(f, 118, 0.003), {
                    fov: 40
                })
        }
    ],
    2: [
        {
            f: 122,
            s: (f)=>dolly([
                    1.0,
                    0.6,
                    -1.5
                ], [
                    -0.5,
                    4.6,
                    -6.0
                ], pushK(f, 122, 0.0015), {
                    fov: 46
                })
        },
        {
            f: 182,
            cut: true,
            s: (f)=>dolly([
                    0.8,
                    1.4,
                    8.5
                ], [
                    0.3,
                    1.3,
                    -8.0
                ], pushK(f, 182, 0.0015), {
                    fov: 44
                })
        }
    ],
    3: [
        {
            f: 224,
            s: (f)=>dolly([
                    3.8,
                    1.25,
                    -0.6
                ], [
                    1.3,
                    1.1,
                    -3.2
                ], pushK(f, 224, 0.0028), {
                    fov: 34
                })
        }
    ],
    4: [
        {
            f: 289,
            s: (f)=>dolly([
                    0.3,
                    0.6,
                    -2.8
                ], [
                    -2.2,
                    0.1,
                    -4.0
                ], pushK(f, 289, 0.002), {
                    fov: 40
                })
        },
        {
            f: 330,
            dur: 34,
            s: ()=>({
                    pos: [
                        -1.7,
                        0.7,
                        -3.0
                    ],
                    look: [
                        -3.8,
                        0.5,
                        -4.0
                    ],
                    fov: 40
                })
        }
    ],
    5: [
        {
            f: 364,
            s: ()=>({
                    pos: [
                        -3.3,
                        0.8,
                        -3.7
                    ],
                    look: [
                        0.5,
                        0.05,
                        -4.0
                    ],
                    fov: 40
                })
        },
        {
            f: 395,
            dur: 30,
            s: ()=>({
                    pos: [
                        -1.5,
                        0.5,
                        -3.8
                    ],
                    look: [
                        0.2,
                        0.05,
                        -4.0
                    ],
                    fov: 38
                })
        }
    ],
    6: [
        {
            f: 426,
            s: (f)=>dolly([
                    3.3,
                    1.1,
                    -1.4
                ], [
                    0.8,
                    0.8,
                    -3.4
                ], pushK(f, 426, 0.0028), {
                    fov: 34
                })
        }
    ],
    7: [
        {
            f: 483,
            s: (f)=>dolly([
                    2.7,
                    1.5,
                    -1.6
                ], [
                    1.3,
                    1.35,
                    -3.2
                ], pushK(f, 483, 0.003), {
                    fov: 30
                })
        }
    ],
    8: [
        {
            f: 543,
            s: (f)=>dolly([
                    4.0,
                    1.4,
                    0.5
                ], [
                    -3.5,
                    2.0,
                    -4.0
                ], pushK(f, 543, 0.003), {
                    fov: 48
                })
        }
    ],
    9: [
        {
            f: 567,
            s: (f)=>dolly([
                    2.5,
                    1.9,
                    0.9
                ], [
                    5.4,
                    1.95,
                    0.0
                ], pushK(f, 567, 0.0028), {
                    fov: 30
                })
        }
    ],
    10: [
        {
            f: 632,
            s: (f)=>dolly([
                    0.5,
                    1.3,
                    -1.0
                ], [
                    -4.1,
                    1.3,
                    -4.0
                ], pushK(f, 632, 0.003), {
                    fov: 34
                })
        }
    ],
    11: [
        {
            f: 688,
            s: (f)=>dolly([
                    -0.4,
                    1.1,
                    -1.9
                ], [
                    -3.9,
                    0.9,
                    -4.0
                ], pushK(f, 688, 0.002), {
                    fov: 32
                })
        }
    ],
    12: [
        {
            f: 747,
            s: (f)=>dolly([
                    -1.9,
                    0.45,
                    -2.6
                ], [
                    -3.5,
                    0.3,
                    -4.0
                ], pushK(f, 747, 0.003), {
                    fov: 36
                })
        }
    ],
    13: [
        {
            f: 799,
            s: ()=>({
                    pos: [
                        -1.8,
                        1.3,
                        4.5
                    ],
                    look: [
                        -2.8,
                        0.9,
                        -4.0
                    ],
                    fov: 46
                })
        },
        {
            f: 800,
            dur: 76,
            s: ()=>({
                    pos: [
                        -1.2,
                        1.3,
                        4.5
                    ],
                    look: [
                        -0.9,
                        0.9,
                        -4.0
                    ],
                    fov: 46
                })
        }
    ],
    14: [
        {
            f: 876,
            s: (f)=>dolly([
                    1.6,
                    1.0,
                    -2.0
                ], [
                    0.0,
                    0.75,
                    -4.0
                ], pushK(f, 876, 0.003), {
                    fov: 30
                })
        }
    ],
    15: [
        {
            f: 903,
            s: (f)=>dolly([
                    1.6,
                    1.0,
                    -2.0
                ], [
                    0.0,
                    0.75,
                    -4.0
                ], pushK(f, 903, 0.0035), {
                    fov: 30
                })
        }
    ],
    16: [
        {
            f: 944,
            s: (f)=>dolly([
                    0.6,
                    0.45,
                    -3.0
                ], [
                    -0.1,
                    0.02,
                    -4.0
                ], pushK(f, 944, 0.002), {
                    fov: 36
                })
        }
    ],
    17: [
        {
            f: 1001,
            s: (f)=>dolly([
                    2.5,
                    2.0,
                    0.9
                ], [
                    5.2,
                    2.25,
                    -0.2
                ], pushK(f, 1001, 0.002), {
                    fov: 38
                })
        }
    ],
    18: [
        {
            f: 1057,
            s: (f)=>dolly([
                    1.5,
                    0.9,
                    -2.0
                ], [
                    0.0,
                    0.05,
                    -4.0
                ], pushK(f, 1057, 0.004), {
                    fov: 36
                })
        }
    ],
    19: [
        {
            f: 1157,
            s: (f)=>dolly([
                    3.0,
                    1.2,
                    -1.2
                ], [
                    0.9,
                    1.0,
                    -3.2
                ], pushK(f, 1157, 0.003), {
                    fov: 34
                })
        },
        {
            f: 1200,
            cut: true,
            s: (f)=>dolly([
                    1.3,
                    0.5,
                    -2.6
                ], [
                    0.0,
                    0.1,
                    -4.0
                ], pushK(f, 1200, 0.003), {
                    fov: 34
                })
        }
    ],
    20: [
        {
            f: 1238,
            s: ()=>({
                    pos: [
                        4.4,
                        1.4,
                        2.0
                    ],
                    look: [
                        -3.0,
                        1.2,
                        -4.0
                    ],
                    fov: 50
                })
        },
        {
            f: 1240,
            dur: 78,
            s: ()=>({
                    pos: [
                        3.4,
                        1.2,
                        0.5
                    ],
                    look: [
                        -2.2,
                        1.0,
                        -4.0
                    ],
                    fov: 46
                })
        }
    ],
    21: [
        {
            f: 1319,
            s: (f)=>dolly([
                    3.6,
                    1.1,
                    -1.0
                ], [
                    -1.0,
                    1.0,
                    -3.8
                ], pushK(f, 1319, 0.002), {
                    fov: 40
                })
        },
        {
            f: 1370,
            dur: 70,
            s: ()=>({
                    pos: [
                        4.4,
                        1.5,
                        2.5
                    ],
                    look: [
                        -2.0,
                        1.0,
                        -4.0
                    ],
                    fov: 48
                })
        }
    ]
};
const KICKS = [];
export const kickAt = (t)=>{
    let a = 0;
    for (const [t0, g] of KICKS){
        const n = Math.floor((t - t0) * FPS + 1e-6);
        if (n >= 0 && n < 7) a += g * (n % 2 ? -1 : 1) * (1 - n / 7) ** 1.5;
    }
    return a;
};
export const camAt = (id, f)=>{
    const c = run(CAMS[id], f), a = kickAt(T(f));
    if (!a) return c;
    const d = [
        c.look[0] - c.pos[0],
        c.look[1] - c.pos[1],
        c.look[2] - c.pos[2]
    ];
    const L = Math.hypot(...d), h = Math.hypot(d[0], d[2]) || 1;
    const m = 3 / 640 * Math.tan(c.fov * Math.PI / 360) * L * a;
    return {
        ...c,
        look: [
            c.look[0] - d[2] / h * m,
            c.look[1] + 0.6 * m,
            c.look[2] + d[0] / h * m
        ],
        roll: c.roll + a * 0.004
    };
};
export const keyEnd = (id, f)=>{
    let e = 0;
    for (const k of CAMS[id])if (f >= k.f) e = k.f + (k.cut ? 0 : k.dur ?? 24);
    return Math.max(f, e);
};
const face = (x)=>()=>[
            x,
            E,
            0
        ];
const at = (x, y, z)=>()=>[
            x,
            y,
            z
        ];
export const DOF = [
    {
        f: 0,
        cInf: 9,
        focus: at(-1.5, 0.1, -3.9)
    },
    {
        f: 40,
        dur: 40,
        cInf: 0
    },
    {
        f: 84,
        cInf: 8,
        focus: at(-3.6, 0.9, -4.0)
    },
    {
        f: 122,
        cInf: 0
    },
    {
        f: 182,
        cInf: 0
    },
    {
        f: 224,
        cInf: 10,
        focus: at(1.3, 1.1, -3.2)
    },
    {
        f: 289,
        cInf: 11,
        focus: at(-2.4, 0.1, -3.95)
    },
    {
        f: 364,
        cInf: 11,
        focus: at(-1.0, 0.05, -4.0)
    },
    {
        f: 426,
        cInf: 10,
        focus: at(0.9, 0.9, -3.3)
    },
    {
        f: 483,
        cInf: 12,
        focus: at(1.3, 1.35, -3.2)
    },
    {
        f: 543,
        cInf: 0
    },
    {
        f: 567,
        cInf: 12,
        focus: at(5.4, 1.95, 0.0)
    },
    {
        f: 632,
        cInf: 8,
        focus: at(-4.1, 1.2, -4.0)
    },
    {
        f: 688,
        cInf: 11,
        focus: at(-3.9, 0.9, -4.0)
    },
    {
        f: 747,
        cInf: 12,
        focus: at(-3.5, 0.3, -4.0)
    },
    {
        f: 799,
        cInf: 0
    },
    {
        f: 876,
        cInf: 12,
        focus: at(0.0, 0.75, -4.0)
    },
    {
        f: 944,
        cInf: 11,
        focus: at(-0.1, 0.02, -4.0)
    },
    {
        f: 1001,
        cInf: 12,
        focus: at(5.4, 1.95, 0.0)
    },
    {
        f: 1057,
        cInf: 11,
        focus: at(0.0, 0.05, -4.0)
    },
    {
        f: 1157,
        cInf: 10,
        focus: at(0.9, 1.0, -3.2)
    },
    {
        f: 1200,
        cInf: 11,
        focus: at(0.0, 0.1, -4.0)
    },
    {
        f: 1238,
        cInf: 0
    },
    {
        f: 1319,
        cInf: 8,
        focus: at(-3.2, 0.7, -4.0)
    },
    {
        f: 1370,
        dur: 70,
        cInf: 0
    }
];
export const dofAt = (f)=>{
    let i = 0;
    while(i + 1 < DOF.length && f >= DOF[i + 1].f)i++;
    const d = DOF[i], p = DOF[Math.max(0, i - 1)];
    const k = d.dur ? Math.min(1, (f - d.f) / d.dur) : 1;
    return {
        cInf: p.cInf + (d.cInf - p.cInf) * k,
        focus: d.focus
    };
};
export const focusAt = (id, f)=>{
    const d = dofAt(f);
    return d.focus ? d.focus(f) : camAt(id, f).look;
};
