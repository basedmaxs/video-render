// Our cast as lit flat sprites in the 3D world. Each frame every character asks for a drawing (a key + a draw call);
// the pool keeps one canvas per distinct drawing, so soldiers marching in step share canvases (7 head shapes x 4
// outfits). Characters are yaw-only billboards shaded by cardShade() (scene tint, bright floor, side gradient toward
// the sun, painted crescent in the drawing); standing ones get a soft multiply contact blob. Effects are unlit cards.
// Cards, effects and blobs live on the NOINK layer so the world ink pass never outlines their quads.
import * as THREE from "three";
import {
  Pen, bodyFront, bodySide, LELAKI, ANAK, fxPuff, fxStars, fxSweat, fxFlour, fxRipple, fxMemory, fxQuestion, fxContact, fxShadow,
  Outfit, Expr, FrontOpts, SideOpts, Prop,
} from "./toon";
import { FPS, V3, SHOTS, smooth, clamp01, easeOut, DOOR_T0, DOOR_T1, FLOUR_T0, FLOUR_T1, FADE_T0, FADE_T1, WALK_T0, WALK_T1,
  NIGHT_T, MORNING_T, HOUSE_X, DOOR_Z, PORCH_Y, SPOT, WIN_X, ROOM_Y, PEM_DAY } from "./story";
import { LIGHTS } from "./lights";
import { NOINK } from "./ink";
import { cardShade, blobMaterial, CARD_K } from "./cardshade";

// ---------------- canvas pool ----------------
type Entry = { cv: HTMLCanvasElement; tex: THREE.CanvasTexture; w: number; h: number };
export type Req = { key: string; w: number; h: number; k: number; draw: (p: Pen) => void; tex?: THREE.CanvasTexture };
const makeEntry = (w: number, h: number): Entry => {
  const cv = document.createElement("canvas");
  cv.width = w; cv.height = h;
  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = 8;
  return { cv, tex, w, h };
};
export class Pool {
  private live = new Map<string, Entry>();
  private free: Entry[] = [];
  private reqs: Req[] = [];
  req(key: string, w: number, h: number, k: number, draw: (p: Pen) => void) {
    const r: Req = { key: `${w}x${h}|${key}`, w, h, k, draw };
    this.reqs.push(r);
    return r;
  }
  flush() {
    const want = new Map<string, Req[]>();
    for (const r of this.reqs) { const l = want.get(r.key); if (l) l.push(r); else want.set(r.key, [r]); }
    for (const [key, e] of this.live) if (!want.has(key)) { this.live.delete(key); this.free.push(e); }
    for (const [key, rs] of want) {
      let e = this.live.get(key);
      if (!e) {
        const r = rs[0], i = this.free.findIndex((x) => x.w === r.w && x.h === r.h);
        e = i >= 0 ? this.free.splice(i, 1)[0] : makeEntry(r.w, r.h);
        const g = e.cv.getContext("2d")!;
        g.setTransform(1, 0, 0, 1, 0, 0); g.clearRect(0, 0, e.w, e.h); g.setTransform(r.k, 0, 0, r.k, 0, 0);
        r.draw(new Pen(g));
        e.tex.needsUpdate = true;
        this.live.set(key, e);
      }
      for (const r of rs) r.tex = e.tex;
    }
    this.reqs = [];
  }
}

// ---------------- sprite meshes ----------------
const blank = (() => { const c = document.createElement("canvas"); c.width = c.height = 2; return new THREE.CanvasTexture(c); })();
export const SU = 0.00216; // metres per design unit: 1000 units = 2.16 m
export const SU_SWING = 2.3 / 1830; // swing canvas: rope of 1830 units = 2.3 m
const BODY = (() => { const g = new THREE.PlaneGeometry(600 * SU, 1000 * SU); g.translate(0, (975 - 500) * SU, 0); return g; })();
const CARD = new THREE.PlaneGeometry(1, 1);
/** world roots that hold actors (to find the scene's sun when world.ts does not pass it) */
const ROOTS = new Set<THREE.Object3D>();

/** lit flat character: cardShade() material, receives shadows (dims to the bright floor only), casts its silhouette
 *  when world.ts says so (golden). Drawn after the contact blobs (renderOrder 1). */
export class Actor {
  mesh: THREE.Mesh; mat: THREE.MeshLambertMaterial; dmat: THREE.MeshDepthMaterial; r: Req | null = null;
  constructor(parent: THREE.Object3D, geo: THREE.BufferGeometry = BODY) {
    this.mat = cardShade(new THREE.MeshLambertMaterial({ map: blank, alphaTest: 0.5, side: THREE.DoubleSide }));
    this.mat.alphaToCoverage = false; // A2C + MSAA left 1 px sky-depth seams on blurred far cards (POST)
    this.dmat = new THREE.MeshDepthMaterial({ depthPacking: THREE.RGBADepthPacking, map: blank, alphaTest: 0.5, side: THREE.DoubleSide });
    this.mesh = new THREE.Mesh(geo, this.mat);
    this.mesh.customDepthMaterial = this.dmat;
    // rim width is in output pixels: tell the card shader the render height (1920 = 1080 x 1920 frame)
    this.mesh.onBeforeRender = (r) => { const rt = r.getRenderTarget(); CARD_K.uPx.value = (rt ? rt.height : r.domElement.height) / 1920; };
    this.mesh.castShadow = false; this.mesh.receiveShadow = true; this.mesh.visible = false;
    this.mesh.rotation.order = "YXZ"; this.mesh.renderOrder = 1; this.mesh.layers.set(NOINK);
    parent.add(this.mesh);
    ROOTS.add(parent);
  }
  bind() { const t = this.r?.tex; if (t) { this.mat.map = t; this.dmat.map = t; } }
}
/** unlit effect card: hard cut-out (ink drawings), soft see-through (dust, mist) or a multiply ground blob */
export class Fx {
  mesh: THREE.Mesh; mat: THREE.MeshBasicMaterial; soft: THREE.MeshBasicMaterial; blob: THREE.MeshBasicMaterial; r: Req | null = null;
  constructor(parent: THREE.Object3D) {
    this.mat = new THREE.MeshBasicMaterial({ map: blank, alphaTest: 0.5, side: THREE.DoubleSide });
    this.mat.alphaToCoverage = false; // A2C + MSAA left 1 px sky-depth seams on blurred far cards (POST)
    this.soft = new THREE.MeshBasicMaterial({ map: blank, transparent: true, depthWrite: false, side: THREE.DoubleSide });
    this.blob = blobMaterial(blank);
    this.mesh = new THREE.Mesh(CARD, this.mat);
    this.mesh.visible = false; this.mesh.layers.set(NOINK);
    parent.add(this.mesh);
  }
  use(soft: boolean) { this.mesh.material = soft ? this.soft : this.mat; }
  bind() {
    const t = this.r?.tex;
    if (!t) return;
    if (this.r!.key.includes("|blob|")) {
      // no mipmaps: at grazing views the mip chain averages the blob with its white surround and it fades out
      if (t.generateMipmaps) { t.generateMipmaps = false; t.minFilter = THREE.LinearFilter; t.needsUpdate = true; }
      this.blob.map = t; this.mesh.material = this.blob; this.mesh.renderOrder = 0.5;
    }
    else { this.mat.map = t; this.soft.map = t; this.mesh.renderOrder = 0; }
  }
}

// ---------------- placements ----------------
export type Place = {
  key: string; draw: (p: Pen) => void; x: number; y: number; z: number;
  scale?: number; mirror?: boolean; yaw?: number; geo?: "body" | "swing"; roll?: number; size?: [number, number, number]; alpha?: number;
};
export type FxPlace = { key: string; cw: number; ch: number; draw: (p: Pen) => void; x: number; y: number; z: number; w: number; h: number; flat?: boolean; rot?: number; soft?: boolean };
/** sun = world direction TOWARD the sun (optional: when absent the scene's shadow-casting light is used) */
export type CamInfo = { pos: THREE.Vector3; right: THREE.Vector3; sun?: THREE.Vector3 };

const hh = (i: number, s = 0) => { const v = Math.sin(i * 127.1 + s * 311.7) * 43758.5453; return v - Math.floor(v); };
const q = (v: number, n = 120) => Math.round(v * n) / n;
/** head-shape seed: 7 shapes, so marching soldiers in step still share canvases */
const seedOf = (i: number) => ((i * 5 + 3) % 7) + 1;
/** drawing resolution by distance: [canvas w, h, scale from the 600 x 1000 design]; sized for the 1440 x 2560 final */
const tier = (d: number): [number, number, number] =>
  d < 3.2 ? [1800, 3000, 3.0] : d < 6.5 ? [1080, 1800, 1.8] : d < 16 ? [480, 800, 0.8] : [240, 400, 0.4];

// ---------------- light ----------------
const SUN = new THREE.Vector3(0.5, 0.75, -0.4).normalize();
const tmp = new THREE.Vector3();
let LNAME: "day" | "golden" | "night" = "day";
const sunOf = (root: THREE.Object3D) => {
  let s: THREE.DirectionalLight | null = null;
  root.traverse((o) => { if (!s && o instanceof THREE.DirectionalLight && o.castShadow) s = o; });
  return s as THREE.DirectionalLight | null;
};
/** the sun of the world that is calling: the attached root whose sun target sits on this camera's view axis */
const findSun = (cam: CamInfo, out: THREE.Vector3) => {
  if (cam.sun) return out.copy(cam.sun).normalize();
  let best: THREE.DirectionalLight | null = null, err = Infinity;
  for (const r of ROOTS) {
    if (!r.parent) continue;
    const s = sunOf(r);
    if (!s) continue;
    const d = tmp.copy(s.target.position).sub(cam.pos), e = Math.abs(d.dot(cam.right)) / (d.length() || 1);
    if (e < err) { err = e; best = s; }
  }
  return best ? out.copy(best.position).sub(best.target.position).normalize() : out;
};
/** canvas angle the sun comes FROM on an upright card facing the camera, in 45-degree steps (small texture cache) */
const light2D = (cam: CamInfo, mirror: boolean) => {
  const sx = SUN.dot(cam.right) * (mirror ? -1 : 1), sy = -SUN.y;
  return Math.round(Math.atan2(sy, sx) / (Math.PI / 4)) * (Math.PI / 4);
};

/** front / side view and mirroring for someone at (x, z) walking along (dx, dz); fs = foreshortening of the walk */
const viewOf = (cam: CamInfo, x: number, z: number, dx: number, dz: number) => {
  const tx = cam.pos.x - x, tz = cam.pos.z - z, tl = Math.hypot(tx, tz) || 1;
  const c = (tx * dx + tz * dz) / tl;
  return { side: c < 0.57, mirror: dx * cam.right.x + dz * cam.right.z < 0, fs: Math.round(Math.sqrt(Math.max(0, 1 - c * c)) * 20) / 20 };
};

// ---------------- life: blinks and reaction timing ----------------
/** reference expression and action changes land 0-3 f before the word onset */
const LEAD = 2 / FPS;
/** eyelid 0 open .. 1 shut. Reference: gaps 0.5-2.3 s, 4-frame blink half / shut / shut / half, plus a blink across
 *  every expression swap (the shut frames hide the swap) */
const LID = [0.5, 1, 1, 0.5];
const SWAPS: Record<number, number[]> = {};
const lidAt = (t: number, i: number, swaps: number[] = []) => {
  const f = Math.round(t * FPS);
  for (const ts of swaps) { const k = f - Math.round((ts - LEAD) * FPS) + 1; if (k >= 0 && k < 4) return LID[k]; }
  let s = Math.round(-60 * hh(i, 9));
  for (let n = 0; s <= f && n < 400; n++) {
    const k = f - s;
    if (k >= 0 && k < 4) return LID[k];
    s += Math.round(15 + 54 * hh(i * 31 + n, 13)); // next blink 0.5-2.3 s later
  }
  return 0;
};
const fkey = (o: object) => JSON.stringify(o, (_k, v) => (typeof v === "number" ? q(v) : v));

type Who = { i: number; o: Outfit; okey: string };
/** one character drawing in the 600 x 1000 design space, sized by distance, lit from the scene's sun */
const person = (cam: CamInfo, who: Who, x: number, y: number, z: number, view: { side: boolean; mirror: boolean }, fo: FrontOpts, so: SideOpts, scale = 1): Place & { tierKey: string } => {
  const d = cam.pos.distanceTo(tmp.set(x, y + 1.2, z)) / scale;
  const [w, h, k] = tier(d);
  const mirror = view.side && view.mirror, light = light2D(cam, mirror), seed = seedOf(who.i);
  const f2: FrontOpts = { ...fo, light, seed }, s2: SideOpts = { ...so, light, seed };
  const key = view.side ? `S|${who.okey}|${fkey(s2)}` : `F|${who.okey}|${fkey(f2)}`;
  return {
    key, x, y, z, scale, mirror, tierKey: `${w}`,
    draw: (p) => (view.side ? bodySide(p, who.o, s2) : bodyFront(p, who.o, f2)),
    size: [w, h, k],
  };
};

/** ground shadow under a standing / sitting card (review rounds 2-4), multiply, blue-violet: a TIGHT contact pool right under
 *  the feet (~.5 on screen at the core) so nobody floats, plus by day (cards cast no real shadow) a lighter soft tail
 *  stretched AWAY from the sun, length ~1.6 m / tan(sun elevation), capped. Golden: world.ts casts real card shadows. */
const CONTACT: Record<"day" | "golden" | "night", [number, number, number]> = { day: [0.2, 0.21, 0.33], golden: [0.24, 0.2, 0.33], night: [0.3, 0.32, 0.5] };
const TAIL: [number, number, number] = [0.42, 0.44, 0.62];
const toSrgb = (v: number) => { const c = clamp01(v); return c <= 0.0031308 ? 12.92 * c : 1.055 * c ** (1 / 2.4) - 0.055; };
const hexOf = (c: [number, number, number], k: number) => "#" + c.map((v) => Math.round(255 * toSrgb(1 - (1 - v) * k)).toString(16).padStart(2, "0")).join("");
const blob = (out: Stage, x: number, y: number, z: number, sc = 1, k = 1) => {
  const hl = Math.hypot(SUN.x, SUN.z) || 1, ox = -SUN.x / hl, oz = -SUN.z / hl, rot = Math.atan2(-ox, -oz);
  if (LNAME === "day") {
    const el = Math.asin(Math.min(0.99, Math.max(0.1, SUN.y)));
    const len = Math.min(2.4, Math.max(0.5, 1.6 / Math.tan(el))) * sc, h = len + 0.55 * sc, c = 0.3 * h; // feet at v = .2 of the card
    const tc = hexOf(TAIL, k);
    out.fx.push({ key: `blob|shadow|${tc}`, cw: 128, ch: 256, draw: (p) => fxShadow(p, tc), x: x + ox * c, y: y + 0.018, z: z + oz * c,
      w: 0.72 * sc, h, flat: true, rot });
  }
  const cc = hexOf(CONTACT[LNAME], k);
  out.fx.push({ key: `blob|contact|${cc}`, cw: 128, ch: 128, draw: (p) => fxContact(p, cc), x: x + ox * 0.03 * sc, y: y + 0.022, z: z + oz * 0.03 * sc,
    w: 0.52 * sc, h: 0.4 * sc, flat: true, rot });
};

// ---------------- the cast of the gang ----------------
export type Stage = { places: Place[]; fx: FxPlace[] };
export { FPS };

type Pose = { expr: Expr; prop?: Prop; look?: number; facing?: -1 | 0 | 1; tilt?: number; gside?: number };
const pick = (t: number, list: [number, Pose][]): Pose => {
  let r = list[0][1];
  for (const [t0, p] of list) if (t + LEAD >= t0) r = p; else break;
  return r;
};

// the young man: watches the prints, points, scratches his head, sprinkles flour, waits, peeks, remembers, leaves a toy
const PEM: [number, Pose][] = [
  [0, { expr: "neutral" }],
  [7.4, { expr: "stern" }],
  [9.7, { expr: "stern", prop: "point" }],
  [11.6, { expr: "nervous" }],
  [12.2, { expr: "nervous", prop: "head" }],
  [13.8, { expr: "neutral" }],
  [14.3, { expr: "smile", prop: "palm" }],
  [15.7, { expr: "smile" }],
  [16.1, { expr: "stern", look: 1 }],
  [18.9, { expr: "nervous" }],               // at the window
  [21.2, { expr: "shock" }],
  [23.0, { expr: "shock" }],
  [25.0, { expr: "nervous" }],
  [29.2, { expr: "shock" }],
  [31.4, { expr: "dazed" }],
  [33.4, { expr: "pained" }],                // remembers
  [35.8, { expr: "pained" }],
  [38.66, { expr: "smile_closed", prop: "toy" }],
  [40.0, { expr: "smile_closed" }],
  [41.4, { expr: "relief" }],
  [44.0, { expr: "smile_closed" }],
];

type Kid = { x: number; y: number; z: number; mode: "stand" | "stroll" | "sit"; phase: number; alpha: number; moving: boolean; expr: Expr; look: number; dx: number } | null;
/** the child: absent until the door opens, steps out, stands, walks to the yard centre, turns, fades; finally rests on the porch */
const kid = (t: number): Kid => {
  if (t >= 22.8 && t < 24.7) {
    const u = (t - 22.8) / 1.9, x = -5.6 + 2.0 * u;
    return { x, y: PORCH_Y, z: DOOR_Z, mode: "stroll", phase: (t * 1.6) % 1, alpha: 1, moving: true, expr: "neutral", look: 0, dx: 1 };
  }
  if (t >= 24.7 && t < WALK_T0) return { x: -3.6, y: PORCH_Y, z: DOOR_Z, mode: "stand", phase: 0, alpha: 1, moving: false, expr: "neutral", look: 0, dx: 1 };
  if (t >= WALK_T0 && t < WALK_T1) {
    const u = (t - WALK_T0) / (WALK_T1 - WALK_T0), x = -3.6 + 3.6 * u;
    const y = PORCH_Y * (1 - smooth((x + 3.4) / 0.3));
    return { x, y, z: DOOR_Z, mode: "stroll", phase: (t * 2.0) % 1, alpha: 1, moving: true, expr: "neutral", look: 0, dx: 1 };
  }
  if (t >= WALK_T1 && t < FADE_T1) {
    const a = 1 - smooth((t - FADE_T0) / (FADE_T1 - FADE_T0));
    return { x: 0, y: 0, z: DOOR_Z, mode: "stand", phase: 0, alpha: a, moving: false, expr: t > 29.4 ? "smile_closed" : "neutral", look: 0, dx: 1 };
  }
  if (t >= 44.3) return { x: -3.45, y: PORCH_Y, z: DOOR_Z + 0.05, mode: "sit", phase: 0, alpha: 0.72 * smooth((t - 44.3) / 1.2), moving: false, expr: "smile_closed", look: 0, dx: 1 };
  return null;
};

const FRONT = { side: false, mirror: false };
const mainChars = (t: number, cam: CamInfo, out: Stage) => {
  const pp = pick(t, PEM);
  // the young man
  let pos: V3 | null = null, sit = false;
  if (t >= 7.2 && t < NIGHT_T - 0.4) pos = PEM_DAY;
  else if (t >= NIGHT_T - 0.4 && t < MORNING_T - 0.2) pos = [WIN_X + 0.5, ROOM_Y, 0.0];
  else if (t >= MORNING_T - 0.2) pos = PEM_DAY;
  if (pos) {
    const fo: FrontOpts = { mode: sit ? "sit" : "stand", expr: pp.expr, prop: pp.prop ?? null, look: pp.look ?? 0, facing: pp.facing ?? 0, blink: lidAt(t, 1), headTilt: pp.tilt ?? 0, gside: pp.gside ?? 1 };
    out.places.push(person(cam, { i: 1, o: LELAKI, okey: "lk" }, pos[0], pos[1], pos[2], FRONT, fo, {}));
    blob(out, pos[0], pos[1], pos[2], 1.1);
  }
  // the child
  const k = kid(t);
  if (k && k.alpha > 0.01) {
    const so: SideOpts = { mode: k.moving ? "march" : "stand", phase: k.phase, expr: k.expr, stomp: 0.35, stride: 0.55, blink: lidAt(t, 2) };
    const view = k.moving ? viewOf(cam, k.x, k.z, k.dx, 0) : FRONT;
    if (k.moving) so.stride = 0.55 * (view as { fs?: number }).fs!;
    const fo: FrontOpts = { mode: k.mode, phase: k.phase, expr: k.expr, look: k.look, blink: lidAt(t, 2) };
    const p = person(cam, { i: 2, o: ANAK, okey: "anak" }, k.x, k.y, k.z, view, fo, so);
    if (k.alpha < 0.99) p.alpha = k.alpha;
    out.places.push(p);
    if (k.alpha > 0.5) blob(out, k.x, 0, k.z, 0.85);
  }
};

// ---- effects ----
const hand = (t: number): V3 => {              // the sprinkling hand (young man, day)
  const u = clamp01((t - FLOUR_T0) / (FLOUR_T1 - FLOUR_T0));
  return [PEM_DAY[0] - 0.55 + 0.35 * Math.sin(u * 9), 0.85, PEM_DAY[2] - 0.35];
};
const fx = (out: Stage, t: number, cam: CamInfo) => {
  // flour falling from his hand
  if (t > FLOUR_T0 && t < FLOUR_T1 + 0.2) {
    const h = hand(t), u = ((t - FLOUR_T0) * 1.3) % 1;
    out.fx.push({ key: `flour${q(u, 20)}`, cw: 300, ch: 300, draw: (p) => fxFlour(p, q(u, 20)), x: h[0], y: h[1] - 0.35, z: h[2], w: 0.7, h: 0.7, soft: true });
  }
  // drips from the child's feet while she stands wet on the porch and walks
  const k = kid(t);
  if (k && k.alpha > 0.5 && t > 24.2 && t < WALK_T1) {
    const u = ((t * 1.7) % 1);
    out.fx.push({ key: `drip${q(u, 20)}`, cw: 200, ch: 200, draw: (p) => fxSweat(p, q(u, 20)), x: k.x, y: k.y + 0.2, z: k.z + 0.1, w: 0.36, h: 0.36 });
  }
  // she dissolves into sparkles
  if (t > FADE_T0 - 0.1 && t < FADE_T1 + 0.9) {
    const u = (t - (FADE_T0 - 0.1)) / (FADE_T1 - FADE_T0 + 1.0);
    for (let i = 0; i < 4; i++) {
      const ox = [-0.28, 0.12, 0.3, -0.05][i], v = clamp01(u * 1.1 - i * 0.05);
      out.fx.push({ key: `spk${i}${q(v, 20)}`, cw: 420, ch: 210, draw: (p) => fxStars(p, q(v, 20)), x: SPOT[0] + ox, y: 0.5 + 1.0 * v + 0.15 * i, z: SPOT[2] + 0.05, w: 0.38, h: 0.19 });
    }
  }
  // the drain: water rings on the ground, and the memory bubble
  if (t > 31.6 && t < 33.2) { const u = ((t - 31.6) * 0.8) % 1; out.fx.push({ key: `rip${q(u, 24)}`, cw: 400, ch: 400, draw: (p) => fxRipple(p, q(u, 24)), x: SPOT[0], y: 0.04, z: SPOT[2], w: 1.0, h: 1.0, flat: true, soft: true }); }
  if (t > 35.3 && t < 38.0) { const u = ((t - 35.3) * 0.7) % 1; out.fx.push({ key: `rip2${q(u, 24)}`, cw: 400, ch: 400, draw: (p) => fxRipple(p, q(u, 24)), x: SPOT[0], y: 0.04, z: SPOT[2], w: 1.3, h: 1.3, flat: true, soft: true }); }
  if (t > 33.6 && t < 35.2) { const u = ((t - 33.6) * 0.7) % 1; out.fx.push({ key: `mem${q(u, 12)}`, cw: 760, ch: 520, draw: (p) => fxMemory(p, q(u, 12)), x: WIN_X - 0.75, y: 3.0, z: -1.0, w: 2.0, h: 1.37 }); }
  // question mark over the young man when the prints end mid-yard
  if (t > 12.3 && t < 13.7) { const u = ((t - 12.3) * 0.9) % 1; out.fx.push({ key: `q${q(u, 20)}`, cw: 200, ch: 260, draw: (p) => fxQuestion(p, q(u, 20)), x: PEM_DAY[0] + 0.1, y: 1.95, z: PEM_DAY[2], w: 0.36, h: 0.47 }); }
  void cam;
};

export const stage = (id: number, t: number, cam: CamInfo): Stage => {
  const out: Stage = { places: [], fx: [] };
  LNAME = SHOTS[id - 1].light;
  findSun(cam, SUN);
  mainChars(t, cam, out);
  fx(out, t, cam);
  return out;
};
void [HOUSE_X, easeOut, DOOR_T0, DOOR_T1, MORNING_T, NIGHT_T];
