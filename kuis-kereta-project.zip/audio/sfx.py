# Every sound effect + ambience bed of the station short as a cue list timed to the picture (timeline.py), rendered
# into one stereo SFX stem. Levels follow the user's standard mix: each EVENT has a "naive" level (LU relative to the
# voice stem, measured as the event's max momentary loudness) and is placed SFX_DB = -6 dB under it; ambience BEDS
# (integrated loudness) are not reduced. Distance to the camera adds gain, a low-pass and more valley reverb.
import math
import numpy as np
from dsp import (SR, ns, tt, rng, dbg, lp, hp, bp, peq, shelf, pan, st, place, fades, widen, make_ir, convolve_st,
                 momentary_max, integrated, colored, smooth_noise, modal)
import sfx_gen as G
import timeline as T

N = ns(T.DUR)
SFX_DB = -6.0


class Cue:
    def __init__(self, t, name, desc, gen, naive, kind="event", p=0.0, extra=0.0, lpf=None, send=0.12, group=None, cut=None):
        self.t, self.name, self.desc, self.gen, self.naive = t, name, desc, gen, naive
        self.kind, self.p, self.extra, self.lpf, self.send, self.cut = kind, p, extra, lpf, send, cut
        self.group = group or name
        self.applied = naive + (SFX_DB if kind == "event" else 0.0) + extra
        self.measured = None


def cues():
    C = []
    R = rng(2711)
    rr = lambda: rng(int(R.integers(1 << 30)))
    add = C.append

    # ------------------------------------------------ ambience beds
    add(Cue(0.0, "amb_hall", "waiting hall: travellers murmuring, soft footsteps, high-ceiling reverb, a breeze through the arches (all shots)",
            _cut(lambda: (_hall(T.DUR, rng(51)), 0.0), T.DUR, 0.5, 1.2), -22, "bed", send=0.0))
    add(Cue(T.DUR - 4.8, "amb_golden", "golden end: birds and a calm breeze fade in under the moral (shot 18)",
            _cut(lambda: (_golden(4.8, rng(53)), 0.0), 4.8, 1.2, 1.0), -26, "bed", send=0.0))

    # ------------------------------------------------ the young man
    add(Cue(8.0, "sigh", "bored sigh on 'bosan'", (lambda r=rr(): (G.oof(r, "ugh", 112), 0.1)), -13, p=-0.25, send=0.25, group="sigh"))
    add(Cue(16.2, "paper_pull", "pulls the ticket from his jacket", (lambda r=rr(): (_paper(r, 0.5), 0.1)), -17, p=-0.2, send=0.1, group="paper"))
    add(Cue(18.6, "paper_fan", "peels the banknotes out", (lambda r=rr(): (_paper(r, 0.9), 0.15)), -15, p=-0.2, send=0.1, group="paper"))
    add(Cue(21.4, "paper_point", "pointing flick of the notes on 'Kek,'", (lambda r=rr(): (_paper(r, 0.6), 0.08)), -18, p=-0.2, send=0.1, group="paper"))
    add(Cue(25.55, "paper_wave", "waves the stack on 'bayar seratus ribu'", (lambda r=rr(): (_paper(r, 0.7), 0.1)), -18, p=-0.2, send=0.1, group="paper"))
    add(Cue(27.55, "paper_wave2", "stack up on 'satu juta'", (lambda r=rr(): (_paper(r, 0.8), 0.1)), -17, p=-0.2, send=0.1, group="paper"))
    for k, (a, b) in enumerate(T.NOTE_FLIGHTS):
        add(Cue(a, "note_fly", f"banknote flies across the bench ({k + 1}/3)", (lambda r=rr(): (G.whoosh(0.5, r, 0.2, 1200, 4200, 0.7, 0.12, 0.25) * 0.5, 0.2)),
                -15, p=0.0, send=0.12, group="note"))
        add(Cue(b - 0.1, "note_catch", f"note lands in the hand ({k + 1}/3)", (lambda r=rr(): (_paper(r, 1.0, snap=True), 0.03)), -12,
                p=-0.2 if k != 1 else 0.2, send=0.1, group="note"))
    add(Cue(41.2, "stars", "victory glints over the young man", lambda: (_glints(rng(61)), 0.0), -14, p=-0.25, send=0.3))
    add(Cue(50.1, "boing", "question marks pop out", lambda: (_boing(rng(62)), 0.02), -12, p=-0.2, send=0.25))
    add(Cue(50.9, "gulp", "nervous gulp", (lambda r=rr(): (G.oof(r, "oh", 118), 0.1)), -16, p=-0.25, send=0.2, group="sigh"))
    add(Cue(T.TWIST - 0.1, "gasp", "shock on 'Saya juga tidak tahu'", (lambda r=rr(): (G.whoa(r, 122, 0.4), 0.1)), -12, p=-0.25, send=0.3, group="sigh"))
    add(Cue(T.TWIST + 0.35, "thud", "deadpan thud under the twist", (lambda r=rr(): (G.push_thump(r), 0.0)), -11, p=0.0, send=0.2))

    # ------------------------------------------------ the riddle of light
    for k, (t0, d, pk) in enumerate([(33.2, 0.9, 0.35), (33.45, 0.9, 0.35)]):
        add(Cue(t0, "light_whoosh", f"streak of light across the hall ({k + 1}/2)", (lambda r=rr(), d=d, pk=pk: (G.whoosh(d, r, pk, 900, 6000, 0.9, 0.22, 0.3), pk)),
                -11, p=-0.5 if k == 0 else 0.5, send=0.3, group="light"))
    add(Cue(34.3, "tick", "clock tick on 'satu detik'", lambda: (_tick(rng(63)), 0.0), -14, p=0.3, send=0.15))

    # ------------------------------------------------ the train
    add(Cue(51.3, "train_rumble", "train rolling in: engine rumble, wheel clacks slowing down, brakes (shots 13-14)",
            _cut(lambda: (_train(5.2, rng(64)), 0.0), 5.2, 0.6, 1.4), -18, "bed", p=0.0, send=0.2))
    add(Cue(T.WHISTLE, "train_whistle", "train whistle on 'peluit'", lambda: (_horn(rng(65)), 0.0), -9, p=-0.3, send=0.45, lpf=5200))
    add(Cue(54.7, "steam", "steam release as it stops", lambda: (_steam(rng(66)), 0.0), -14, p=0.3, send=0.4))

    # ------------------------------------------------ he leaves for the platform
    for k, t in enumerate(T.walk_steps()):
        add(Cue(t, "step", "old man's footstep walking off", (lambda r=rr(): (shelf(G.stroll_step(r, r.uniform(0.3, 0.9)), 1500, 4.0, "high"), 0.0)),
                -9, p=min(0.7, -0.1 + 0.12 * k), extra=-max(0.0, 0.4 * k), send=0.3, group="steps"))
    return C


# ================================================================ generators for this story
def _paper(r, size=0.7, snap=False):
    d = 0.25 + 0.2 * size
    n = ns(d)
    t = np.arange(n) / SR
    nz = r.standard_normal(n)
    y = bp(nz, 1500, 7000, 1) * smooth_noise(n, r, 40) ** 2 * np.exp(-t / (0.08 * size + 0.04))
    if snap:
        y += bp(nz, 700, 3500, 1) * np.exp(-t / 0.012) * 1.2
    return fades(y, 0.002, 0.03)


def _glints(r):
    out = np.zeros(ns(1.3))
    for k, f in enumerate([2400, 3100, 3700, 2800]):
        c = np.asarray(G.clink(r, f, 0.25, 1.0), float) * 0.7
        i = ns(0.12 * k + r.uniform(0, 0.03))
        out[i:i + len(c)] += c[: len(out) - i]
    return fades(out, 0.002, 0.2)


def _boing(r):
    d = 0.42
    t = tt(d)
    f = 280 + 420 * np.exp(-t / 0.12) * np.sin(np.pi * np.minimum(t / 0.3, 1)) + 140 * t
    y = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / 0.16) * np.clip(t / 0.004, 0, 1)
    return fades(y + 0.25 * np.sin(2 * np.pi * np.cumsum(f * 2.01) / SR) * np.exp(-t / 0.08), 0.002, 0.05)


def _tick(r):
    t = tt(0.12)
    return np.sin(2 * np.pi * 1700 * t) * np.exp(-t / 0.006) + 0.4 * bp(r.standard_normal(len(t)), 800, 5000, 1) * np.exp(-t / 0.004)


def _horn(r):
    d = 1.35
    n = ns(d)
    t = np.arange(n) / SR
    vib = 1 + 0.006 * np.sin(2 * np.pi * 5.5 * t)
    env = np.clip(t / 0.06, 0, 1) * np.where(t < 0.55, 1.0, np.exp(-(t - 0.55) / 0.12)) + 0.0
    env = np.clip(t / 0.05, 0, 1) * np.where(t < 0.75, 1.0, np.exp(-(t - 0.75) / 0.14))
    y = np.zeros(n)
    for f, a in [(660, 1.0), (880, 0.75), (990, 0.5), (1320, 0.3)]:
        y += a * np.sin(2 * np.pi * np.cumsum(np.full(n, f) * vib) / SR)
    y += 0.25 * bp(r.standard_normal(n), 1500, 6000, 1)
    return fades(lp(y, 6000, 1) * env, 0.004, 0.08)


def _steam(r):
    d = 2.2
    n = ns(d)
    t = np.arange(n) / SR
    y = bp(colored(n, r, 0.3), 2500, 9000, 1) * np.where(t < 0.1, t / 0.1, np.exp(-(t - 0.1) / 0.8))
    return fades(y, 0.01, 0.4)


def _train(dur, r):
    n = ns(dur)
    t = np.arange(n) / SR
    k = np.clip(t / dur, 0, 1)
    rumble = lp(colored(n, r, 1.2), 160, 2) * (0.9 - 0.45 * k)
    chug = np.zeros(n)
    tm = 0.0
    while tm < dur:                    # wheel clacks slow down as the train brakes
        i = ns(tm)
        if i < n - 400:
            seg = np.arange(400) / SR
            chug[i:i + 400] += np.sin(2 * np.pi * 110 * seg) * np.exp(-seg / 0.03) * 0.6 + bp(r.standard_normal(400), 300, 2500, 1) * np.exp(-seg / 0.01) * 0.35
        tm += 0.18 + 0.5 * min(1.0, tm / dur) ** 2
    squeal = bp(colored(n, r, 0.2), 2800, 3400, 2) * np.where(t > dur * 0.62, np.sin(np.pi * np.clip((t - dur * 0.62) / (dur * 0.35), 0, 1)) , 0) * 0.5
    return st(rumble) + pan(chug, 0.1) * 0.7 + pan(squeal, -0.1)


def _golden(dur, r):
    n = ns(dur)
    x = G.breeze(dur, r, 0.6, 0.1, 650)
    x += pan(G.bird_chirps(dur, r, 0.35, "blackbird") * 0.06, -0.5)
    x += pan(G.bird_chirps(dur, r, 0.25, "blackbird") * 0.04, 0.6)
    return x


def _hall(dur, r):
    n = ns(dur)
    x = _murmur(dur, r, 12, early=False)
    x += G.breeze(dur, r, 0.5, 0.15, 500)
    for tm in np.arange(1.0, dur - 1.0, 2.3):
        place(x, pan(shelf(G.stroll_step(r, r.uniform(0.2, 0.9)), 1500, 4.0, "high") * 0.25, r.uniform(-0.8, 0.8)), tm + r.uniform(0, 1.6))
    return x


def _cut(gen, dur, fin, fout):
    def g():
        x, a = gen()
        return fades(x, fin, fout), a
    return g


def _env(gen, dur, fin, fout):
    return _cut(gen, dur, fin, fout)


def _murmur(dur, r, voices, early=False):
    n = ns(dur)
    out = np.zeros((2, n))
    for v in range(voices):
        kind = r.uniform()
        base, scale = ((r.uniform(95, 140), r.uniform(0.95, 1.05)) if kind < 0.45 else
                       (r.uniform(175, 235), r.uniform(1.12, 1.2)) if kind < 0.85 else (r.uniform(260, 330), r.uniform(1.25, 1.35)))
        y = G.babble(dur, r, base, scale, r.uniform(3.6, 4.8), r.uniform(0.55, 0.8), fmax=3400)
        y = lp(y, r.uniform(2200, 3600), 1) * r.uniform(0.3, 1.0)
        out += pan(y, r.uniform(-0.85, 0.85))
    if early:
        for k in range(4):
            h = G.hurrah(r, r.uniform(110, 230), r.uniform(1.0, 1.18))
            place(out, pan(lp(h, 3000, 1) * 0.5, r.uniform(-0.8, 0.8)), r.uniform(0.2, 1.6))
    return fades(out, 0.25, 0.8)



def render(v_ref, on_event=None):
    """v_ref = integrated loudness of the voice stem (stereo). Returns (stereo stem, cue list with measured levels).
    on_event(cue, x, t0) is called with every placed (dry) event, for analysis."""
    C = cues()
    out = np.zeros((2, N))
    send = np.zeros(N)
    for c in C:
        x, anchor = c.gen()
        x = np.asarray(x, float)
        x = pan(x, c.p) if x.ndim == 1 else x
        if c.cut is not None:
            k = ns(c.cut - (c.t - anchor))
            if 0 < k < x.shape[1]:
                x = fades(x[:, :k], 0.0, 0.02)
        tgt = v_ref + c.applied
        cur = momentary_max(x) if c.kind == "event" else integrated(x)
        if np.isfinite(cur):
            x = x * dbg(tgt - cur)
        if c.lpf:
            x = lp(x, c.lpf, 1)
        c.measured = momentary_max(x) - v_ref if c.kind == "event" else integrated(x) - v_ref
        t0 = c.t - anchor
        place(out, x, t0)
        if on_event:
            on_event(c, x, t0)
        if c.send > 0:
            G._place_mono(send, c.send * x.mean(0), t0)
    valley = make_ir(1.1, 77, pre=0.01, hf=1.6, early=[(0.09, 0.45, -0.5), (0.14, 0.3, 0.6), (0.23, 0.2, -0.2)])
    out += 0.55 * convolve_st(send, valley)
    out = hp(out, 25, 2)
    end = ns(T.DUR - 0.12)
    out[:, end:] *= np.linspace(1, 0, N - end)[None, :] ** 2
    return out, C
