# Original comic score for "Tebak-tebakan di stasiun" (C major, 112 bpm, pizzicato + vibes + glockenspiel + brush):
# a lazy station-waiting tune, a smug theme for the young man, bet music, quiz ticking, a win sting, a tiptoeing riddle
# bed, a panic climb on the whistle, a nervous payment, tension -> DEAD STOP before the twist line ("Saya juga tidak tahu,
# Nak."), one lonely "plink" after it, then a warm resolved version of the theme for the moral and a callback to the intro.
import numpy as np
from dsp import SR, ns, rng, pan, place, fades, dbg, make_ir, convolve_st, integrated, lp, hp
import instruments as I
import timeline as T

N = ns(T.DUR)
Q = 60.0 / 112.0     # quarter note (s)
F = I.m2f

SECTIONS = [
    ("wait", 0.0, 10.0), ("smug", 10.0, 21.4), ("bet", 21.4, 29.0), ("quiz", 29.0, 36.4), ("pay", 36.4, 42.5),
    ("riddle", 42.5, 50.2), ("panic", 50.2, 53.9), ("give", 53.9, 58.5), ("tension", 58.5, 63.6), ("dropout", 63.6, 65.65),
    ("moral", 65.65, T.DUR),
]
HARD = [63.6, 65.65]   # music is silent here: level switches are instant

# theme A (quarter-note offsets from the phrase start, length, midi), 4 bars of 4/4
THEME = [(0, 1, 76), (1, .5, 79), (1.5, .5, 76), (2, 1, 74), (3, 1, 72), (4, 1, 74), (5, .5, 77), (5.5, .5, 74), (6, 1, 72), (7, 1, 71),
         (8, 1, 72), (9, .5, 76), (9.5, .5, 79), (10, 1, 84), (11, 1, 79), (12, 2, 77), (14, 1, 74), (15, 1, 67)]
CHORDS = {"C": (36, 43, [52, 55, 60]), "Am": (33, 40, [52, 57, 60]), "F": (41, 36, [53, 57, 60]), "G7": (43, 38, [53, 55, 59]),
          "Dm": (38, 45, [53, 57, 62]), "E7": (40, 47, [52, 56, 62]), "G": (43, 38, [55, 59, 62])}
PROG_A = ["C", "G7", "C", "F", "C", "G7", "C", "G7", "C", "Am", "F", "G7", "C", "G7", "C", "C"]   # per bar over 16 beats? (per 4 beats below)
BARS_A = ["C", "G7", "C", "F"]


class Band:
    def __init__(self):
        self.tr = {}
        self.send = {}
        self.cues = []

    def track(self, name, send):
        if name not in self.tr:
            self.tr[name] = np.zeros((2, N))
            self.send[name] = send
        return self.tr[name]

    def add(self, name, x, t, p=0.0, g=1.0, send=0.15):
        buf = self.track(name, send)
        place(buf, pan(x, p) if np.ndim(x) == 1 else x, t, g)


R = rng(1831)


def _r():
    return rng(int(R.integers(1 << 30)))



R = rng(2711)


def _r():
    return rng(int(R.integers(1 << 30)))


def walk_bass(b, t0, t1, bars, vel=0.6, dur_q=0.9):
    """pizzicato bass: root / fifth on the beats, bar chords from `bars`"""
    k, t = 0, t0
    while t < t1 - 0.05:
        ch = CHORDS[bars[(k // 4) % len(bars)]]
        m = ch[0] if k % 2 == 0 else ch[1]
        b.add("pluck", I.pluck(F(m), vel * R.uniform(0.92, 1.05), _r(), dur=0.6, bright=0.3), t, -0.1)
        k += 1
        t += Q


def comp(b, t0, t1, bars, vel=0.34):
    """off-beat chord plucks (the 'pah')"""
    k, t = 0, t0
    while t < t1 - 0.05:
        ch = CHORDS[bars[(k // 4) % len(bars)]]
        for m in ch[2]:
            b.add("pah", I.pluck(F(m + 12), vel * R.uniform(0.9, 1.05), _r(), dur=0.4, bright=0.5), t + 0.5 * Q, 0.15)
        k += 1
        t += Q


def brush(b, t0, t1, vel=0.4):
    k, t = 0, t0
    while t < t1 - 0.05:
        b.add("brush", I.brush(vel * (1.0 if k % 2 else 0.6), _r(), swish=(k % 2 == 1)), t, 0.2)
        k += 1
        t += Q


def tune(b, t0, notes=THEME, tr=0, name="vibes", vel=0.55, p=-0.15, bars=1):
    for (o, d, m) in notes:
        tm = t0 + o * Q
        if name == "vibes":
            x = I.vibes(F(m + tr), vel * R.uniform(0.93, 1.05), _r(), dur=max(1.2, d * Q + 0.8), damp=d * Q + 0.35)
        elif name == "glock":
            x = I.glock(F(m + tr + 12), vel * R.uniform(0.93, 1.05), _r())
        else:
            x = I.musicbox(F(m + tr), vel * R.uniform(0.93, 1.05), _r())
        b.add(name, x, tm, p)


def build():
    b = Band()
    for name, send in [("pluck", 0.10), ("pah", 0.16), ("vibes", 0.26), ("glock", 0.22), ("musicbox", 0.26), ("brush", 0.12),
                       ("triangle", 0.25), ("pad", 0.25), ("timpani", 0.18), ("cymbal", 0.16)]:
        b.track(name, send)

    # ---- wait 0 - 10: lazy, bass + brush, the theme on vibes in the first 2 bars, then sparse
    walk_bass(b, 0.0, 10.0, BARS_A, 0.5)
    brush(b, 0.0, 10.0, 0.32)
    tune(b, 0.6, THEME[:10], 0, "vibes", 0.42)
    comp(b, 4.0, 10.0, BARS_A, 0.22)
    b.cues.append((0.0, "wait: walking pizzicato bass, brush, vibes sketch of the theme, hall of travellers"))

    # ---- smug 10 - 21.4: full theme, vibes + glock octave, bass + off-beats (the young man's swagger)
    t = 10.0
    for rep in range(2):
        tune(b, t, THEME, 0, "vibes", 0.58)
        tune(b, t, THEME, 0, "glock", 0.28, 0.3)
        t += 16 * Q
    walk_bass(b, 10.0, 21.4, BARS_A, 0.62)
    comp(b, 10.0, 21.4, BARS_A, 0.34)
    brush(b, 10.0, 21.4, 0.38)
    b.cues.append((10.0, "smug: theme on vibes + glock, walking bass, off-beat plucks, brush"))

    # ---- bet 21.4 - 29: dotted stabs, triangle on "satu juta"
    bet_bars = ["C", "Am", "Dm", "G7"]
    walk_bass(b, 21.4, 29.0, bet_bars, 0.62)
    k, tt_ = 0, 21.4
    while tt_ < 29.0 - 0.1:
        for m in CHORDS[bet_bars[(k // 4) % 4]][2]:
            b.add("pah", I.pluck(F(m + 12), 0.4, _r(), dur=0.3, bright=0.6), tt_ + 0.75 * Q, 0.1)
            b.add("pah", I.pluck(F(m + 12), 0.34, _r(), dur=0.3, bright=0.6), tt_ + 1.5 * Q, 0.1)
        k += 2
        tt_ += 2 * Q
    brush(b, 21.4, 29.0, 0.36)
    b.add("triangle", I.triangle(0.6, _r()), 27.62, 0.2)
    b.cues.append((21.4, "bet: dotted stabs over a Dm-G7 turn, triangle ding on 'satu juta'"))

    # ---- quiz 29 - 36.4: ticking staccato plucks, rising question figure; whoosh of light at 33.3
    quiz_bars = ["Am", "Dm", "G7", "C"]
    walk_bass(b, 29.0, 36.4, quiz_bars, 0.55, 0.5)
    tm = 29.0
    while tm < 36.2:
        b.add("pah", I.pluck(F(88), 0.28, _r(), dur=0.12, bright=0.9), tm, 0.35)
        tm += Q
    for k, m in enumerate([72, 74, 76, 79]):
        b.add("glock", I.glock(F(m + 12), 0.4, _r()), 32.3 + k * 0.3, 0.2)
    b.add("glock", I.glock(F(96), 0.5, _r()), 33.4, 0.2)
    b.cues.append((29.0, "quiz: quiz-show ticking, rising 4-note question figure into 'cahaya'"))

    # ---- pay 36.4 - 42.5: calm descending bass, win sting at 41.5 ("tersenyum menang")
    walk_bass(b, 36.4, 41.4, ["C", "G7", "C", "F"], 0.5)
    brush(b, 36.4, 41.4, 0.3)
    for k, m in enumerate([72, 76, 79, 84, 88]):
        b.add("glock", I.glock(F(m + 12), 0.55, _r()), 41.45 + k * 0.07, 0.25)
        b.add("vibes", I.vibes(F(m), 0.5, _r(), dur=1.2, damp=0.6), 41.45 + k * 0.07, -0.2)
    b.add("triangle", I.triangle(0.7, _r()), 41.8, 0.2)
    b.add("cymbal", I.cymbal(0.3, _r()), 41.45, 0.0)
    b.cues.append((41.45, "win sting: ascending glock/vibes run + cymbal"))

    # ---- riddle 42.5 - 50.2: mysterious pad, tiptoe pizzicato (Am - E7)
    pad_f = [F(57), F(60), F(64)]
    b.add("pad", I.pad(pad_f, 7.6, 0.4, _r(), att=1.2, rel=1.0), 42.5, 0.0)
    tm, k = 42.9, 0
    while tm < 50.0:
        m = [57, 60, 64, 60][k % 4] if tm < 46.5 else [56, 59, 64, 59][k % 4]
        b.add("pluck", I.pluck(F(m), 0.42, _r(), dur=0.35, bright=0.4), tm, -0.2 if k % 2 else 0.2)
        k += 1
        tm += Q * 1.0
    b.add("musicbox", I.musicbox(F(88), 0.4, _r()), 46.9, 0.3)
    b.cues.append((42.5, "riddle: pad + tiptoeing plucks, music-box 'question' note as the picture appears"))

    # ---- panic 50.2 - 53.9: fast chromatic climb, whistle accent
    tm, k = 50.2, 0
    while tm < 51.95:
        b.add("pluck", I.pluck(F(52 + k), 0.5 + 0.02 * k, _r(), dur=0.2, bright=0.7), tm, 0.0)
        b.add("vibes", I.vibes(F(76 + k), 0.4, _r(), dur=0.5, damp=0.2), tm, 0.2)
        k += 1
        tm += Q / 2
    b.add("cymbal", I.cymbal(0.55, _r(), dur=2.0), 52.02, 0.0)
    b.add("timpani", I.timpani(F(36), 0.8, _r()), 52.02, 0.0)
    b.cues.append((50.2, "panic: chromatic pizzicato climb, cymbal + timpani on the train whistle"))

    # ---- give 53.9 - 58.5: nervous slow plucks
    walk_bass(b, 53.9, 58.5, ["Am", "Dm", "E7", "Am"], 0.4)
    for k, m in enumerate([69, 67, 69, 72, 71, 69]):
        b.add("vibes", I.vibes(F(m), 0.34, _r(), dur=1.0, damp=0.5), 54.2 + k * 0.7, 0.1)
    b.cues.append((53.9, "give: slow nervous bass + wandering vibes while he hands over the million"))

    # ---- tension 58.5 - 63.6: pad build, then DEAD STOP
    b.add("pad", I.pad([F(48), F(55), F(60)], 5.0, 0.5, _r(), att=2.0, rel=0.2), 58.5, 0.0)
    walk_bass(b, 59.0, 63.6, ["C", "C", "G7", "G7"], 0.45)
    for k in range(5):
        b.add("timpani", I.timpani(F(43), 0.3 + 0.1 * k, _r(), dur=0.8), 59.8 + k * 0.8, 0.0)
    for tr in b.tr.values():
        end = ns(63.6)
        tr[:, end:] = 0.0
    b.cues.append((63.6, "dead stop on 'Saya juga tidak tahu, Nak.': silence"))

    # ---- one lonely plink right after the twist line (after "Nak.")
    b.add("musicbox", I.musicbox(F(79), 0.5, _r()), 65.12, 0.1)

    # ---- moral 65.65 - end: warm slow theme, callback to the intro, final chord
    t = 65.65
    tune(b, t, THEME[:10], 0, "musicbox", 0.5, 0.0)
    tune(b, t, THEME[:10], -12, "vibes", 0.35, -0.2)
    walk_bass(b, t, T.DUR - 0.6, ["C", "G7", "C", "F"], 0.4)
    brush(b, t, T.DUR - 0.6, 0.2)
    b.add("pad", I.pad([F(48), F(52), F(55), F(60)], 4.6, 0.4, _r(), att=1.0, rel=1.5), T.DUR - 4.6, 0.0)
    for m in [60, 64, 67, 72]:
        b.add("glock", I.glock(F(m + 12), 0.4, _r()), T.DUR - 1.3, 0.2)
    b.cues.append((65.65, "moral: music-box + low vibes theme, brush, final warm chord"))

    end = np.ones(N)
    a = ns(T.DUR - 1.0)
    end[a:] = np.linspace(1, 0, N - a) ** 1.5
    for k in b.tr:
        b.tr[k] *= end[None, :]
    return b


TARGET = {"pluck": -3.0, "pah": -7.5, "vibes": -2.5, "glock": -7.0, "musicbox": -3.0, "brush": -13.0, "triangle": -14.0,
          "pad": -4.0, "timpani": -6.0, "cymbal": -11.0}


def render(b, ref=-20.0):
    hall = make_ir(1.5, 7, pre=0.018, hf=1.4)
    yard = make_ir(0.9, 8, pre=0.008, hf=1.8, early=[(0.11, 0.5, -0.4), (0.19, 0.35, 0.5)])
    dry = np.zeros((2, N))
    wet_hall = np.zeros((2, N))
    wet_yard = np.zeros((2, N))
    levels = {}
    for k, x in b.tr.items():
        if not np.any(x):
            continue
        L = integrated(x)
        g = dbg(ref + TARGET.get(k, -6) - L)
        levels[k] = (round(L, 1), round(ref + TARGET.get(k, -6), 1))
        x = x * g
        b.tr[k] = x
        dry += x
        if k == "whistle":
            wet_yard += 0.16 * x
        else:
            wet_hall += b.send[k] * x
    out = dry + 0.7 * convolve_st(wet_hall.mean(0), hall) + 0.8 * convolve_st(wet_yard.mean(0), yard)
    out = hp(out, 30, 2)
    return out, levels
