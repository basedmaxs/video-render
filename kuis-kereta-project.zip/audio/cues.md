# Tebak-tebakan di stasiun - soundtrack cue sheet

All sound is original: synthesized in numpy/scipy by `sfx_gen.py` / `instruments.py`, placed by `sfx.py` / `music.py`, mixed by `mix.py`.
Voice = `voice/voice.wav`, gain only (no EQ, no compression, no pitch).

## Files
| file | content |
|---|---|
| `mix.wav` | final mix, 48 kHz, stereo, 24-bit, 3,240,000 samples = 67.500 s |
| `stem_voice.wav` / `stem_music.wav` / `stem_sfx.wav` | stems at mix gain (they sum to the mix before the master limiter) |

## Master loudness (own BS.1770-4 meter)
- Integrated **-15.0 LUFS**, true peak **-1.2 dBTP**, LRA 2.7 LU, max momentary -10.1 LUFS, max short-term -12.7 LUFS
- Stems: voice -15.3 LUFS, music -25.7 LUFS, sfx -34.9 LUFS (voice gain +3.17 dB, same gain on every stem)
- Master limiter (4x oversampled look-ahead, ceiling -1.2 dBTP): max gain reduction 0.62 dB, active (>0.1 dB) on 0.21 % of samples, >0.5 dB on 0.03 %

ffmpeg ebur128 cross-check:
```
Summary:
  Integrated loudness:
    I:         -15.0 LUFS
    Threshold: -25.1 LUFS
  Loudness range:
    LRA:         2.7 LU
    Threshold: -35.2 LUFS
    LRA low:   -16.3 LUFS
    LRA high:  -13.7 LUFS
  True peak:
    Peak:       -1.2 dBFS
```

## Voice on top: per-section loudness (LUFS, integrated per stem, at mix gain)
bed = music + sfx. margin = voice - bed (integrated over the section). speech median / p10 = median and 10th percentile of the 400 ms momentary margin (voice - bed) over windows centred on spoken words.

| section (shots) | time s | voice | music | sfx | bed | margin LU | speech median LU | speech p10 LU |
|---|---|---|---|---|---|---|---|---|
| wait (1-2) | 0.00-10.00 | -14.4 | -24.9 | -36.6 | -24.6 | 10.2 | 9.7 | 6.4 |
| smug (3-4) | 10.00-19.77 | -14.6 | -25.0 | -37.1 | -24.7 | 10.1 | 10.0 | 4.4 |
| bet (5-7) | 19.77-32.30 | -15.7 | -25.8 | -36.6 | -25.5 | 9.8 | 9.9 | 6.9 |
| quiz (8-9) | 32.30-40.77 | -16.0 | -27.0 | -35.5 | -26.4 | 10.4 | 10.6 | 7.9 |
| win+riddle (10-12) | 40.77-50.10 | -15.6 | -25.9 | -37.2 | -25.6 | 10.0 | 10.9 | 7.5 |
| panic+give (13-14) | 50.10-57.50 | -14.5 | -25.0 | -31.3 | -24.2 | 9.6 | 9.4 | 6.4 |
| twist (15-17) | 57.50-65.63 | -15.6 | -26.9 | -35.8 | -26.7 | 11.2 | 11.6 | 7.5 |
| moral (18) | 65.63-70.93 | -15.3 | -26.3 | -30.5 | -25.2 | 9.8 | 9.9 | 7.0 |

## Music map (original march, Bb major, 120 bpm: quarter note = footfall)
Music target per section, LU under the voice (after a -3 dB speech duck keyed from words.json): wait -10.5, smug -10.0, bet -10.0, quiz -10.5, pay -10.5, riddle -11.0, panic -9.5, give -11.0, tension -10.5, moral -11.0. Applied section gains (dB): wait -4.1, smug -8.1, bet -8.9, quiz -4.6, pay -5.6, riddle -6.3, panic -3.3, give -2.8, tension -7.1, moral -9.2, dropout -7.1.

Rides (music only, dB): 34.20-34.65 s -2.0, 49.40-49.90 s -2.0, 28.00-28.45 s -1.5 - so quiet sentence-final words stay on top and the band blooms in the gaps after them. The hook's last two footfalls (3.5, 4.0) are also 3 dB lower in the SFX for '...walking across it.'

| time s | frame | music |
|---|---|---|
| 0.00 | 0 | wait: walking pizzicato bass, brush, vibes sketch of the theme, hall of travellers |
| 10.00 | 300 | smug: theme on vibes + glock, walking bass, off-beat plucks, brush |
| 21.40 | 642 | bet: dotted stabs over a Dm-G7 turn, triangle ding on 'satu juta' |
| 29.00 | 870 | quiz: quiz-show ticking, rising 4-note question figure into 'cahaya' |
| 41.45 | 1244 | win sting: ascending glock/vibes run + cymbal |
| 42.50 | 1275 | riddle: pad + tiptoeing plucks, music-box 'question' note as the picture appears |
| 50.20 | 1506 | panic: chromatic pizzicato climb, cymbal + timpani on the train whistle |
| 53.90 | 1617 | give: slow nervous bass + wandering vibes while he hands over the million |
| 63.60 | 1908 | dead stop on 'Saya juga tidak tahu, Nak.': silence |
| 65.65 | 1970 | moral: music-box + low vibes theme, brush, final warm chord |

## SFX events
Level convention: every EVENT has a naive level (LU vs the voice stem, as the event's max momentary loudness); applied = naive - 6 dB (standard mix rule) + distance/intensity offsets. BEDS are integrated loudness, not reduced. 'mix LUFS' = the event's max momentary loudness in the final mix (voice stem = -15.3 LUFS integrated). Column sounds also get the camera-distance low-pass and more valley reverb.

| # | time s | frame | cue | what | naive LU | applied LU | mix LUFS | pan |
|---|---|---|---|---|---|---|---|---|
| 1 | 0.000 | 0.0 | amb_hall (bed, integrated) | waiting hall: travellers murmuring, soft footsteps, high-ceiling reverb, a breeze through the arches (all shots) | -22 | -22.0 | -37.3 | +0.00 |
| 2 | 8.000 | 240.0 | sigh | bored sigh on 'bosan' | -13 | -19.0 | -34.3 | -0.25 |
| 3 | 16.200 | 486.0 | paper_pull | pulls the ticket from his jacket | -17 | -23.0 | -38.3 | -0.20 |
| 4 | 18.600 | 558.0 | paper_fan | peels the banknotes out | -15 | -21.0 | -36.3 | -0.20 |
| 5 | 21.400 | 642.0 | paper_point | pointing flick of the notes on 'Kek,' | -18 | -24.0 | -39.3 | -0.20 |
| 6 | 25.550 | 766.5 | paper_wave | waves the stack on 'bayar seratus ribu' | -18 | -24.0 | -39.3 | -0.20 |
| 7 | 27.550 | 826.5 | paper_wave2 | stack up on 'satu juta' | -17 | -23.0 | -38.3 | -0.20 |
| 8 | 33.200 | 996.0 | light_whoosh | streak of light across the hall (1/2) | -11 | -17.0 | -32.3 | -0.50 |
| 9 | 33.450 | 1003.5 | light_whoosh | streak of light across the hall (2/2) | -11 | -17.0 | -32.3 | +0.50 |
| 10 | 34.300 | 1029.0 | tick | clock tick on 'satu detik' | -14 | -20.0 | -35.3 | +0.30 |
| 11 | 38.300 | 1149.0 | note_fly | banknote flies across the bench (1/3) | -15 | -21.0 | -36.3 | +0.00 |
| 12 | 39.100 | 1173.0 | note_catch | note lands in the hand (1/3) | -12 | -18.0 | -33.3 | -0.20 |
| 13 | 41.200 | 1236.0 | stars | victory glints over the young man | -14 | -20.0 | -35.3 | -0.25 |
| 14 | 50.100 | 1503.0 | boing | question marks pop out | -12 | -18.0 | -33.3 | -0.20 |
| 15 | 50.900 | 1527.0 | gulp | nervous gulp | -16 | -22.0 | -37.3 | -0.25 |
| 16 | 51.300 | 1539.0 | train_rumble (bed, integrated) | train rolling in: engine rumble, wheel clacks slowing down, brakes (shots 13-14) | -18 | -18.0 | -33.3 | +0.00 |
| 17 | 52.020 | 1560.6 | train_whistle | train whistle on 'peluit' | -9 | -15.0 | -30.4 | -0.30 |
| 18 | 54.700 | 1641.0 | steam | steam release as it stops | -14 | -20.0 | -35.3 | +0.30 |
| 19 | 55.300 | 1659.0 | note_fly | banknote flies across the bench (2/3) | -15 | -21.0 | -36.3 | +0.00 |
| 20 | 56.000 | 1680.0 | note_catch | note lands in the hand (2/3) | -12 | -18.0 | -33.3 | +0.20 |
| 21 | 61.200 | 1836.0 | note_fly | banknote flies across the bench (3/3) | -15 | -21.0 | -36.3 | +0.00 |
| 22 | 62.100 | 1863.0 | note_catch | note lands in the hand (3/3) | -12 | -18.0 | -33.3 | -0.20 |
| 23 | 64.450 | 1933.5 | gasp | shock on 'Saya juga tidak tahu' | -12 | -18.0 | -33.3 | -0.25 |
| 24 | 64.900 | 1947.0 | thud | deadpan thud under the twist | -11 | -17.0 | -32.3 | +0.00 |
| 25 | 66.133 | 1984.0 | amb_golden (bed, integrated) | golden end: birds and a calm breeze fade in under the moral (shot 18) | -26 | -26.0 | -41.3 | +0.00 |
| 26 | 67.300 | 2019.0 | step | old man's footstep walking off | -9 | -15.0 | -30.3 | -0.10 |
| 27 | 67.594 | 2027.8 | step | old man's footstep walking off | -9 | -15.4 | -30.7 | +0.02 |
| 28 | 67.888 | 2036.6 | step | old man's footstep walking off | -9 | -15.8 | -31.1 | +0.14 |
| 29 | 68.182 | 2045.5 | step | old man's footstep walking off | -9 | -16.2 | -31.5 | +0.26 |
| 30 | 68.476 | 2054.3 | step | old man's footstep walking off | -9 | -16.6 | -31.9 | +0.38 |
| 31 | 68.771 | 2063.1 | step | old man's footstep walking off | -9 | -17.0 | -32.3 | +0.50 |
| 32 | 69.065 | 2071.9 | step | old man's footstep walking off | -9 | -17.4 | -32.7 | +0.62 |
| 33 | 69.359 | 2080.8 | step | old man's footstep walking off | -9 | -17.8 | -33.1 | +0.70 |
| 34 | 69.653 | 2089.6 | step | old man's footstep walking off | -9 | -18.2 | -33.5 | +0.70 |
| 35 | 69.947 | 2098.4 | step | old man's footstep walking off | -9 | -18.6 | -33.9 | +0.70 |
| 36 | 70.241 | 2107.2 | step | old man's footstep walking off | -9 | -19.0 | -34.3 | +0.70 |
| 37 | 70.535 | 2116.1 | step | old man's footstep walking off | -9 | -19.4 | -34.7 | +0.70 |
| 38 | 70.829 | 2124.9 | step | old man's footstep walking off | -9 | -19.8 | -35.1 | +0.70 |
