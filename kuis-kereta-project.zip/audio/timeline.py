# Picture timeline mirrored from src/story.ts + src/cast.ts: shots, key event times (all in seconds).
import numpy as np

FPS = 30
TOTAL = 2128
DUR = TOTAL / FPS            # 70.933 s
fr = lambda f: f / FPS
FLASH = 1e6                  # no white flash in this film (kept for mix.py)

CUTS = [0, 225, 300, 475, 593, 771, 865, 969, 1049, 1223, 1276, 1345, 1503, 1596, 1725, 1774, 1911, 1969, TOTAL]
SHOTS = {i + 1: (CUTS[i], CUTS[i + 1], "golden" if i == 17 else "day", "station") for i in range(18)}
XFADE = {18: 6}

# story events (seconds)
TRAIN_T0, TRAIN_T1 = 51.7, 55.2      # train slides in, brakes
WHISTLE = 52.02                      # "peluit"
NOTE_FLIGHTS = [(38.3, 39.2), (55.3, 56.1), (61.2, 62.2)]
LIGHT = (33.2, 35.0)
STARS = 41.2
THINK = (46.8, 50.4)
TWIST = 64.55
STAND_T, WALK_T = 66.1, 67.3


def shot_t(i):
    a, b = SHOTS[i][:2]
    return fr(a), fr(b)


def shot_at(t):
    f = t * FPS
    for i, (a, b, *_r) in SHOTS.items():
        if a <= f < b:
            return i
    return 18


def walk_steps():
    """the old man's footfalls while he walks to the platform (cast.ts: phase = ((t - WALK_T) * 1.7) % 1, footfall at 0 and .5)"""
    out, k = [], 0
    while True:
        t = WALK_T + k * 0.5 / 1.7
        if t > DUR - 0.05:
            return out
        out.append(t)
        k += 1


def words(path):
    import json
    return json.load(open(path, encoding="utf-8"))
