import * as THREE from "three";
import { Pen, bodyFront, bodySide, townsfolk, PEMUDA, KAKEK, fxBurst, fxPuff, fxStars, fxLight, fxQuestion, fxSweat, fxThink, fxMoney, fxContact, fxShadow } from "./toon.js";
import { FPS, SHOTS, PEM_X, KAK_X, SEAT_Y, smooth, clamp01, trainX, trainSpeed } from "./story.js";
import { LIGHTS } from "./lights.js";
import { NOINK } from "./ink.js";
import { cardShade, blobMaterial, CARD_K } from "./cardshade.js";
const makeEntry = (w, h)=>{
    const cv = document.createElement("canvas");
    cv.width = w;
    cv.height = h;
    const tex = new THREE.CanvasTexture(cv);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = 8;
    return {
        cv,
        tex,
        w,
        h
    };
};
export class Pool {
    live = new Map();
    free = [];
    reqs = [];
    req(key, w, h, k, draw) {
        const r = {
            key: `${w}x${h}|${key}`,
            w,
            h,
            k,
            draw
        };
        this.reqs.push(r);
        return r;
    }
    flush() {
        const want = new Map();
        for (const r of this.reqs){
            const l = want.get(r.key);
            if (l) l.push(r);
            else want.set(r.key, [
                r
            ]);
        }
        for (const [key, e] of this.live)if (!want.has(key)) {
            this.live.delete(key);
            this.free.push(e);
        }
        for (const [key, rs] of want){
            let e = this.live.get(key);
            if (!e) {
                const r = rs[0], i = this.free.findIndex((x)=>x.w === r.w && x.h === r.h);
                e = i >= 0 ? this.free.splice(i, 1)[0] : makeEntry(r.w, r.h);
                const g = e.cv.getContext("2d");
                g.setTransform(1, 0, 0, 1, 0, 0);
                g.clearRect(0, 0, e.w, e.h);
                g.setTransform(r.k, 0, 0, r.k, 0, 0);
                r.draw(new Pen(g));
                e.tex.needsUpdate = true;
                this.live.set(key, e);
            }
            for (const r of rs)r.tex = e.tex;
        }
        this.reqs = [];
    }
}
const blank = (()=>{
    const c = document.createElement("canvas");
    c.width = c.height = 2;
    return new THREE.CanvasTexture(c);
})();
export const SU = 0.00216;
export const SU_SWING = 2.3 / 1830;
const BODY = (()=>{
    const g = new THREE.PlaneGeometry(600 * SU, 1000 * SU);
    g.translate(0, (975 - 500) * SU, 0);
    return g;
})();
const CARD = new THREE.PlaneGeometry(1, 1);
const ROOTS = new Set();
export class Actor {
    mesh;
    mat;
    dmat;
    r = null;
    constructor(parent, geo = BODY){
        this.mat = cardShade(new THREE.MeshLambertMaterial({
            map: blank,
            alphaTest: 0.5,
            side: THREE.DoubleSide
        }));
        this.mat.alphaToCoverage = false;
        this.dmat = new THREE.MeshDepthMaterial({
            depthPacking: THREE.RGBADepthPacking,
            map: blank,
            alphaTest: 0.5,
            side: THREE.DoubleSide
        });
        this.mesh = new THREE.Mesh(geo, this.mat);
        this.mesh.customDepthMaterial = this.dmat;
        this.mesh.onBeforeRender = (r)=>{
            const rt = r.getRenderTarget();
            CARD_K.uPx.value = (rt ? rt.height : r.domElement.height) / 1920;
        };
        this.mesh.castShadow = false;
        this.mesh.receiveShadow = true;
        this.mesh.visible = false;
        this.mesh.rotation.order = "YXZ";
        this.mesh.renderOrder = 1;
        this.mesh.layers.set(NOINK);
        parent.add(this.mesh);
        ROOTS.add(parent);
    }
    bind() {
        const t = this.r?.tex;
        if (t) {
            this.mat.map = t;
            this.dmat.map = t;
        }
    }
}
export class Fx {
    mesh;
    mat;
    soft;
    blob;
    r = null;
    constructor(parent){
        this.mat = new THREE.MeshBasicMaterial({
            map: blank,
            alphaTest: 0.5,
            side: THREE.DoubleSide
        });
        this.mat.alphaToCoverage = false;
        this.soft = new THREE.MeshBasicMaterial({
            map: blank,
            transparent: true,
            depthWrite: false,
            side: THREE.DoubleSide
        });
        this.blob = blobMaterial(blank);
        this.mesh = new THREE.Mesh(CARD, this.mat);
        this.mesh.visible = false;
        this.mesh.layers.set(NOINK);
        parent.add(this.mesh);
    }
    use(soft) {
        this.mesh.material = soft ? this.soft : this.mat;
    }
    bind() {
        const t = this.r?.tex;
        if (!t) return;
        if (this.r.key.includes("|blob|")) {
            if (t.generateMipmaps) {
                t.generateMipmaps = false;
                t.minFilter = THREE.LinearFilter;
                t.needsUpdate = true;
            }
            this.blob.map = t;
            this.mesh.material = this.blob;
            this.mesh.renderOrder = 0.5;
        } else {
            this.mat.map = t;
            this.soft.map = t;
            this.mesh.renderOrder = 0;
        }
    }
}
const hh = (i, s = 0)=>{
    const v = Math.sin(i * 127.1 + s * 311.7) * 43758.5453;
    return v - Math.floor(v);
};
const q = (v, n = 120)=>Math.round(v * n) / n;
const FOLK = [
    0,
    1,
    2,
    3,
    4,
    5
].map((v)=>townsfolk(v));
const seedOf = (i)=>(i * 5 + 3) % 7 + 1;
const tier = (d)=>d < 3.2 ? [
        1800,
        3000,
        3.0
    ] : d < 6.5 ? [
        1080,
        1800,
        1.8
    ] : d < 16 ? [
        480,
        800,
        0.8
    ] : [
        240,
        400,
        0.4
    ];
const SUN = new THREE.Vector3(0.5, 0.75, -0.4).normalize();
const tmp = new THREE.Vector3();
let LNAME = "day";
const sunOf = (root)=>{
    let s = null;
    root.traverse((o)=>{
        if (!s && o instanceof THREE.DirectionalLight && o.castShadow) s = o;
    });
    return s;
};
const findSun = (cam, out)=>{
    if (cam.sun) return out.copy(cam.sun).normalize();
    let best = null, err = Infinity;
    for (const r of ROOTS){
        if (!r.parent) continue;
        const s = sunOf(r);
        if (!s) continue;
        const d = tmp.copy(s.target.position).sub(cam.pos), e = Math.abs(d.dot(cam.right)) / (d.length() || 1);
        if (e < err) {
            err = e;
            best = s;
        }
    }
    return best ? out.copy(best.position).sub(best.target.position).normalize() : out;
};
const light2D = (cam, mirror)=>{
    const sx = SUN.dot(cam.right) * (mirror ? -1 : 1), sy = -SUN.y;
    return Math.round(Math.atan2(sy, sx) / (Math.PI / 4)) * (Math.PI / 4);
};
const viewOf = (cam, x, z, dx, dz)=>{
    const tx = cam.pos.x - x, tz = cam.pos.z - z, tl = Math.hypot(tx, tz) || 1;
    const c = (tx * dx + tz * dz) / tl;
    return {
        side: c < 0.57,
        mirror: dx * cam.right.x + dz * cam.right.z < 0,
        fs: Math.round(Math.sqrt(Math.max(0, 1 - c * c)) * 20) / 20
    };
};
const LEAD = 2 / FPS;
const LID = [
    0.5,
    1,
    1,
    0.5
];
const SWAPS = {};
const lidAt = (t, i, swaps = [])=>{
    const f = Math.round(t * FPS);
    for (const ts of swaps){
        const k = f - Math.round((ts - LEAD) * FPS) + 1;
        if (k >= 0 && k < 4) return LID[k];
    }
    let s = Math.round(-60 * hh(i, 9));
    for(let n = 0; s <= f && n < 400; n++){
        const k = f - s;
        if (k >= 0 && k < 4) return LID[k];
        s += Math.round(15 + 54 * hh(i * 31 + n, 13));
    }
    return 0;
};
const fkey = (o)=>JSON.stringify(o, (_k, v)=>typeof v === "number" ? q(v) : v);
const person = (cam, who, x, y, z, view, fo, so, scale = 1)=>{
    const d = cam.pos.distanceTo(tmp.set(x, y + 1.2, z)) / scale;
    const [w, h, k] = tier(d);
    const mirror = view.side && view.mirror, light = light2D(cam, mirror), seed = seedOf(who.i);
    const f2 = {
        ...fo,
        light,
        seed
    }, s2 = {
        ...so,
        light,
        seed
    };
    const key = view.side ? `S|${who.okey}|${fkey(s2)}` : `F|${who.okey}|${fkey(f2)}`;
    return {
        key,
        x,
        y,
        z,
        scale,
        mirror,
        tierKey: `${w}`,
        draw: (p)=>view.side ? bodySide(p, who.o, s2) : bodyFront(p, who.o, f2),
        size: [
            w,
            h,
            k
        ]
    };
};
const CONTACT = {
    day: [
        0.2,
        0.21,
        0.33
    ],
    golden: [
        0.24,
        0.2,
        0.33
    ]
};
const TAIL = [
    0.42,
    0.44,
    0.62
];
const toSrgb = (v)=>{
    const c = clamp01(v);
    return c <= 0.0031308 ? 12.92 * c : 1.055 * c ** (1 / 2.4) - 0.055;
};
const hexOf = (c, k)=>"#" + c.map((v)=>Math.round(255 * toSrgb(1 - (1 - v) * k)).toString(16).padStart(2, "0")).join("");
const blob = (out, x, y, z, sc = 1, k = 1)=>{
    const hl = Math.hypot(SUN.x, SUN.z) || 1, ox = -SUN.x / hl, oz = -SUN.z / hl, rot = Math.atan2(-ox, -oz);
    if (LNAME === "day") {
        const el = Math.asin(Math.min(0.99, Math.max(0.1, SUN.y)));
        const len = Math.min(2.4, Math.max(0.5, 1.6 / Math.tan(el))) * sc, h = len + 0.55 * sc, c = 0.3 * h;
        const tc = hexOf(TAIL, k);
        out.fx.push({
            key: `blob|shadow|${tc}`,
            cw: 128,
            ch: 256,
            draw: (p)=>fxShadow(p, tc),
            x: x + ox * c,
            y: y + 0.018,
            z: z + oz * c,
            w: 0.72 * sc,
            h,
            flat: true,
            rot
        });
    }
    const cc = hexOf(CONTACT[LNAME], k);
    out.fx.push({
        key: `blob|contact|${cc}`,
        cw: 128,
        ch: 128,
        draw: (p)=>fxContact(p, cc),
        x: x + ox * 0.03 * sc,
        y: y + 0.022,
        z: z + oz * 0.03 * sc,
        w: 0.52 * sc,
        h: 0.4 * sc,
        flat: true,
        rot
    });
};
export { FPS };
const pick = (t, list)=>{
    let r = list[0][1];
    for (const [t0, p] of list)if (t + LEAD >= t0) r = p;
    else break;
    return r;
};
const PEM = [
    [
        0,
        {
            expr: "neutral"
        }
    ],
    [
        7.55,
        {
            expr: "neutral",
            look: 1
        }
    ],
    [
        10.05,
        {
            expr: "smile",
            facing: 1
        }
    ],
    [
        17.15,
        {
            expr: "smile",
            prop: "ticket",
            facing: 1
        }
    ],
    [
        19.0,
        {
            expr: "smile",
            prop: "notes",
            facing: 1
        }
    ],
    [
        20.6,
        {
            expr: "grin",
            prop: "notes",
            facing: 1
        }
    ],
    [
        21.45,
        {
            expr: "smile",
            prop: "point",
            facing: 1
        }
    ],
    [
        25.7,
        {
            expr: "grin",
            prop: "notes",
            facing: 1
        }
    ],
    [
        28.6,
        {
            expr: "smile",
            facing: 1
        }
    ],
    [
        30.5,
        {
            expr: "smile",
            prop: "palm",
            facing: 1
        }
    ],
    [
        34.6,
        {
            expr: "smile",
            facing: 1
        }
    ],
    [
        37.9,
        {
            expr: "neutral",
            prop: "palm",
            facing: 1
        }
    ],
    [
        39.4,
        {
            expr: "smile",
            prop: "note",
            facing: 1
        }
    ],
    [
        40.85,
        {
            expr: "grin",
            prop: "note",
            facing: 1
        }
    ],
    [
        42.5,
        {
            expr: "smile",
            facing: 1
        }
    ],
    [
        47.0,
        {
            expr: "nervous",
            facing: 1
        }
    ],
    [
        50.15,
        {
            expr: "nervous",
            prop: "head"
        }
    ],
    [
        52.0,
        {
            expr: "shock",
            prop: "head"
        }
    ],
    [
        53.35,
        {
            expr: "pained"
        }
    ],
    [
        54.5,
        {
            expr: "nervous",
            prop: "notes",
            facing: 1
        }
    ],
    [
        56.0,
        {
            expr: "nervous",
            facing: 1
        }
    ],
    [
        57.5,
        {
            expr: "smile",
            facing: 1
        }
    ],
    [
        61.4,
        {
            expr: "neutral",
            prop: "palm",
            facing: 1
        }
    ],
    [
        62.5,
        {
            expr: "neutral",
            prop: "note",
            facing: 1
        }
    ],
    [
        64.55,
        {
            expr: "shock",
            prop: "note",
            facing: 1
        }
    ],
    [
        66.0,
        {
            expr: "dazed",
            prop: "note"
        }
    ]
];
const KAK = [
    [
        0,
        {
            expr: "smile_closed"
        }
    ],
    [
        12.9,
        {
            expr: "neutral",
            facing: -1
        }
    ],
    [
        28.85,
        {
            expr: "smile_closed",
            facing: -1
        }
    ],
    [
        30.4,
        {
            expr: "neutral",
            facing: -1
        }
    ],
    [
        36.7,
        {
            expr: "neutral",
            facing: -1
        }
    ],
    [
        38.0,
        {
            expr: "neutral",
            prop: "note",
            facing: -1,
            gside: -1
        }
    ],
    [
        39.3,
        {
            expr: "smile_closed",
            facing: -1
        }
    ],
    [
        42.5,
        {
            expr: "smile",
            facing: -1
        }
    ],
    [
        55.2,
        {
            expr: "smile",
            prop: "palm",
            facing: -1,
            gside: -1
        }
    ],
    [
        56.0,
        {
            expr: "smile_closed",
            prop: "notes",
            facing: -1
        }
    ],
    [
        59.4,
        {
            expr: "grin",
            facing: -1
        }
    ],
    [
        60.85,
        {
            expr: "grin",
            prop: "note",
            facing: -1,
            gside: -1
        }
    ],
    [
        62.2,
        {
            expr: "grin",
            facing: -1
        }
    ],
    [
        63.8,
        {
            expr: "grin",
            prop: "palm",
            facing: -1
        }
    ],
    [
        65.2,
        {
            expr: "smile_closed",
            prop: "notes",
            facing: -1
        }
    ]
];
const STAND_T = 66.1, WALK_T = 67.3;
const nod = (t, t0)=>{
    const n = Math.round((t - (t0 - LEAD)) * FPS);
    return n >= 0 && n < 4 ? {
        lid: LID[n],
        tilt: [
            2,
            5,
            5,
            2
        ][n]
    } : {
        lid: 0,
        tilt: 0
    };
};
const mainChars = (t, cam, out)=>{
    const pp = pick(t, PEM), kp = pick(t, KAK);
    {
        const fo = {
            mode: "sit",
            expr: pp.expr,
            prop: pp.prop ?? null,
            look: pp.look ?? 0,
            facing: pp.facing ?? 0,
            blink: lidAt(t, 1),
            headTilt: pp.tilt ?? 0,
            gside: pp.gside ?? 1
        };
        out.places.push(person(cam, {
            i: 1,
            o: PEMUDA,
            okey: "pem"
        }, PEM_X, SEAT_Y, 0.04, {
            side: false,
            mirror: false
        }, fo, {}));
        blob(out, PEM_X, 0, 0.1, 1.1);
    }
    const nd = nod(t, 29.4);
    if (t < STAND_T) {
        const fo = {
            mode: "sit",
            expr: kp.expr,
            prop: kp.prop ?? null,
            look: kp.look ?? 0,
            facing: kp.facing ?? 0,
            blink: Math.max(nd.lid, lidAt(t, 2)),
            headTilt: nd.tilt,
            gside: kp.gside ?? 1
        };
        out.places.push(person(cam, {
            i: 2,
            o: KAKEK,
            okey: "kak"
        }, KAK_X, SEAT_Y, 0.04, {
            side: false,
            mirror: false
        }, fo, {}));
        blob(out, KAK_X, 0, 0.1, 1.1);
    } else {
        const w = clamp01((t - WALK_T) / 3.4), x = KAK_X + 4.6 * w, z = 0.2 - 4.6 * w, dx = 1, dz = -1;
        const ph = (t - WALK_T) * 1.7 % 1;
        const view = viewOf(cam, x, z, dx, dz);
        const mode = w > 0 ? "stroll" : "stand";
        const fo = {
            mode,
            phase: ph,
            expr: "smile_closed",
            prop: kp.prop ?? null,
            facing: -1,
            blink: lidAt(t, 2)
        };
        const so = {
            mode: w > 0 ? "march" : "stand",
            phase: ph,
            expr: "smile_closed",
            stomp: 0.55,
            stride: 0.6 * view.fs,
            blink: lidAt(t, 2)
        };
        out.places.push(person(cam, {
            i: 2,
            o: KAKEK,
            okey: "kak"
        }, x, 0, z, w > 0 ? view : {
            side: false,
            mirror: false
        }, fo, so));
        blob(out, x, 0, z, 1.1);
    }
};
const EXTRAS = [
    {
        x: -6.6,
        z: -4.6,
        v: 0,
        kind: "stand"
    },
    {
        x: -5.1,
        z: -3.4,
        v: 1,
        kind: "sit"
    },
    {
        x: -4.4,
        z: -3.4,
        v: 2,
        kind: "sit"
    },
    {
        x: 3.4,
        z: -3.2,
        v: 3,
        kind: "stand"
    },
    {
        x: 4.2,
        z: -4.4,
        v: 4,
        kind: "stand"
    },
    {
        x: 6.2,
        z: -3.3,
        v: 5,
        kind: "sit"
    },
    {
        x: 7.4,
        z: -3.4,
        v: 0,
        kind: "sit"
    },
    {
        x: -8.2,
        z: -2.2,
        v: 2,
        kind: "stand"
    },
    {
        x: -7,
        z: -1.7,
        v: 1,
        kind: "walk",
        dir: 1,
        sp: 0.9
    },
    {
        x: 8,
        z: -2.5,
        v: 3,
        kind: "walk",
        dir: -1,
        sp: 1.1
    },
    {
        x: -3,
        z: -5.1,
        v: 4,
        kind: "walk",
        dir: 1,
        sp: 0.7
    },
    {
        x: 2,
        z: -4.6,
        v: 5,
        kind: "walk",
        dir: -1,
        sp: 1.0
    },
    {
        x: -6.5,
        z: 5.5,
        v: 2,
        kind: "stand"
    },
    {
        x: 6.8,
        z: 6.0,
        v: 0,
        kind: "stand"
    }
];
const extras = (t, cam, out)=>{
    EXTRAS.forEach((e, i)=>{
        const who = {
            i: 20 + i,
            o: FOLK[e.v],
            okey: `f${e.v}`
        };
        const exprs = [
            "neutral",
            "smile_closed",
            "neutral",
            "smile"
        ];
        const expr = exprs[i % 4];
        if (e.kind === "walk") {
            const span = 17, x = ((e.x + 9 + e.dir * e.sp * t) % span + span) % span - 9, ph = (t * e.sp / 0.7 + hh(i)) % 1;
            const view = viewOf(cam, x, e.z, e.dir, 0);
            const fo = {
                mode: "stroll",
                phase: q(ph, 60),
                expr,
                blink: lidAt(t, 30 + i)
            };
            const so = {
                mode: "march",
                phase: q(ph, 60),
                expr,
                stomp: 0.5,
                stride: 0.9 * view.fs,
                blink: lidAt(t, 30 + i)
            };
            out.places.push(person(cam, who, x, 0, e.z, view, fo, so));
            blob(out, x, 0, e.z);
        } else {
            const fo = {
                mode: e.kind === "sit" ? "sit" : "stand",
                expr,
                blink: lidAt(t, 30 + i),
                look: Math.round(Math.sin(t * 0.3 + i))
            };
            out.places.push(person(cam, who, e.x, e.kind === "sit" ? SEAT_Y : 0, e.z, {
                side: false,
                mirror: false
            }, fo, {}));
            blob(out, e.x, 0, e.z);
        }
    });
};
const arc3 = (a, b, u, lift)=>[
        a[0] + (b[0] - a[0]) * u,
        a[1] + (b[1] - a[1]) * u + lift * Math.sin(Math.PI * u),
        a[2] + (b[2] - a[2]) * u
    ];
const note = (out, t, t0, t1, a, b)=>{
    if (t < t0 || t >= t1) return;
    const u = smooth((t - t0) / (t1 - t0)), p = arc3(a, b, u, 0.22);
    out.fx.push({
        key: "money",
        cw: 220,
        ch: 120,
        draw: fxMoney,
        x: p[0],
        y: p[1],
        z: p[2],
        w: 0.3,
        h: 0.164,
        rot: 0.25 * Math.sin(u * 8)
    });
};
const fx = (out, t, cam)=>{
    const pH = [
        -0.4,
        0.8,
        0.3
    ], kH = [
        0.4,
        0.8,
        0.3
    ];
    note(out, t, 38.3, 39.2, kH, pH);
    note(out, t, 55.3, 56.1, pH, kH);
    note(out, t, 61.2, 62.2, kH, pH);
    if (t > 33.2 && t < 35.0) {
        const u = (t - 33.2) / 1.6;
        out.fx.push({
            key: `light${q(u, 40)}`,
            cw: 800,
            ch: 200,
            draw: (p)=>fxLight(p, q(u, 40)),
            x: -5 + 10 * u,
            y: 1.9,
            z: -1.2,
            w: 4.0,
            h: 1.0
        });
        out.fx.push({
            key: `light2${q(u, 40)}`,
            cw: 800,
            ch: 200,
            draw: (p)=>fxLight(p, q(u, 40)),
            x: 5 - 10 * u,
            y: 2.7,
            z: -1.6,
            w: 4.0,
            h: 1.0,
            rot: Math.PI
        });
    }
    if (t > 41.2 && t < 42.6) {
        const u = (t - 41.2) * 0.9 % 1;
        out.fx.push({
            key: `stars${q(u, 30)}`,
            cw: 420,
            ch: 210,
            draw: (p)=>fxStars(p, q(u, 30)),
            x: PEM_X,
            y: 1.68,
            z: 0.1,
            w: 0.75,
            h: 0.375
        });
    }
    if (t > 46.8 && t < 50.4) out.fx.push({
        key: "think",
        cw: 760,
        ch: 520,
        draw: fxThink,
        x: 0.0,
        y: 2.45,
        z: 0.3,
        w: 2.3,
        h: 1.57
    });
    if (t > 49.9 && t < 53.4) {
        const u = (t - 49.9) * 0.8 % 1;
        for (const [dx, dy, s] of [
            [
                -0.35,
                0,
                0.42
            ],
            [
                0.05,
                0.12,
                0.5
            ],
            [
                0.42,
                -0.04,
                0.38
            ]
        ])out.fx.push({
            key: `q${q(u, 20)}`,
            cw: 200,
            ch: 260,
            draw: (p)=>fxQuestion(p, q(u, 20)),
            x: PEM_X + dx,
            y: 1.75 + dy,
            z: 0.12,
            w: 0.3 * s / 0.4,
            h: 0.39 * s / 0.4
        });
        out.fx.push({
            key: `sweat${q(t * 1.3 % 1, 20)}`,
            cw: 200,
            ch: 200,
            draw: (p)=>fxSweat(p, q(t * 1.3 % 1, 20)),
            x: PEM_X + 0.35,
            y: 1.25,
            z: 0.12,
            w: 0.35,
            h: 0.35
        });
    }
    if (t > 52.0 && t < 53.2) {
        const u = (t - 52.0) / 1.2;
        out.fx.push({
            key: `puff${q(u, 20)}`,
            cw: 300,
            ch: 300,
            draw: (p)=>fxPuff(p, q(u, 20)),
            x: trainX(t) + 12,
            y: 3.4 + 1.4 * u,
            z: -10.4,
            w: 3.4,
            h: 3.4,
            soft: true
        });
    }
    void cam;
};
export const stage = (id, t, cam)=>{
    const out = {
        places: [],
        fx: []
    };
    const s = SHOTS[id - 1];
    LNAME = s.light;
    findSun(cam, SUN);
    mainChars(t, cam, out);
    extras(t, cam, out);
    fx(out, t, cam);
    return out;
};
void KAK_X;
void trainSpeed;
