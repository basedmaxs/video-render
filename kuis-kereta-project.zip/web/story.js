export const FPS = 30;
export const TOTAL = 2128;
export const D0 = 0;
export const clamp01 = (x)=>Math.max(0, Math.min(1, x));
export const smooth = (x)=>{
    const u = clamp01(x);
    return u * u * (3 - 2 * u);
};
export const easeOut = (u)=>1 - (1 - clamp01(u)) ** 3;
export const PEM_X = -0.5, KAK_X = 0.5;
export const SEAT_Y = 0.3;
export const HALL = {
    x0: -10,
    x1: 10,
    zBack: -6,
    zFront: 12,
    h: 7
};
const CUTS = [
    0,
    225,
    300,
    475,
    593,
    771,
    865,
    969,
    1049,
    1223,
    1276,
    1345,
    1503,
    1596,
    1725,
    1774,
    1911,
    1969,
    TOTAL
];
export const SHOTS = CUTS.slice(0, -1).map((a, i)=>({
        id: i + 1,
        a,
        b: CUTS[i + 1],
        light: i === 17 ? "golden" : "day"
    }));
export const XFADE = {
    18: 6
};
export const FLASH_AT = 99999;
export const shotAt = (f)=>SHOTS.find((s)=>f >= s.a && f < s.b) ?? SHOTS[SHOTS.length - 1];
export const layersAt = (f)=>{
    for (const s of SHOTS){
        const x = XFADE[s.id];
        if (x && f >= s.a - x / 2 && f < s.a + x / 2) return [
            {
                id: s.id - 1,
                alpha: 1
            },
            {
                id: s.id,
                alpha: (f - (s.a - x / 2) + 1) / (x + 1)
            }
        ];
    }
    return [
        {
            id: shotAt(f).id,
            alpha: 1
        }
    ];
};
export const TRAIN_T0 = 51.7, TRAIN_T1 = 55.2;
export const trainX = (t)=>-95 + 95 * (1 - (1 - clamp01((t - TRAIN_T0) / (TRAIN_T1 - TRAIN_T0))) ** 2.2);
export const trainSpeed = (t)=>(trainX(t + 0.02) - trainX(t - 0.02)) / 0.04;
export const glide = (u)=>{
    const x = clamp01(u);
    return x * x * x * (x * (6 * x - 15) + 10);
};
const mix = (a, b, k)=>({
        pos: a.pos.map((v, i)=>v + (b.pos[i] - v) * k),
        look: a.look.map((v, i)=>v + (b.look[i] - v) * k),
        fov: a.fov + (b.fov - a.fov) * k,
        roll: a.roll + (b.roll - a.roll) * k
    });
const full = (c)=>({
        fov: 40,
        roll: 0,
        ...c
    });
const run = (keys, f)=>{
    let cur = full(keys[0].s(f));
    for(let i = 1; i < keys.length; i++){
        const k = keys[i];
        if (f < k.f) break;
        cur = k.cut ? full(k.s(f)) : mix(cur, full(k.s(f)), glide((f - k.f) / (k.dur ?? 24)));
    }
    return cur;
};
const T = (f)=>f / FPS;
const pushK = (f, f0, rate, punch = 0, n = 35)=>{
    const x = Math.max(0, f - f0);
    let s = rate * x;
    if (punch > rate) for(let i = 0; i < Math.min(x, n); i++)s += (punch - rate) * Math.max(0, Math.min(1, (i + 0.5) / 8, (n - i - 0.5) / 8));
    return Math.exp(-s);
};
const dolly = (pos, look, k, rest = {})=>({
        pos: [
            look[0] + (pos[0] - look[0]) * k,
            look[1] + (pos[1] - look[1]) * k,
            look[2] + (pos[2] - look[2]) * k
        ],
        look,
        ...rest
    });
const E = 1.14;
const cu = (who, f0, dist = 2.1, rate = 0.0025, fov = 32, o = {})=>(f)=>{
        const x = who < 0 ? -0.5 : 0.5, sd = (o.side ?? 0.42) * who;
        return dolly([
            x + sd,
            E + 0.04,
            dist
        ], [
            x,
            E - 0.03,
            0
        ], pushK(f, f0, rate, o.punch ?? 0, o.n ?? 35), {
            fov,
            roll: o.roll ?? 0
        });
    };
const two = (f0, dist = 3.3, rate = 0.002, fov = 38, o = {})=>(f)=>dolly([
            o.x ?? 0.1,
            o.y ?? 1.25,
            dist
        ], [
            0,
            1.0,
            0
        ], pushK(f, f0, rate), {
            fov,
            roll: o.roll ?? 0
        });
const CAMS = {
    1: [
        {
            f: 0,
            s: (f)=>dolly([
                    0.4,
                    1.3,
                    4.6
                ], [
                    0,
                    1.0,
                    0
                ], pushK(f, 0, 0.002), {
                    fov: 40
                })
        },
        {
            f: 14,
            dur: 32,
            s: (f)=>dolly([
                    -3.0,
                    2.0,
                    9.5
                ], [
                    0.5,
                    1.3,
                    -2
                ], pushK(f, 46, 0.0015), {
                    fov: 46
                })
        },
        {
            f: 64,
            dur: 26,
            s: two(90, 3.9, 0.0022, 38)
        },
        {
            f: 140,
            dur: 34,
            s: (f)=>dolly([
                    1.1,
                    1.2,
                    2.9
                ], [
                    0.5,
                    1.0,
                    0
                ], pushK(f, 174, 0.0025), {
                    fov: 36,
                    roll: 0.03
                })
        }
    ],
    2: [
        {
            f: 225,
            s: (f)=>dolly([
                    -2.6,
                    3.0,
                    3.5
                ], [
                    -4.2,
                    4.6,
                    -6
                ], pushK(f, 225, 0.004), {
                    fov: 34
                })
        },
        {
            f: 252,
            cut: true,
            s: cu(-1, 252, 2.3, 0.003, 34)
        }
    ],
    3: [
        {
            f: 300,
            s: cu(-1, 300, 2.0, 0.0025, 32, {
                side: 0.38
            })
        },
        {
            f: 390,
            cut: true,
            s: two(390, 3.3, 0.002, 38, {
                roll: 0.03
            })
        }
    ],
    4: [
        {
            f: 475,
            s: (f)=>dolly([
                    -0.5,
                    1.0,
                    1.7
                ], [
                    -0.4,
                    0.85,
                    0
                ], pushK(f, 475, 0.0025), {
                    fov: 34
                })
        },
        {
            f: 517,
            dur: 20,
            s: (f)=>dolly([
                    -0.3,
                    0.95,
                    1.5
                ], [
                    -0.38,
                    0.8,
                    0
                ], pushK(f, 517, 0.0025), {
                    fov: 33
                })
        }
    ],
    5: [
        {
            f: 593,
            s: cu(-1, 593, 2.2, 0.0025, 32, {
                side: 0.55
            })
        },
        {
            f: 642,
            cut: true,
            s: cu(1, 642, 2.1, 0.0025, 32, {
                roll: -0.03
            })
        },
        {
            f: 728,
            cut: true,
            s: two(728, 3.0, 0.002, 38)
        }
    ],
    6: [
        {
            f: 771,
            s: (f)=>dolly([
                    0.05,
                    1.05,
                    2.2
                ], [
                    -0.45,
                    0.98,
                    0
                ], pushK(f, 771, 0.003), {
                    fov: 38
                })
        },
        {
            f: 820,
            cut: true,
            s: cu(1, 820, 1.9, 0.003, 30, {
                side: 0.3
            })
        }
    ],
    7: [
        {
            f: 865,
            s: cu(1, 865, 1.9, 0.0025, 30, {
                side: 0.3
            })
        },
        {
            f: 915,
            cut: true,
            s: two(915, 3.2, 0.002, 38)
        }
    ],
    8: [
        {
            f: 969,
            s: (f)=>dolly([
                    -1.2,
                    1.25,
                    3.0
                ], [
                    -0.5,
                    1.1,
                    0
                ], pushK(f, 969, 0.0025), {
                    fov: 38
                })
        },
        {
            f: 996,
            dur: 26,
            s: (f)=>dolly([
                    0.0,
                    1.5,
                    4.2
                ], [
                    0,
                    1.4,
                    -1
                ], pushK(f, 1022, 0.002), {
                    fov: 46
                })
        }
    ],
    9: [
        {
            f: 1049,
            s: (f)=>dolly([
                    0.9,
                    1.2,
                    2.8
                ], [
                    0.5,
                    1.0,
                    0
                ], pushK(f, 1049, 0.0025), {
                    fov: 36
                })
        },
        {
            f: 1109,
            cut: true,
            s: (f)=>dolly([
                    0.7,
                    0.95,
                    1.6
                ], [
                    0.5,
                    0.8,
                    0
                ], pushK(f, 1109, 0.003), {
                    fov: 32
                })
        },
        {
            f: 1150,
            cut: true,
            s: two(1150, 3.2, 0.002, 40)
        },
        {
            f: 1196,
            cut: true,
            s: cu(1, 1196, 2.0, 0.003, 32, {
                side: 0.35
            })
        }
    ],
    10: [
        {
            f: 1223,
            s: cu(-1, 1223, 2.0, 0.0028, 32, {
                roll: -0.03
            })
        }
    ],
    11: [
        {
            f: 1276,
            s: cu(1, 1276, 2.4, 0.003, 34, {
                side: 0.3
            })
        }
    ],
    12: [
        {
            f: 1345,
            s: (f)=>dolly([
                    0,
                    1.55,
                    4.4
                ], [
                    0,
                    1.5,
                    0
                ], pushK(f, 1345, 0.002), {
                    fov: 44
                })
        },
        {
            f: 1438,
            cut: true,
            s: cu(-1, 1438, 2.2, 0.0025, 32)
        }
    ],
    13: [
        {
            f: 1503,
            s: cu(-1, 1503, 2.0, 0.003, 30, {
                side: 0.4
            })
        },
        {
            f: 1559,
            cut: true,
            s: (f)=>dolly([
                    -1.8,
                    1.3,
                    3.4
                ], [
                    -0.5,
                    1.3,
                    -4
                ], pushK(f, 1559, 0.002), {
                    fov: 42,
                    roll: -0.04
                })
        }
    ],
    14: [
        {
            f: 1596,
            s: (f)=>dolly([
                    -0.9,
                    1.15,
                    2.6
                ], [
                    -0.5,
                    1.0,
                    0
                ], pushK(f, 1596, 0.0025), {
                    fov: 36
                })
        },
        {
            f: 1650,
            cut: true,
            s: (f)=>dolly([
                    0.0,
                    1.0,
                    2.2
                ], [
                    0,
                    0.85,
                    0
                ], pushK(f, 1650, 0.0025), {
                    fov: 36
                })
        },
        {
            f: 1700,
            cut: true,
            s: cu(1, 1700, 2.0, 0.003, 32, {
                side: 0.35
            })
        }
    ],
    15: [
        {
            f: 1725,
            s: cu(-1, 1725, 1.9, 0.0035, 30, {
                side: 0.42
            })
        }
    ],
    16: [
        {
            f: 1774,
            s: cu(1, 1774, 2.0, 0.0025, 32)
        },
        {
            f: 1826,
            cut: true,
            s: (f)=>dolly([
                    0.1,
                    1.0,
                    1.9
                ], [
                    0.0,
                    0.85,
                    0
                ], pushK(f, 1826, 0.003), {
                    fov: 34
                })
        }
    ],
    17: [
        {
            f: 1911,
            s: cu(1, 1911, 1.7, 0.0025, 30, {
                roll: 0.04,
                punch: 0.006,
                n: 38,
                side: 0.3
            })
        }
    ],
    18: [
        {
            f: 1969,
            s: cu(-1, 1969, 1.9, 0.002, 32, {
                side: 0.4
            })
        },
        {
            f: 2042,
            cut: true,
            s: (f)=>dolly([
                    -1.5,
                    1.4,
                    6.0
                ], [
                    0.2,
                    1.2,
                    -2
                ], pushK(f, 2042, 0.0015), {
                    fov: 44
                })
        },
        {
            f: 2070,
            dur: 58,
            s: ()=>({
                    pos: [
                        0,
                        2.4,
                        9
                    ],
                    look: [
                        0.3,
                        1.3,
                        -3
                    ],
                    fov: 46
                })
        }
    ]
};
const KICKS = [
    [
        52.02,
        0.7
    ],
    [
        64.9,
        1.0
    ],
    [
        8.0,
        0.3
    ]
];
export const kickAt = (t)=>{
    let a = 0;
    for (const [t0, g] of KICKS){
        const n = Math.floor((t - t0) * FPS + 1e-6);
        if (n >= 0 && n < 7) a += g * (n % 2 ? -1 : 1) * (1 - n / 7) ** 1.5;
    }
    return a;
};
export const camAt = (id, f)=>{
    const c = run(CAMS[id], f), a = kickAt(T(f));
    if (!a) return c;
    const d = [
        c.look[0] - c.pos[0],
        c.look[1] - c.pos[1],
        c.look[2] - c.pos[2]
    ];
    const L = Math.hypot(...d), h = Math.hypot(d[0], d[2]) || 1;
    const m = 3 / 640 * Math.tan(c.fov * Math.PI / 360) * L * a;
    return {
        ...c,
        look: [
            c.look[0] - d[2] / h * m,
            c.look[1] + 0.6 * m,
            c.look[2] + d[0] / h * m
        ],
        roll: c.roll + a * 0.004
    };
};
export const keyEnd = (id, f)=>{
    let e = 0;
    for (const k of CAMS[id])if (f >= k.f) e = k.f + (k.cut ? 0 : k.dur ?? 24);
    return Math.max(f, e);
};
const face = (x)=>()=>[
            x,
            E,
            0
        ];
export const DOF = [
    {
        f: 0,
        cInf: 8,
        focus: face(0)
    },
    {
        f: 14,
        dur: 32,
        cInf: 0
    },
    {
        f: 64,
        dur: 26,
        cInf: 8,
        focus: face(0)
    },
    {
        f: 225,
        cInf: 0
    },
    {
        f: 252,
        cInf: 12,
        focus: face(PEM_X)
    },
    {
        f: 300,
        cInf: 12,
        focus: face(PEM_X)
    },
    {
        f: 390,
        cInf: 9,
        focus: face(0)
    },
    {
        f: 475,
        cInf: 13,
        focus: ()=>[
                -0.4,
                0.85,
                0
            ]
    },
    {
        f: 593,
        cInf: 12,
        focus: face(PEM_X)
    },
    {
        f: 642,
        cInf: 12,
        focus: face(KAK_X)
    },
    {
        f: 728,
        cInf: 9,
        focus: face(0)
    },
    {
        f: 771,
        cInf: 11,
        focus: ()=>[
                -0.45,
                0.98,
                0
            ]
    },
    {
        f: 820,
        cInf: 13,
        focus: face(KAK_X)
    },
    {
        f: 915,
        cInf: 9,
        focus: face(0)
    },
    {
        f: 969,
        cInf: 10,
        focus: face(PEM_X)
    },
    {
        f: 996,
        dur: 26,
        cInf: 0
    },
    {
        f: 1049,
        cInf: 10,
        focus: face(KAK_X)
    },
    {
        f: 1109,
        cInf: 12,
        focus: ()=>[
                0.5,
                0.8,
                0
            ]
    },
    {
        f: 1150,
        cInf: 9,
        focus: face(0)
    },
    {
        f: 1196,
        cInf: 12,
        focus: face(KAK_X)
    },
    {
        f: 1223,
        cInf: 13,
        focus: face(PEM_X)
    },
    {
        f: 1276,
        cInf: 12,
        focus: face(KAK_X)
    },
    {
        f: 1345,
        cInf: 0
    },
    {
        f: 1438,
        cInf: 12,
        focus: face(PEM_X)
    },
    {
        f: 1503,
        cInf: 12,
        focus: face(PEM_X)
    },
    {
        f: 1559,
        cInf: 6,
        focus: face(PEM_X)
    },
    {
        f: 1596,
        cInf: 10,
        focus: face(PEM_X)
    },
    {
        f: 1650,
        cInf: 11,
        focus: ()=>[
                0,
                0.85,
                0
            ]
    },
    {
        f: 1700,
        cInf: 12,
        focus: face(KAK_X)
    },
    {
        f: 1725,
        cInf: 13,
        focus: face(PEM_X)
    },
    {
        f: 1774,
        cInf: 12,
        focus: face(KAK_X)
    },
    {
        f: 1826,
        cInf: 12,
        focus: ()=>[
                0,
                0.85,
                0
            ]
    },
    {
        f: 1911,
        cInf: 13,
        focus: face(KAK_X)
    },
    {
        f: 1969,
        cInf: 12,
        focus: face(PEM_X)
    },
    {
        f: 2042,
        cInf: 0
    }
];
export const dofAt = (f)=>{
    let i = 0;
    while(i + 1 < DOF.length && f >= DOF[i + 1].f)i++;
    const d = DOF[i], p = DOF[Math.max(0, i - 1)];
    const k = d.dur ? Math.min(1, (f - d.f) / d.dur) : 1;
    return {
        cInf: p.cInf + (d.cInf - p.cInf) * k,
        focus: d.focus
    };
};
export const focusAt = (id, f)=>{
    const d = dofAt(f);
    return d.focus ? d.focus(f) : camAt(id, f).look;
};
