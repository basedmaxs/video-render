import * as THREE from "three";
import { Batch, boxGeo, V, lam } from "./build.js";
import { beam, ctex, stoneHD, cobbleHD, grassHD, cloudHD } from "./paint.js";
import { LIGHTS, LOOK } from "./lights.js";
import { TONE, CHAR, twoTone, untone } from "./shade.js";
import { NOINK } from "./ink.js";
import { Pool, Actor, Fx, stage } from "./cast.js";
import { FPS, SHOTS, camAt, trainX, HALL } from "./story.js";
export const loadKit = ()=>Promise.resolve({});
const discTex = ()=>ctex("sunDisc", 128, 128, (g)=>{
        const gr = g.createRadialGradient(64, 64, 58, 64, 64, 64);
        gr.addColorStop(0, "rgba(255,255,255,1)");
        gr.addColorStop(1, "rgba(255,255,255,0)");
        g.fillStyle = gr;
        g.fillRect(0, 0, 128, 128);
    });
const haloTex = ()=>ctex("sunHalo", 256, 256, (g)=>{
        const im = g.createImageData(256, 256);
        for(let y = 0; y < 256; y++)for(let x = 0; x < 256; x++){
            const u = Math.hypot(x - 127.5, y - 127.5) / 128;
            const a = (0.55 * Math.exp(-((u / 0.25) ** 2)) + 0.35 * Math.exp(-((u / 0.6) ** 2))) * (1 - Math.min(1, Math.max(0, (u - 0.8) / 0.2)));
            const i = (y * 256 + x) * 4;
            im.data[i] = im.data[i + 1] = im.data[i + 2] = 255;
            im.data[i + 3] = Math.round(255 * Math.min(1, a));
        }
        g.putImageData(im, 0, 0);
    });
const SUN_SHOT = {
    1: {
        az: 62
    },
    18: {
        az: 160,
        el: 9
    }
};
const tileTex = ()=>ctex("hallTile", 512, 512, (g, r)=>{
        const n = 4, s = 512 / n;
        for(let y = 0; y < n; y++)for(let x = 0; x < n; x++){
            const dark = (x + y) % 2 === 0, j = (r() - 0.5) * 14;
            const base = dark ? [
                176,
                140,
                112
            ] : [
                222,
                210,
                180
            ];
            g.fillStyle = `rgb(${base[0] + j | 0},${base[1] + j | 0},${base[2] + j | 0})`;
            g.fillRect(x * s, y * s, s, s);
        }
        g.strokeStyle = "rgba(90,70,60,0.8)";
        g.lineWidth = 6;
        for(let i = 0; i <= n; i++){
            g.beginPath();
            g.moveTo(i * s, 0);
            g.lineTo(i * s, 512);
            g.stroke();
            g.beginPath();
            g.moveTo(0, i * s);
            g.lineTo(512, i * s);
            g.stroke();
        }
    });
const boardTex = ()=>ctex("depBoard", 1024, 410, (g)=>{
        g.fillStyle = "#1f2a3a";
        g.fillRect(0, 0, 1024, 410);
        g.strokeStyle = "#caa24a";
        g.lineWidth = 14;
        g.strokeRect(10, 10, 1004, 390);
        g.fillStyle = "#f5c451";
        g.font = "bold 66px monospace";
        g.textBaseline = "middle";
        const rows = [
            [
                "08.15",
                "02",
                "\u25B6"
            ],
            [
                "08.40",
                "07",
                "\u25B6"
            ],
            [
                "09.05",
                "11",
                "\u25B6"
            ],
            [
                "09.30",
                "04",
                "\u25B6"
            ]
        ];
        rows.forEach((rw, i)=>{
            const y = 62 + i * 92;
            g.fillText(rw[0], 70, y);
            g.fillText(rw[1], 520, y);
            g.fillText(rw[2], 820, y);
        });
    });
const clockTex = ()=>ctex("hallClock", 256, 256, (g)=>{
        g.fillStyle = "#3b2f28";
        g.beginPath();
        g.arc(128, 128, 126, 0, 7);
        g.fill();
        g.fillStyle = "#f7f1e1";
        g.beginPath();
        g.arc(128, 128, 110, 0, 7);
        g.fill();
        g.strokeStyle = "#241726";
        g.lineCap = "round";
        for(let i = 0; i < 12; i++){
            const a = i * Math.PI / 6;
            g.lineWidth = i % 3 ? 5 : 9;
            g.beginPath();
            g.moveTo(128 + 92 * Math.sin(a), 128 - 92 * Math.cos(a));
            g.lineTo(128 + 104 * Math.sin(a), 128 - 104 * Math.cos(a));
            g.stroke();
        }
        g.lineWidth = 11;
        g.beginPath();
        g.moveTo(128, 128);
        g.lineTo(128 + 48 * Math.sin(0.5), 128 - 48 * Math.cos(0.5));
        g.stroke();
        g.lineWidth = 7;
        g.beginPath();
        g.moveTo(128, 128);
        g.lineTo(128 + 78 * Math.sin(1.57), 128 - 78 * Math.cos(1.57));
        g.stroke();
    });
const carTex = ()=>ctex("trainCar", 1024, 256, (g)=>{
        g.fillStyle = "#f2f0ea";
        g.fillRect(0, 0, 1024, 256);
        g.fillStyle = "#2d5aa0";
        g.fillRect(0, 150, 1024, 106);
        g.fillStyle = "#c0353a";
        g.fillRect(0, 138, 1024, 12);
        for(let i = 0; i < 7; i++){
            const x = 40 + i * 140;
            g.fillStyle = "#241726";
            g.fillRect(x - 5, 38, 110, 86);
            g.fillStyle = "#6fa7b8";
            g.fillRect(x, 43, 100, 76);
            g.fillStyle = "rgba(255,255,255,0.35)";
            g.fillRect(x + 8, 49, 28, 64);
        }
    });
const locoTex = ()=>ctex("trainLoco", 512, 256, (g)=>{
        g.fillStyle = "#2d5aa0";
        g.fillRect(0, 0, 512, 256);
        g.fillStyle = "#f2f0ea";
        g.fillRect(0, 150, 512, 50);
        g.fillStyle = "#c0353a";
        g.fillRect(0, 200, 512, 56);
        for (const x of [
            60,
            340
        ]){
            g.fillStyle = "#241726";
            g.fillRect(x - 5, 40, 110, 80);
            g.fillStyle = "#6fa7b8";
            g.fillRect(x, 45, 100, 70);
        }
        g.fillStyle = "#241726";
        for(let i = 0; i < 6; i++)g.fillRect(190 + i * 18, 60, 8, 100);
    });
function quadUp(x0, x1, z0, z1, u, v, y = 0) {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute([
        x0,
        y,
        z1,
        x1,
        y,
        z1,
        x1,
        y,
        z0,
        x0,
        y,
        z1,
        x1,
        y,
        z0,
        x0,
        y,
        z0
    ], 3));
    g.setAttribute("normal", new THREE.Float32BufferAttribute([
        0,
        1,
        0,
        0,
        1,
        0,
        0,
        1,
        0,
        0,
        1,
        0,
        0,
        1,
        0,
        0,
        1,
        0
    ], 3));
    g.setAttribute("uv", new THREE.Float32BufferAttribute([
        0,
        0,
        u,
        0,
        u,
        v,
        0,
        0,
        u,
        v,
        0,
        v
    ], 2));
    return g;
}
export class World {
    root = new THREE.Group();
    pool = new Pool();
    actors = [];
    fxs = [];
    hemi;
    sun;
    fill;
    sky;
    skyMat;
    fog = new THREE.Fog("#bccbec", 25, 420);
    sunDisc;
    sunHalo;
    sunCache = new Map();
    cloudMaps;
    clouds = [];
    train = new THREE.Group();
    frustum = new THREE.Frustum();
    m4 = new THREE.Matrix4();
    v = new THREE.Vector3();
    sph = new THREE.Sphere();
    constructor(kit){
        const R = this.root, M = {};
        this.skyMat = new THREE.ShaderMaterial({
            uniforms: {
                c0: {
                    value: new THREE.Color()
                },
                c1: {
                    value: new THREE.Color()
                },
                c2: {
                    value: new THREE.Color()
                },
                c3: {
                    value: new THREE.Color()
                },
                c4: {
                    value: new THREE.Color()
                },
                e: {
                    value: new THREE.Vector4()
                }
            },
            vertexShader: "varying vec3 vP; void main(){ vP = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }",
            fragmentShader: `uniform vec3 c0, c1, c2, c3, c4; uniform vec4 e; varying vec3 vP;
        void main(){ float el = asin(clamp(normalize(vP).y, -1.0, 1.0));
          vec3 c = mix(c0, c1, smoothstep(0.0, e.x, el));
          c = mix(c, c2, smoothstep(e.x, e.y, el));
          c = mix(c, c3, smoothstep(e.y, e.z, el));
          c = mix(c, c4, smoothstep(e.z, e.w, el));
          gl_FragColor = vec4(c, 1.0); }`,
            side: THREE.BackSide,
            depthWrite: false,
            fog: false
        });
        this.sky = new THREE.Mesh(new THREE.SphereGeometry(1100, 48, 24), this.skyMat);
        this.sky.renderOrder = -1;
        this.sky.frustumCulled = false;
        this.sky.layers.set(NOINK);
        R.add(this.sky);
        this.sunDisc = new THREE.Sprite(new THREE.SpriteMaterial({
            map: discTex(),
            color: new THREE.Color(6.0, 4.4, 2.4),
            fog: false,
            depthWrite: false
        }));
        this.sunHalo = new THREE.Sprite(new THREE.SpriteMaterial({
            map: haloTex(),
            color: new THREE.Color(1, 1, 1),
            fog: false,
            depthWrite: false,
            depthTest: true,
            transparent: true,
            blending: THREE.AdditiveBlending
        }));
        this.sunDisc.renderOrder = -0.5;
        this.sunHalo.renderOrder = 5;
        for (const m of [
            this.sunDisc,
            this.sunHalo
        ]){
            m.frustumCulled = false;
            m.layers.set(NOINK);
            R.add(m);
        }
        this.hemi = new THREE.HemisphereLight("#cfe6ff", "#6c5c8c", 1.1);
        this.sun = new THREE.DirectionalLight("#fff0d6", 2.6);
        this.sun.castShadow = true;
        this.sun.shadow.mapSize.set(4096, 4096);
        this.fill = new THREE.DirectionalLight("#9fb8ff", 0.35);
        R.add(this.hemi, this.sun, this.sun.target, this.fill, this.fill.target);
        this.cloudMaps = {
            day: [
                0,
                1,
                2,
                3
            ].map((k)=>cloudHD(k, LOOK.day.cloud)),
            golden: [
                0,
                1,
                2,
                3
            ].map((k)=>cloudHD(k, LOOK.golden.cloud))
        };
        for(let i = 0; i < 9; i++){
            const a = i / 9 * Math.PI * 2 + 0.3, d = 620 + i % 3 * 60;
            const m = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({
                map: this.cloudMaps.day[i % 4],
                color: new THREE.Color(1.1, 1.1, 1.1),
                transparent: true,
                depthWrite: false,
                fog: false
            }));
            const w = 130 + i % 4 * 30;
            m.position.set(Math.cos(a) * d, 120 + i % 4 * 38, Math.sin(a) * d);
            m.scale.set(w, w / 2, 1);
            m.layers.set(NOINK);
            this.clouds.push(m);
            R.add(m);
        }
        M.floor = lam("hallTile", ()=>({
                map: tileTex()
            }));
        M.wall = lam("hallWallHD", ()=>({
                map: stoneHD("hallWallHD", [
                    "#ecdfc6",
                    "#e4d6bb",
                    "#f0e5cd",
                    "#dccdb0"
                ], "#bfae90")
            }));
        M.trim = lam("hallTrim", ()=>({
                color: "#d8c9a8"
            }));
        M.dark = lam("hallDark", ()=>({
                color: "#4a3a32"
            }));
        M.wood = lam("benchWood", ()=>({
                color: "#b07a44"
            }));
        M.grass = lam("grassHD", ()=>({
                map: grassHD()
            }));
        M.paving = lam("cobbleHD", ()=>({
                map: cobbleHD()
            }));
        M.ballast = lam("ballast", ()=>({
                color: "#6b625c"
            }));
        M.iron = twoTone(new THREE.MeshPhongMaterial({
            color: "#3d414c",
            specular: "#8a8a8a",
            shininess: 60
        }), 0.15);
        M.case = lam("suitcase", ()=>({
                color: "#7a4b2a"
            }));
        M.crate = lam("crate", ()=>({
                color: "#b98c55"
            }));
        M.shed = lam("shedWall", ()=>({
                color: "#cdbb98"
            }));
        M.shedRoof = lam("shedRoof", ()=>({
                color: "#8a5a4a"
            }));
        M.leaf = lam("leaf", ()=>({
                color: "#5aa046"
            }));
        M.trunk = lam("trunk", ()=>({
                color: "#7a5236"
            }));
        const { x0, x1, zBack, zFront, h } = HALL;
        const b = new Batch();
        b.add(quadUp(-900, 900, -900, 900, 450, 450, -0.02), M.grass);
        b.add(quadUp(x0, x1, zBack, zFront, 9, 9, 0.005), M.floor);
        b.add(quadUp(x0 - 6, x1 + 6, zBack - 3.2, zBack, 14, 3, 0.004), M.paving);
        b.add(quadUp(-120, 120, zBack - 10.5, zBack - 3.2, 60, 4, 0.003), M.ballast);
        for (const [xa, xb] of [
            [
                x0,
                -6.6
            ],
            [
                -3.4,
                -1.6
            ],
            [
                1.6,
                3.4
            ],
            [
                6.6,
                x1
            ]
        ])b.add(boxGeo(V(xa, 0, zBack - 0.6), V(xb, h, zBack), 2), M.wall);
        b.add(boxGeo(V(x0, 4.8, zBack - 0.6), V(x1, h, zBack), 2), M.wall);
        for (const xa of [
            -6.6,
            -3.4,
            -1.6,
            1.6,
            3.4,
            6.6
        ])b.add(boxGeo(V(xa - 0.12, 0, zBack - 0.05), V(xa + 0.12, 4.8, zBack + 0.15)), M.trim);
        b.add(boxGeo(V(x0, 4.7, zBack), V(x1, 4.86, zBack + 0.22)), M.trim);
        b.add(boxGeo(V(x0, 0, zBack), V(x1, 0.18, zBack + 0.08)), M.dark);
        for (const sx of [
            -1,
            1
        ]){
            b.add(boxGeo(V(sx > 0 ? x1 : x0 - 0.6, 0, zBack - 0.6), V(sx > 0 ? x1 + 0.6 : x0, h, zFront), 2), M.wall);
            b.add(boxGeo(V(sx > 0 ? x1 - 0.1 : x0, 0.9, zBack), V(sx > 0 ? x1 : x0 + 0.1, 1.0, zFront)), M.trim);
        }
        for (const [px, pz] of [
            [
                -7.8,
                3
            ],
            [
                7.8,
                3
            ],
            [
                -7.8,
                8
            ],
            [
                7.8,
                8
            ]
        ]){
            b.add(boxGeo(V(px - 0.3, 0, pz - 0.3), V(px + 0.3, h - 0.5, pz + 0.3), 2), M.wall);
            b.add(boxGeo(V(px - 0.45, 0, pz - 0.45), V(px + 0.45, 0.45, pz + 0.45)), M.trim);
            b.add(boxGeo(V(px - 0.45, h - 0.9, pz - 0.45), V(px + 0.45, h - 0.5, pz + 0.45)), M.trim);
        }
        const bench = (cx, cz, w)=>{
            b.add(boxGeo(V(cx - w / 2, 0, cz - 0.3), V(cx + w / 2, 0.45, cz + 0.22), 1), M.wood);
            b.add(boxGeo(V(cx - w / 2, 0.45, cz - 0.3), V(cx + w / 2, 1.1, cz - 0.22), 1), M.wood);
        };
        bench(0, -0.34, 2.6);
        bench(-4.8, -3.8, 2.6);
        bench(6.8, -3.8, 2.6);
        b.add(boxGeo(V(-1.75, 0, -0.1), V(-1.2, 0.68, 0.14), 0), M.case);
        b.add(boxGeo(V(-1.75, 0.34, -0.12), V(-1.2, 0.4, 0.16)), M.iron);
        b.add(boxGeo(V(1.35, 0, -0.1), V(1.85, 0.42, 0.36), 0), M.crate);
        b.add(boxGeo(V(1.42, 0.42, -0.04), V(1.8, 0.8, 0.3), 0), M.crate);
        b.add(boxGeo(V(-3.4, 0, 2.4), V(-2.6, 0.9, 3.0), 0), M.case);
        b.add(boxGeo(V(4.1, 0, 3.4), V(4.9, 0.6, 3.9), 0), M.crate);
        for (const zr of [
            -12.7,
            -11.3
        ])b.add(boxGeo(V(-120, 0, zr - 0.05), V(120, 0.14, zr + 0.05)), M.iron);
        for(let sx = -118; sx < 118; sx += 1.3)b.add(boxGeo(V(sx, 0, -13.1), V(sx + 0.3, 0.1, -10.9)), M.dark);
        for (const [sx, sz, sw, sh] of [
            [
                -40,
                -44,
                22,
                6
            ],
            [
                -6,
                -52,
                30,
                7
            ],
            [
                34,
                -46,
                26,
                6
            ],
            [
                70,
                -60,
                28,
                8
            ]
        ]){
            b.add(boxGeo(V(sx - sw / 2, 0, sz - 5), V(sx + sw / 2, sh, sz + 5), 3), M.shed);
            b.add(boxGeo(V(sx - sw / 2 - 0.6, sh, sz - 5.6), V(sx + sw / 2 + 0.6, sh + 1.4, sz + 5.6)), M.shedRoof);
        }
        for(let i = 0; i < 16; i++){
            const tx = -70 + i * 9.5 + i * 37 % 7, tz = -22 - i * 53 % 18, th = 4 + i % 3;
            b.add(boxGeo(V(tx - 0.2, 0, tz - 0.2), V(tx + 0.2, th * 0.45, tz + 0.2)), M.trunk);
            const crown = new THREE.IcosahedronGeometry(th * 0.42, 1);
            b.add(crown, M.leaf, new THREE.Matrix4().makeTranslation(tx, th * 0.75, tz));
        }
        b.build(R);
        const board = new THREE.Mesh(new THREE.PlaneGeometry(4.0, 1.6), new THREE.MeshBasicMaterial({
            map: boardTex(),
            color: 0xe6e6e6
        }));
        board.position.set(-5.0, 5.8, zBack + 0.24);
        board.layers.set(NOINK);
        const clock = new THREE.Mesh(new THREE.CircleGeometry(0.8, 32), new THREE.MeshBasicMaterial({
            map: clockTex(),
            color: 0xe6e6e6
        }));
        clock.position.set(0, 5.85, zBack + 0.24);
        clock.layers.set(NOINK);
        R.add(board, clock);
        const tb = new Batch();
        const carM = lam("trainCar", ()=>({
                map: carTex()
            })), locoM = lam("trainLoco", ()=>({
                map: locoTex()
            }));
        const zf = -11.0, zb = -13.0;
        tb.add(boxGeo(V(-7, 0.55, zb), V(0, 3.6, zf), 0), locoM);
        tb.add(boxGeo(V(-6.6, 3.6, zb + 0.2), V(-0.4, 3.75, zf - 0.2)), M.dark);
        for(let c = 0; c < 3; c++){
            const xa = -7.6 - c * 9.2;
            tb.add(boxGeo(V(xa - 8.6, 0.55, zb), V(xa, 3.5, zf), 0), carM);
            tb.add(boxGeo(V(xa - 8.4, 3.5, zb + 0.3), V(xa - 0.2, 3.62, zf - 0.3)), M.dark);
        }
        tb.add(boxGeo(V(-40, 0.12, zb + 0.25), V(0, 0.55, zf - 0.25)), M.dark);
        tb.build(this.train);
        R.add(this.train);
    }
    shotSun(id, s, L) {
        let v = this.sunCache.get(id);
        if (v) return v;
        let fx = 0, fz = 0;
        for(let f = s.a; f < s.b; f += 3){
            const c = camAt(id, f), x = c.look[0] - c.pos[0], z = c.look[2] - c.pos[2], n = Math.hypot(x, z) || 1;
            fx += x / n;
            fz += z / n;
        }
        const n = Math.hypot(fx, fz) || 1;
        fx /= n;
        fz /= n;
        const ss = s;
        const az = THREE.MathUtils.degToRad(ss.sunAz ?? SUN_SHOT[id]?.az ?? L.az), el = THREE.MathUtils.degToRad(ss.sunEl ?? SUN_SHOT[id]?.el ?? L.el);
        const hx = fx * Math.cos(az) - fz * Math.sin(az), hz = fz * Math.cos(az) + fx * Math.sin(az);
        v = new THREE.Vector3(hx * Math.cos(el), Math.sin(el), hz * Math.cos(el)).normalize();
        this.sunCache.set(id, v);
        return v;
    }
    actor(i) {
        while(this.actors.length <= i)this.actors.push(new Actor(this.root));
        return this.actors[i];
    }
    fx(i) {
        while(this.fxs.length <= i)this.fxs.push(new Fx(this.root));
        return this.fxs[i];
    }
    update(id, f, cam, scene) {
        const t = f / FPS, s = SHOTS[id - 1], L = LIGHTS[s.light];
        const c = camAt(id, f);
        cam.position.set(...c.pos);
        cam.up.set(0, 1, 0);
        cam.lookAt(...c.look);
        cam.rotateZ(c.roll);
        cam.fov = c.fov;
        cam.near = 0.2;
        cam.far = 1500;
        cam.updateProjectionMatrix();
        cam.updateMatrixWorld();
        const focus = V(...c.look), dist = cam.position.distanceTo(focus);
        cam.layers.enable(NOINK);
        const K = LOOK[s.light], sunDir = this.shotSun(id, s, L);
        this.hemi.color.set(L.sky);
        this.hemi.groundColor.set(L.ground);
        this.hemi.intensity = L.hemiI;
        this.sun.color.set(L.sunCol);
        this.sun.intensity = L.sunI;
        let Rr = THREE.MathUtils.clamp(dist * 1.15 + 7, 12, 40);
        if (s.light === "golden") Rr = Math.max(Rr, 30);
        this.sun.position.copy(focus).addScaledVector(sunDir, 220);
        this.sun.target.position.copy(focus);
        const sc = this.sun.shadow.camera;
        sc.left = -Rr;
        sc.right = Rr;
        sc.top = Rr;
        sc.bottom = -Rr;
        sc.near = 20;
        sc.far = 480;
        sc.updateProjectionMatrix();
        this.sun.shadow.bias = L.bias;
        this.sun.shadow.normalBias = L.normalBias * (Rr / 12);
        this.fill.intensity = 0;
        TONE.uLitCol.value.set(...L.lit);
        TONE.uShadeCol.value.set(...L.shade);
        TONE.uShadeLift.value.set(...L.lift);
        TONE.uLambert.value = L.lambert;
        TONE.uSideK.value = L.sideK;
        TONE.uTerm.value = L.term;
        TONE.uBounce.value.set(...LOOK[s.light].bounce);
        TONE.uSat.value = LOOK[s.light].sat;
        CHAR.uCharTint.value.set(...L.charTint);
        CHAR.uCharShade.value = L.charShade;
        CHAR.uGrad.value = L.charGrad;
        CHAR.uBodyGrad.value = L.bodyGrad;
        CHAR.uSideTint.value.set(...L.sideTint);
        const su = this.skyMat.uniforms;
        K.sky.c.forEach((hx, i)=>untone(hx, su["c" + i].value));
        const e = K.sky.e.map((deg)=>THREE.MathUtils.degToRad(deg));
        su.e.value.set(e[1], e[2], e[3], e[4]);
        this.sky.position.copy(cam.position);
        untone(L.fog, this.fog.color);
        this.fog.near = L.fogNear;
        this.fog.far = L.fogFar;
        scene.fog = this.fog;
        scene.background = null;
        const showSun = s.light === "golden";
        this.sunDisc.visible = this.sunHalo.visible = showSun;
        if (showSun) {
            this.sunDisc.position.copy(cam.position).addScaledVector(sunDir, 900);
            this.sunDisc.scale.setScalar(2 * 900 * Math.tan(THREE.MathUtils.degToRad(1.7)));
            this.sunHalo.position.copy(this.sunDisc.position);
            this.sunHalo.scale.setScalar(2 * 900 * Math.tan(THREE.MathUtils.degToRad(24)));
            this.sunHalo.material.color.set(L.sunDisc).multiplyScalar(1.3);
        }
        for(let i = 0; i < this.clouds.length; i++){
            const m = this.clouds[i], mat = m.material;
            m.lookAt(cam.position.x, m.position.y, cam.position.z);
            mat.map = this.cloudMaps[s.light][i % 4];
        }
        this.train.position.set(trainX(t) + 12, 0, 0);
        const right = V(0, 0, 0).setFromMatrixColumn(cam.matrixWorld, 0);
        const st = stage(id, t, {
            pos: cam.position,
            right
        });
        this.frustum.setFromProjectionMatrix(this.m4.multiplyMatrices(cam.projectionMatrix, cam.matrixWorldInverse));
        const tint = s.light === "golden" ? "#ffcf9e" : "#ffffff";
        let ai = 0;
        const used = [];
        for (const p of st.places){
            const sc2 = p.scale ?? 1;
            if (!this.frustum.intersectsSphere(this.sph.set(this.v.set(p.x, p.y + 1.1 * sc2, p.z), 3.5))) continue;
            const a = this.actor(ai++);
            const [w, hh2, k] = p.size ?? [
                300,
                500,
                0.5
            ];
            a.r = this.pool.req(p.key, w, hh2, k, p.draw);
            a.mesh.visible = true;
            a.mesh.position.set(p.x, p.y, p.z);
            a.mesh.rotation.set(0, p.yaw ?? Math.atan2(cam.position.x - p.x, cam.position.z - p.z), p.roll ?? 0);
            a.mesh.scale.set(p.mirror ? -sc2 : sc2, sc2, sc2);
            if (a.mat.emissiveMap) a.mat.emissive.set(tint);
            a.mesh.castShadow = L.actorShadow;
            used.push(a);
        }
        for(let i = ai; i < this.actors.length; i++)this.actors[i].mesh.visible = false;
        let fi = 0;
        const fused = [];
        for (const p of st.fx){
            if (!this.frustum.intersectsSphere(this.sph.set(this.v.set(p.x, p.y, p.z), Math.max(p.w, p.h)))) continue;
            const ef = this.fx(fi++);
            ef.r = this.pool.req(p.key, p.cw, p.ch, 1, p.draw);
            ef.use(!!p.soft);
            ef.mesh.visible = true;
            ef.mesh.position.set(p.x, p.y, p.z);
            if (p.flat) ef.mesh.rotation.set(-Math.PI / 2, 0, p.rot ?? 0);
            else {
                ef.mesh.quaternion.copy(cam.quaternion);
                ef.mesh.rotateZ(p.rot ?? 0);
            }
            ef.mesh.scale.set(p.w, p.h, 1);
            fused.push(ef);
        }
        for(let i = fi; i < this.fxs.length; i++)this.fxs[i].mesh.visible = false;
        this.pool.flush();
        for (const a of used)a.bind();
        for (const ef of fused)ef.bind();
        return focus;
    }
}
