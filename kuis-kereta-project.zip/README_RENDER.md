# Tebak-tebakan di stasiun - render project

Vertical 1080x1920, 30 fps, 2128 frames (70.9 s). Picture and sound are finished; only the full frame render is left.

## Render on GitHub Actions (about 20-30 min with 100 frames per job)
1. Create a repository (public repos get free standard runners) and push this folder:
   `git init && git add -A && git commit -m "station short" && git branch -M main && git remote add origin <your repo URL> && git push -u origin main`
2. GitHub -> Actions -> **render** -> Run workflow: title `Tebak-tebakan di stasiun`, chunk `100`.
   Tip: first run it with `total` = `60` as a quick trial.
3. Download the artifact `final-video` (MP4 + qa_sheet.jpg).
Note: GitHub's Actions terms restrict use to developing/testing the repository's software; rendering video is a grey area, so keep it to occasional renders.

## Render on your own computer instead
Needs Node 22.6+, ffmpeg, Python 3 with numpy/scipy/Pillow, and Playwright + Chromium (`npm i -g playwright && npx playwright install chromium`).
```
node build.mjs .
node render.mjs frames "0-2127"      # can be split: "0-1063" and "1064-2127" in two processes
bash finish.sh "Tebak-tebakan di stasiun"
```
Output: out/Tebak-tebakan di stasiun.mp4 (+ out/qa_sheet.jpg). mix_final.wav (the finished soundtrack) is muxed automatically.
