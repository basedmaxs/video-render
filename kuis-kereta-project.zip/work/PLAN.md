# Shot plan: "Tebak-tebakan di stasiun" (2128 frames, 70.92 s, 30 fps)

Cast: PEMUDA (young man, tidy dark suit, tie, rolled diploma tube in his bag, wristwatch) and KAKEK (old vendor, faded shirt, peci, tray on a neck strap with snacks and water bottles).
Place: station waiting hall (benches, tiled floor, arched windows, platform beyond with a steam/diesel train). Light `day`; `golden` for the last shot (twist aftermath).
Diegetic text only: departure board (numbers/blank), no captions.

| # | frames | words | shot | light | camera | on screen | lens | fx / SFX cue |
|---|---|---|---|---|---|---|---|---|
| 1 | 0-227 | "Di ruang tunggu ... berbaju lusuh" | hook MS of the bench (frame 0 already the two of them), glide wide to hall with crowd, then push to two-shot on "kakek pedagang asongan" | day | MS -> wide -> two-shot | both seated, crowd walking | wide sharp, two-shot cInf 8 | hall ambience, crowd murmur |
| 2 | 227-302 | "Merasa bosan menunggu jadwal keberangkatan" | insert departure board, cut to pemuda CU checking watch, sighing | day | insert -> CU | pemuda bored | cInf 12 | board flip clack, sigh |
| 3 | 302-477 | "pemuda lulusan luar negeri ... tebak-tebakan" | CU pemuda smirk (diploma tube in bag), looks down at kakek, turns and gestures | day | CU -> MS two-shot | pemuda smug, kakek polishing a bottle | cInf 12 | smirk sting |
| 4 | 477-595 | "Ia mengeluarkan selembar tiket ... uang kertas" | insert on hands: ticket then fat stack of notes | day | insert | pemuda hands | cInf 13 | paper slide, note fan |
| 5 | 595-773 | "lalu berkata sombong ... seratus ribu" | CU pemuda pointing (jaw on "Kek"), cut to kakek listening, reaction on "seratus ribu" | day | CU -> CU | both | cInf 12 | |
| 6 | 773-867 | "Tapi ... satu juta" | stack held up in foreground, kakek eyes on it, stars glint | day | insert + foreground notes | pemuda arm, kakek | cInf 11 | glint |
| 7 | 867-971 | "Si kakek mengangguk setuju. Pemuda itu langsung bertanya" | kakek nod CU, two-shot as pemuda leans in | day | CU -> MS | both | cInf 11 | |
| 8 | 971-1051 | "Berapa kecepatan cahaya ..." | MS pemuda asking; light beam streak fx cards fly across hall on "cahaya", clock tick on "satu detik" | day | MS, push | pemuda | cInf 10 | whoosh on cahaya |
| 9 | 1051-1225 | "Tanpa berpikir panjang ... dengan tenang" | kakek reaches in pocket (MS), insert hand holding 100k, passes it over, calm face | day | MS -> insert -> CU | kakek | cInf 11 | note slap |
| 10 | 1225-1278 | "Pemuda itu tersenyum menang" | pemuda CU grin, stars | day | CU | pemuda | cInf 13 | win sting |
| 11 | 1278-1347 | "Kini giliran ... bertanya pelan" | slow push on kakek, soft smile | day | CU push | kakek | cInf 12 | music hush |
| 12 | 1347-1505 | riddle | MS two-shot; thought card: carriage steps with animal drawn going up (3 legs) and down (4 legs), question marks | day | MS -> CU pemuda | both | cInf 10 | |
| 13 | 1505-1598 | "panik memeras otak ... peluit kereta" | pemuda CU sweating, hands on head, train pulls into platform behind, whistle on "peluit" | day | CU, kick on whistle | pemuda | cInf 12 | train whistle, steam |
| 14 | 1598-1727 | "Karena menyerah ... penasaran" | pemuda sags, hands over the million (insert), kakek takes it | day | MS -> insert | both | cInf 11 | |
| 15 | 1727-1776 | "Jadi apa jawabannya?" | pemuda CU leaning in, eager | day | CU | pemuda | cInf 13 | |
| 16 | 1776-1913 | "Si kakek tersenyum ... sambil menjawab" | kakek CU smile, returns the 100k note with two fingers | day | CU -> insert | kakek | cInf 12 | |
| 17 | 1913-1971 | "Saya juga tidak tahu, Nak." | twist: CU kakek shrug, push-in with roll; music stops | day | CU punch | kakek | cInf 13 | sting, hit |
| 18 | 1971-2128 | moral, 2 sentences | pemuda stunned holding one note (CU), then wide: kakek tucks the million away, tips peci, walks to the train; last word = kakek on the step | golden | CU -> wide crane | both | cInf 12 -> 0 | callback hall ambience |

Crossfades: shot 18 (6 f, to golden). No white flash (set FLASH_AT past TOTAL).
